---
id: d0346027-74fc-43a8-8d8d-77143acf43f7
name: Lake Accotink Conservation Area
type: geojson
category: zone
description: A protected natural zone around Lake Accotink, dedicated to environmental preservation, wildlife protection, and responsible public recreation.
srid: 4326
bounds:
  minLon: -77.205
  minLat: 38.78
  maxLon: -77.195
  maxLat: 38.79
metadata:
  source: CivicPress Geography System
  created: 2025-11-25T15:30:02.310Z
  updated: 2025-11-25T15:30:02.310Z
  version: 1.0.0
  accuracy: Standard
  color_mapping:
    property: name
    type: property
    colors:
      Lake Accotink Conservation Area: "#e63b7a"
    default_color: "#6b7280"
created_at: 2025-11-25T15:30:02.310Z
updated_at: 2025-11-25T15:30:02.310Z
color_mapping:
  property: name
  type: property
  colors:
    Lake Accotink Conservation Area: "#e63b7a"
  default_color: "#6b7280"
---

```json
{
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "geometry": {
        "type": "Polygon",
        "coordinates": [
          [
            [
              -77.205,
              38.79
            ],
            [
              -77.195,
              38.79
            ],
            [
              -77.195,
              38.78
            ],
            [
              -77.205,
              38.78
            ],
            [
              -77.205,
              38.79
            ]
          ]
        ]
      },
      "properties": {
        "name": "Lake Accotink Conservation Area",
        "category": "zone"
      }
    }
  ]
}

```
