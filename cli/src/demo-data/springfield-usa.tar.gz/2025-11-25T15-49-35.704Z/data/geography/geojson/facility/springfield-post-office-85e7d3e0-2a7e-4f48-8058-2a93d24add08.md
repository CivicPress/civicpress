---
id: 85e7d3e0-2a7e-4f48-8058-2a93d24add08
name: Springfield Post Office
type: geojson
category: facility
description: A central USPS facility serving Springfield residents. Provides mailing services, PO boxes, passport processing, and parcel drop-off.
srid: 4326
bounds:
  minLon: -77.1848
  minLat: 38.7819
  maxLon: -77.1848
  maxLat: 38.7819
metadata:
  source: CivicPress Geography System
  created: 2025-11-25T23:59:57.000Z
  updated: 2025-11-25T23:59:57.000Z
  version: 1.0.0
  accuracy: Standard
  icon_mapping:
    property: name
    type: property
    icons:
      Springfield Post Office:
        url: e3716453-ce89-4133-98d2-117332f82e5d
        size:
          - 32
          - 32
        anchor:
          - 16
          - 32
    default_icon: circle
    apply_to:
      - Point
created_at: 2025-11-25T23:59:57.000Z
updated_at: 2025-11-25T23:59:57.000Z
icon_mapping:
  property: name
  type: property
  icons:
    Springfield Post Office:
      url: e3716453-ce89-4133-98d2-117332f82e5d
      size:
        - 32
        - 32
      anchor:
        - 16
        - 32
  default_icon: circle
  apply_to:
    - Point
---

```json
{
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "geometry": {
        "type": "Point",
        "coordinates": [
          -77.1848,
          38.7819
        ]
      },
      "properties": {
        "name": "Springfield Post Office",
        "category": "facility"
      }
    }
  ]
}

```
