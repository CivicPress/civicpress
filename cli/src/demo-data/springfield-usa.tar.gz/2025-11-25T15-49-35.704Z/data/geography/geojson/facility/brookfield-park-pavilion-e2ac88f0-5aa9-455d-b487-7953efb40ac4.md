---
id: e2ac88f0-5aa9-455d-b487-7953efb40ac4
name: Brookfield Park Pavilion
type: geojson
category: facility
description: A covered pavilion located within Brookfield Park. Frequently used for gatherings, outdoor events, and community celebrations.
srid: 4326
bounds:
  minLon: -77.2002
  minLat: 38.7775
  maxLon: -77.2002
  maxLat: 38.7775
metadata:
  source: CivicPress Geography System
  created: 2025-11-25T15:28:22.371Z
  updated: 2025-11-25T15:28:22.371Z
  version: 1.0.0
  accuracy: Standard
  icon_mapping:
    property: name
    type: property
    icons:
      Brookfield Park Pavilion:
        url: 392103ef-fb79-4677-b1f1-fb7eb0c53863
        size:
          - 32
          - 32
        anchor:
          - 16
          - 32
    default_icon: circle
    apply_to:
      - Point
created_at: 2025-11-25T15:28:22.371Z
updated_at: 2025-11-25T15:28:22.371Z
icon_mapping:
  property: name
  type: property
  icons:
    Brookfield Park Pavilion:
      url: 392103ef-fb79-4677-b1f1-fb7eb0c53863
      size:
        - 32
        - 32
      anchor:
        - 16
        - 32
  default_icon: circle
  apply_to:
    - Point
---

```json
{
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "geometry": {
        "type": "Point",
        "coordinates": [
          -77.2002,
          38.7775
        ]
      },
      "properties": {
        "name": "Brookfield Park Pavilion",
        "category": "facility"
      }
    }
  ]
}

```
