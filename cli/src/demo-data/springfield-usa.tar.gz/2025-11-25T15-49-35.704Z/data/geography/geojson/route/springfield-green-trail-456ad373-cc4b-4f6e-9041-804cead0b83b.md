---
id: 456ad373-cc4b-4f6e-9041-804cead0b83b
name: Springfield Green Trail
type: geojson
category: route
description: A pedestrian and cycling route connecting neighborhoods to parks and natural corridors. Popular for walking, jogging, and recreational cycling.
srid: 4326
bounds:
  minLon: -77.22
  minLat: 38.782
  maxLon: -77.19
  maxLat: 38.79
metadata:
  source: CivicPress Geography System
  created: 2025-11-25T15:30:30.532Z
  updated: 2025-11-25T15:30:30.532Z
  version: 1.0.0
  accuracy: Standard
created_at: 2025-11-25T15:30:30.532Z
updated_at: 2025-11-25T15:30:30.532Z
---

```json
{
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "geometry": {
        "type": "LineString",
        "coordinates": [
          [
            -77.22,
            38.79
          ],
          [
            -77.21,
            38.788
          ],
          [
            -77.2,
            38.785
          ],
          [
            -77.19,
            38.782
          ]
        ]
      },
      "properties": {
        "name": "Springfield Green Trail",
        "category": "route"
      }
    }
  ]
}

```
