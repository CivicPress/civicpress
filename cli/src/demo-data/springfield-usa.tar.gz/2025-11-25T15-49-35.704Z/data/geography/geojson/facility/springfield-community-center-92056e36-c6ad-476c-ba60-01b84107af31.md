---
id: 92056e36-c6ad-476c-ba60-01b84107af31
name: Springfield Community Center
type: geojson
category: facility
description: A community facility offering recreation programs, youth activities, meeting rooms, and public events for Springfield residents.
srid: 4326
bounds:
  minLon: -77.1805
  minLat: 38.785
  maxLon: -77.1805
  maxLat: 38.785
metadata:
  source: CivicPress Geography System
  created: 2025-11-25T15:27:35.171Z
  updated: 2025-11-25T15:27:35.171Z
  version: 1.0.0
  accuracy: Standard
  icon_mapping:
    property: name
    type: property
    icons:
      Springfield Community Center:
        url: 3febe094-e581-4e80-ba5d-574639845569
        size:
          - 32
          - 32
        anchor:
          - 16
          - 32
    default_icon: circle
    apply_to:
      - Point
created_at: 2025-11-25T15:27:35.171Z
updated_at: 2025-11-25T15:27:35.171Z
icon_mapping:
  property: name
  type: property
  icons:
    Springfield Community Center:
      url: 3febe094-e581-4e80-ba5d-574639845569
      size:
        - 32
        - 32
      anchor:
        - 16
        - 32
  default_icon: circle
  apply_to:
    - Point
---

```json
{
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "geometry": {
        "type": "Point",
        "coordinates": [
          -77.1805,
          38.785
        ]
      },
      "properties": {
        "name": "Springfield Community Center",
        "category": "facility"
      }
    }
  ]
}

```
