---
id: d7b56b82-a907-4f68-8fc4-428769cda347
name: Central Springfield Improvement Zone
type: geojson
category: zone
description: A designated civic development area focused on improving walkability, small business vitality, public services, and community spaces in the town center.
srid: 4326
bounds:
  minLon: -77.192
  minLat: 38.785
  maxLon: -77.18
  maxLat: 38.795
metadata:
  source: CivicPress Geography System
  created: 2025-11-25T15:29:13.052Z
  updated: 2025-11-25T15:29:13.052Z
  version: 1.0.0
  accuracy: Standard
  color_mapping:
    property: name
    type: property
    colors:
      Central Springfield Improvement Zone: "#4d22b3"
    default_color: "#6b7280"
created_at: 2025-11-25T15:29:13.052Z
updated_at: 2025-11-25T15:29:13.052Z
color_mapping:
  property: name
  type: property
  colors:
    Central Springfield Improvement Zone: "#4d22b3"
  default_color: "#6b7280"
---

```json
{
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "geometry": {
        "type": "Polygon",
        "coordinates": [
          [
            [
              -77.192,
              38.795
            ],
            [
              -77.18,
              38.795
            ],
            [
              -77.18,
              38.785
            ],
            [
              -77.192,
              38.785
            ],
            [
              -77.192,
              38.795
            ]
          ]
        ]
      },
      "properties": {
        "name": "Central Springfield Improvement Zone",
        "category": "zone"
      }
    }
  ]
}

```
