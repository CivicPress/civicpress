---
id: f113b1fc-b433-4171-ad83-8202b920b962
name: Main Street Transit Corridor
type: geojson
category: route
description: A primary transportation corridor linking key community facilities, commercial areas, and public services through the heart of Springfield.
srid: 4326
bounds:
  minLon: -77.185
  minLat: 38.775
  maxLon: -77.185
  maxLat: 38.795
metadata:
  source: CivicPress Geography System
  created: 2025-11-25T15:31:13.254Z
  updated: 2025-11-25T15:31:13.254Z
  version: 1.0.0
  accuracy: Standard
  color_mapping:
    property: name
    type: property
    colors:
      Main Street Transit Corridor: "#ff4013"
    default_color: "#6b7280"
created_at: 2025-11-25T15:31:13.254Z
updated_at: 2025-11-25T15:31:13.254Z
color_mapping:
  property: name
  type: property
  colors:
    Main Street Transit Corridor: "#ff4013"
  default_color: "#6b7280"
---

```json
{
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "geometry": {
        "type": "LineString",
        "coordinates": [
          [
            -77.185,
            38.795
          ],
          [
            -77.185,
            38.785
          ],
          [
            -77.185,
            38.775
          ]
        ]
      },
      "properties": {
        "name": "Main Street Transit Corridor",
        "category": "route"
      }
    }
  ]
}

```
