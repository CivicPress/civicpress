---
id: d67a2abc-90ae-44a0-953b-a470be1333fa
name: Springfield Library
type: geojson
category: facility
description: A Fairfax County Public Library branch offering books, study spaces, public computers, events, and local history archives.
srid: 4326
bounds:
  minLon: -77.187
  minLat: 38.781
  maxLon: -77.187
  maxLat: 38.781
metadata:
  source: CivicPress Geography System
  created: 2025-11-25T23:59:56.000Z
  updated: 2025-11-25T23:59:56.000Z
  version: 1.0.0
  accuracy: Standard
  icon_mapping:
    property: name
    type: property
    icons:
      Springfield Library:
        url: 3febe094-e581-4e80-ba5d-574639845569
        size:
          - 32
          - 32
        anchor:
          - 16
          - 32
    default_icon: circle
    apply_to:
      - Point
created_at: 2025-11-25T23:59:56.000Z
updated_at: 2025-11-25T23:59:56.000Z
icon_mapping:
  property: name
  type: property
  icons:
    Springfield Library:
      url: 3febe094-e581-4e80-ba5d-574639845569
      size:
        - 32
        - 32
      anchor:
        - 16
        - 32
  default_icon: circle
  apply_to:
    - Point
---

```json
{
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "geometry": {
        "type": "Point",
        "coordinates": [
          -77.187,
          38.781
        ]
      },
      "properties": {
        "name": "Springfield Library",
        "category": "facility"
      }
    }
  ]
}

```
