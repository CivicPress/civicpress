---
id: 982dafcf-3442-4661-84df-e3c34ed8cbb8
name: Springfield Town Hall
type: geojson
category: facility
description: The main civic administration building for Springfield. Hosts town services, public records, permit processing, and community meetings.
srid: 4326
bounds:
  minLon: -77.1875
  minLat: 38.7893
  maxLon: -77.1875
  maxLat: 38.7893
metadata:
  source: CivicPress Geography System
  created: 2025-11-25T23:59:58.000Z
  updated: 2025-11-25T23:59:58.000Z
  version: 1.0.0
  accuracy: Standard
  icon_mapping:
    property: name
    type: property
    icons:
      Springfield Town Hall:
        url: 3febe094-e581-4e80-ba5d-574639845569
        size:
          - 32
          - 32
        anchor:
          - 16
          - 32
    default_icon: circle
    apply_to:
      - Point
created_at: 2025-11-25T23:59:58.000Z
updated_at: 2025-11-25T23:59:58.000Z
icon_mapping:
  property: name
  type: property
  icons:
    Springfield Town Hall:
      url: 3febe094-e581-4e80-ba5d-574639845569
      size:
        - 32
        - 32
      anchor:
        - 16
        - 32
  default_icon: circle
  apply_to:
    - Point
---

```json
{
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "geometry": {
        "type": "Point",
        "coordinates": [
          -77.1875,
          38.7893
        ]
      },
      "properties": {
        "name": "Springfield Town Hall",
        "category": "facility"
      }
    }
  ]
}
```
