---
id: e7d5b8a1-da05-4183-88a3-d6554490cda2
name: Lake Accotink Park Entrance
type: geojson
category: facility
description: One of the primary public access points to Lake Accotink Park. Connects visitors to trails, water access, picnic areas, and nature amenities.
srid: 4326
bounds:
  minLon: -77.218
  minLat: 38.789
  maxLon: -77.218
  maxLat: 38.789
metadata:
  source: CivicPress Geography System
  created: 2025-11-25T15:25:35.157Z
  updated: 2025-11-25T15:26:50.976Z
  version: 1.0.0
  accuracy: Standard
  icon_mapping:
    property: name
    type: property
    icons:
      Lake Accotink Park Entrance:
        url: 392103ef-fb79-4677-b1f1-fb7eb0c53863
        size:
          - 32
          - 32
        anchor:
          - 16
          - 32
    default_icon: circle
    apply_to:
      - Point
created_at: 2025-11-25T15:25:35.157Z
updated_at: 2025-11-25T15:26:50.976Z
icon_mapping:
  property: name
  type: property
  icons:
    Lake Accotink Park Entrance:
      url: 392103ef-fb79-4677-b1f1-fb7eb0c53863
      size:
        - 32
        - 32
      anchor:
        - 16
        - 32
  default_icon: circle
  apply_to:
    - Point
---

```json
{
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "geometry": {
        "type": "Point",
        "coordinates": [
          -77.218,
          38.789
        ]
      },
      "properties": {
        "name": "Lake Accotink Park Entrance",
        "category": "facility"
      }
    }
  ]
}
```
