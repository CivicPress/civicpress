---
id: "record-1731628800000"
title: 'Animal Control Ordinance'
type: ordinance
status: published

author: "admin"
authors:
  - name: 'City Clerk'
    username: 'admin'
    role: 'clerk'

created: "2024-11-15T10:00:00Z"
updated: "2025-01-10T14:30:00Z"

tags: ['animals', 'licensing', 'public-safety', 'community']
module: legal-register
slug: 'animal-control'
version: "1.0.0"

attached_files:
  - id: "ec8e037d-679c-4dae-8761-b5ef4f8753ba"
    path: "public/dominic-wajda-MvYeDLqt1Wg-unsplash.ec8e037d-679c-4dae-8761-b5ef4f8753ba.jpg"
    original_name: "dominic-wajda-MvYeDLqt1Wg-unsplash.jpg"
    description: "IMAGE"
    category: "Reference"
  - id: "e1a702bb-1469-46fa-964e-7a7560ca3d55"
    path: "public/ohsoshy-poT4mFoVh3I-unsplash.e1a702bb-1469-46fa-964e-7a7560ca3d55.jpg"
    original_name: "ohsoshy-poT4mFoVh3I-unsplash.jpg"
    description: "IMAGE"
    category: "Reference"
---

# Animal Control Ordinance

The City of Springfield adopts this Animal Control Ordinance to promote public safety and ensure the humane treatment of animals within city limits.

![](ec8e037d-679c-4dae-8761-b5ef4f8753ba)

## 1. Purpose

The purpose of this ordinance is to:

- reduce risks to public health and safety caused by uncontrolled animals  
- ensure animals are treated humanely  
- provide clear rules for pet owners inside the city

## 2. Licensing of Dogs

All dogs over four months of age that reside within the City of Springfield must be licensed annually.

- Licenses are issued by the City Clerk’s Office or online through the city portal  
- Proof of current rabies vaccination is required  
- Failure to obtain a license may result in a fine as outlined in Section 7

## 3. Leash Requirements

Dogs must be:

- on a leash not exceeding 2 meters when in public spaces, **or**  
- within a fenced yard or secure enclosure on private property  

Exceptions apply only for designated off-leash areas approved by Council.

## 4. Dangerous Animals

An animal may be designated as “dangerous” by the Animal Control Department if it:

- has bitten or attacked a person or another domestic animal, or  
- has been used to threaten or intimidate members of the public

Once designated as dangerous, the owner must:

- display a warning sign on the property  
- ensure the animal is muzzled in public  
- maintain liability insurance as prescribed by regulation

## 5. Enforcement

Animal Control Officers are authorized to:

- issue warnings and fines  
- impound animals when necessary  
- refer serious cases to the City Attorney for prosecution  

![](e1a702bb-1469-46fa-964e-7a7560ca3d55)

## 6. Penalties

Penalties for violations are as follows:

- First offence: written warning or fine up to 100 USD  
- Second offence: fine up to 300 USD  
- Subsequent offences: fine up to 1,000 USD and possible court action

## 7. Coming into Force

This ordinance comes into force on 1 March 2025 and applies to all residents and businesses within the City of Springfield.
