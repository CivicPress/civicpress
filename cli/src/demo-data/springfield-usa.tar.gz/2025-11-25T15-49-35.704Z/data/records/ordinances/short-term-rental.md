---
id: "record-1725148800000"
title: 'Short-Term Rental Regulation Ordinance'
type: ordinance
status: published

author: "admin"
authors:
  - name: 'City Clerk'
    username: 'admin'
    role: 'clerk'

created: "2024-09-01T10:00:00Z"
updated: "2025-01-12T14:30:00Z"

tags: ['short-term-rental', 'housing', 'zoning', 'business']
module: legal-register
slug: 'short-term-rental'
version: "1.0.0"

attached_files:
  - id: "d5adcb06-775d-4e53-91a2-0230779948ca"
    path: "public/pexels-uporovphoto-8864476.d5adcb06-775d-4e53-91a2-0230779948ca.jpg"
    original_name: "pexels-uporovphoto-8864476.jpg"
    description: "IMAGE"
    category: "Reference"
  - id: "aa373480-5272-4186-8ce9-b84e14408f61"
    path: "public/cari-kolipoki-cG32qawRuVQ-unsplash.aa373480-5272-4186-8ce9-b84e14408f61.jpg"
    original_name: "cari-kolipoki-cG32qawRuVQ-unsplash.jpg"
    description: "IMAGE"
    category: "Reference"
---

# Short-Term Rental Regulation Ordinance

This ordinance regulates short-term rentals in the City of Springfield in order to balance tourism, neighborhood stability, and housing availability.

![](d5adcb06-775d-4e53-91a2-0230779948ca)

## 1. Definitions

For the purposes of this ordinance:

- **Short-Term Rental (STR)**: the rental of a dwelling unit or a portion of it for fewer than 30 consecutive days  
- **Host**: any person or entity operating a short-term rental  

## 2. Registration

All short-term rentals must be registered with the City and issued a permit number.

Registration requires:

- proof of ownership or a signed authorization from the owner  
- contact information for a local emergency contact available 24/7  
- proof of compliance with fire and building codes  

## 3. Occupancy Limits

Maximum occupancy for STR units is the lower of:

- 2 persons per bedroom plus 2 additional persons, or  
- the limit established by the Fire Marshal  

## 4. Neighborhood Protections

Hosts must:

- provide neighbors with a telephone number to report urgent issues  
- include the permit number in any online listing  
- respect local noise and parking bylaws  

Repeated complaints may lead to suspension or revocation of the STR permit.

## 5. Taxes and Fees

STR stays are subject to applicable accommodation taxes and fees, which must be remitted to the City according to the established schedule.

## 6. Enforcement

The City may:

- issue fines for operating without a permit or in violation of conditions  
- suspend or revoke permits after due process  
- work with online platforms to remove non-compliant listings  

![](aa373480-5272-4186-8ce9-b84e14408f61)

## 7. Evaluation

City staff will report annually to Council on:

- the number of registered STRs  
- complaint volumes  
- impact on housing availability and neighborhoods  

This ordinance may be amended based on those findings.
