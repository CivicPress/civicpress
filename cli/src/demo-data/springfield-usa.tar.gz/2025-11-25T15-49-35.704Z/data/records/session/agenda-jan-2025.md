---
id: "record-1736899200000"
title: 'Agenda – Regular Council Meeting – January 14, 2025'
type: session
status: published

author: "admin"
authors:
  - name: 'City Clerk'
    username: 'admin'
    role: 'clerk'

created: "2025-01-07T10:00:00Z"
updated: "2025-01-10T14:30:00Z"

tags: ['agenda', 'council', 'january-2025']
module: legal-register
slug: 'agenda-jan-2025'
version: "1.0.0"
session_type: regular
date: "2025-01-14T19:00:00Z"
location: "Springfield City Hall, Council Chamber"

attached_files:
  - id: "5c8a32a8-6914-4cf4-af2b-230f121cba9a"
    path: "public/pexels-hberganza-32266769.5c8a32a8-6914-4cf4-af2b-230f121cba9a.jpg"
    original_name: "pexels-hberganza-32266769.jpg"
    description: "IMAGE"
    category: "Reference"
---

# Agenda – Regular Council Meeting

**Date:** Tuesday, 14 January 2025  
**Time:** 7:00 p.m.  
**Location:** Springfield City Hall, Council Chamber

![](5c8a32a8-6914-4cf4-af2b-230f121cba9a)

## 1. Call to Order

- 1.1 Adoption of the agenda  
- 1.2 Approval of minutes from the 10 December 2024 meeting  

## 2. Public Participation

- 2.1 Comments from the public (limited to 5 minutes per speaker)  

## 3. Reports

- 3.1 Report from the Finance Committee – Budget 2025 update  
- 3.2 Report from Public Works – Winter operations status  

## 4. Bylaws and Ordinances

- 4.1 First reading – Short-Term Rental Regulation Ordinance  
- 4.2 Second reading – Snow Removal and Winter Parking Ordinance  

## 5. Resolutions

- 5.1 Climate Action Resolution  
- 5.2 Infrastructure Investment Resolution  

## 6. New Business

- 6.1 Downtown Revitalization Plan – Consultation schedule  

## 7. Adjournment

The next regular meeting of Council is scheduled for 11 February 2025.
