---
id: "record-1736899200001"
title: 'Minutes – Regular Council Meeting – January 14, 2025'
type: session
status: published

author: "admin"
authors:
  - name: 'City Clerk'
    username: 'admin'
    role: 'clerk'

created: "2025-01-15T10:00:00Z"
updated: "2025-01-18T14:30:00Z"

tags: ['minutes', 'council', 'january-2025']
module: legal-register
slug: 'minutes-jan-2025'
version: "1.0.0"
session_type: regular
date: "2025-01-14T19:00:00Z"
location: "Springfield City Hall, Council Chamber"
---

# Minutes – Regular Council Meeting

**Date:** Tuesday, 14 January 2025  
**Time:** 7:00 p.m.  
**Location:** Springfield City Hall, Council Chamber  


## 1. Call to Order

The meeting was called to order at 7:02 p.m. by Mayor Smith.  

Council members present: Councillors Allen, Brooks, Chen, Morales, and Patel.  
Regrets: Councillor Rivera.  

The agenda was adopted without amendment.  
The minutes of the 10 December 2024 meeting were approved as presented.

## 2. Public Participation

Three residents addressed Council regarding winter parking rules and sidewalk snow clearing.  
Council requested that staff prepare a communication campaign to clarify responsibilities.

## 3. Reports

### 3.1 Finance Committee – Budget 2025 Update

The Chair of the Finance Committee presented an update on the draft 2025 budget. No formal decisions were made at this time.

### 3.2 Public Works – Winter Operations Status

Public Works reported that salt and sand inventories were adequate and that response times were within established service levels.

## 4. Bylaws and Ordinances

### 4.1 First Reading – Short-Term Rental Regulation Ordinance

Council gave first reading to the Short-Term Rental Regulation Ordinance.  
A public hearing will be scheduled prior to final adoption.

### 4.2 Second Reading – Snow Removal and Winter Parking Ordinance

Council adopted the Snow Removal and Winter Parking Ordinance on second reading. The ordinance will take effect on 1 December 2025.

## 5. Resolutions

### 5.1 Climate Action Resolution

Following discussion, Council adopted the Climate Action Resolution unanimously.

### 5.2 Infrastructure Investment Resolution

Council adopted the Infrastructure Investment Resolution with one abstention.

## 6. New Business

### 6.1 Downtown Revitalization Plan – Consultation Schedule

Staff presented a proposed timeline for public consultation. Council directed staff to finalize details and report back at the next regular meeting.

## 7. Adjournment

The meeting was adjourned at 9:18 p.m.
