---
id: council-meeting-january-2025
title: City Council Meeting - January 2025
type: session
status: under_review

author: janderson
authors:
  - name: Mayor James Anderson
    username: janderson
    role: mayor
  - name: City Clerk Patricia Martinez
    username: pmartinez
    role: clerk

created: 2025-11-24T22:24:03.000Z
updated: 2025-11-25T13:20:10.649Z

tags:
  - council
  - meeting
  - minutes
  - "2025"
  - january
module: legal-register
slug: council-meeting-january-2025
version: 1.0.0

source:
  reference: file-sync

session_type: regular
date: 2025-01-15T18:00:00.000Z

metadata:
  metadata:
    file_path: session/session-council-meeting-january-2025.md
    author: janderson
    authorId: admin
    authorName: Mayor James Anderson
    created: 2025-01-15T18:00:00.000Z
    updated: 2025-01-16T10:30:00.000Z
  file_path: session/session-council-meeting-january-2025.md

---

# City Council Meeting - January 2025

## Meeting Information

**Date**: January 15, 2025  
**Time**: 6:00 PM  
**Location**: City Hall Council Chambers  
**Meeting Type**: Regular Session

## Attendance

### Present
- Mayor James Anderson
- Council Member Maria Garcia
- Council Member Thomas Lee
- Council Member Robert Wilson
- Council Member David Wilson

### Absent
- Council Member Sarah Johnson (excused)

### Staff Present
- City Manager Michael Chen
- City Attorney Jennifer Green
- City Clerk Patricia Martinez
- Finance Director Lisa Thompson

## Call to Order

Mayor Anderson called the meeting to order at 6:02 PM.

## Approval of Agenda

Motion by Council Member Garcia, seconded by Council Member Lee, to approve the agenda as presented. Motion carried unanimously.

## Public Comment Period

### Public Comments Received
- John Smith - Spoke regarding downtown parking concerns
- Mary Johnson - Expressed support for the new park project
- Robert Brown - Raised questions about property tax assessment

## Old Business

### Item 1: Downtown Revitalization Project Update

City Manager Chen provided an update on the downtown revitalization project. Phase 1 is 75% complete with expected completion in March 2025.

**Action**: No action required. Update received and filed.

### Item 2: Water Treatment Plant Upgrade

Discussion regarding the water treatment plant upgrade project. Council reviewed contractor proposals and discussed funding options.

**Motion**: Council Member Wilson moved to approve the contract with ABC Construction Company for $1,800,000, subject to final review by the city attorney.

**Second**: Council Member Garcia

**Vote**: 4-0 in favor (Council Member Johnson absent)

**Action**: Motion carried.

## New Business

### Item 3: Proposed Noise Ordinance Amendment

First reading of proposed amendment to the noise ordinance regarding construction hours.

**Discussion**: Council discussed extending construction hours from 7:00 AM to 8:00 PM on weekdays to accommodate larger projects.

**Action**: Referred to Planning Commission for review and recommendation. Public hearing scheduled for February 12, 2025.

### Item 4: Budget Adjustment - Emergency Services

Request for budget adjustment to fund additional emergency services equipment.

**Motion**: Council Member Lee moved to approve budget adjustment of $150,000 for emergency services equipment.

**Second**: Council Member Wilson

**Vote**: 5-0 in favor

**Action**: Motion carried.

### Item 5: Appointment to Planning Commission

Mayor Anderson nominated Jane Doe to fill the vacant Planning Commission position.

**Motion**: Council Member Garcia moved to approve the appointment of Jane Doe to the Planning Commission.

**Second**: Council Member Lee

**Vote**: 5-0 in favor

**Action**: Motion carried.

## Executive Session

The council entered executive session at 7:45 PM to discuss personnel matters. The council reconvened at 8:15 PM.

## Adjournment

Motion by Council Member Garcia, seconded by Council Member Lee, to adjourn the meeting. Motion carried. Meeting adjourned at 8:20 PM.

## Next Meeting

The next regular council meeting is scheduled for February 12, 2025 at 6:00 PM.

---

**Prepared by**: City Clerk Patricia Martinez  
**Status**: Under Review - Awaiting final approval from Mayor  
**Distribution**: Council Members, Department Heads, Public Records