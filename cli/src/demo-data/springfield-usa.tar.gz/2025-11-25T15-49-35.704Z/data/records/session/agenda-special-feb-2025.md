---
id: "record-1738627200000"
title: 'Agenda – Special Council Meeting – February 4, 2025'
type: session
status: published

author: "admin"
authors:
  - name: 'City Clerk'
    username: 'admin'
    role: 'clerk'

created: "2025-01-28T10:00:00Z"
updated: "2025-01-30T14:30:00Z"

tags: ['agenda', 'special-meeting', 'council']
module: legal-register
slug: 'agenda-special-feb-2025'
version: "1.0.0"
session_type: special
date: "2025-02-04T18:00:00Z"
location: "Springfield City Hall, Council Chamber"

attached_files:
  - id: "a7f4db9d-b823-4e14-b10f-f5400a1fd885"
    path: "public/pexels-artempodrez-6823618.a7f4db9d-b823-4e14-b10f-f5400a1fd885.jpg"
    original_name: "pexels-artempodrez-6823618.jpg"
    description: "IMAGE"
    category: "Reference"
---

# Agenda – Special Council Meeting

**Date:** Tuesday, 4 February 2025  
**Time:** 6:00 p.m.  
**Location:** Springfield City Hall, Council Chamber

![](a7f4db9d-b823-4e14-b10f-f5400a1fd885)

## 1. Call to Order

- 1.1 Adoption of the agenda  

## 2. Public Hearing – Short-Term Rental Regulation Ordinance

- 2.1 Presentation by the Planning Department  
- 2.2 Comments from the public  
- 2.3 Council questions and discussion  

## 3. Consideration of Third Reading and Adoption

- 3.1 Short-Term Rental Regulation Ordinance – third reading and adoption  

## 4. Adjournment
