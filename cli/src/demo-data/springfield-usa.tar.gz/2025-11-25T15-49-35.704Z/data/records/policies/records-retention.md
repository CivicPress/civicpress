---
id: "record-1715299200000"
title: 'Records Retention and Archiving Policy'
type: policy
status: published

author: "admin"
authors:
  - name: 'City Clerk'
    username: 'admin'
    role: 'clerk'

created: "2024-05-10T10:00:00Z"
updated: "2025-01-13T14:30:00Z"

tags: ['records', 'archiving', 'retention', 'governance']
module: legal-register
slug: 'records-retention'
version: "1.0.0"

attached_files:
  - id: "94d24352-8ed6-47f1-80f2-6257824abb66"
    path: "public/nolan-krattinger-TqiXCgnTYGk-unsplash.94d24352-8ed6-47f1-80f2-6257824abb66.jpg"
    original_name: "nolan-krattinger-TqiXCgnTYGk-unsplash.jpg"
    description: "IMAGE"
    category: "Reference"
  - id: "aa625717-2d61-48b8-a02e-8030d30a5441"
    path: "public/justin-morgan-ZjX-z2Q5zrk-unsplash.aa625717-2d61-48b8-a02e-8030d30a5441.jpg"
    original_name: "justin-morgan-ZjX-z2Q5zrk-unsplash.jpg"
    description: "IMAGE"
    category: "Reference"
---

# Records Retention and Archiving Policy

This policy describes how long the City of Springfield retains its records and how they are archived or disposed of.

![](94d24352-8ed6-47f1-80f2-6257824abb66)

## 1. Purpose

To ensure that:

- legal obligations are met  
- historical and civic memory is preserved  
- information is available when needed for operations and accountability  

## 2. Retention Schedules

Different types of records have different retention periods:

- Council minutes and bylaws: permanent  
- Financial statements: minimum of 7 years  
- Routine correspondence: 2 to 5 years depending on topic  

Detailed schedules are maintained by the City Clerk’s Office.

## 3. Formats and Preservation

Records may be stored:

- on paper  
- in digital formats with appropriate backups  

Permanent records must be preserved in open or widely supported formats whenever possible.

## 4. Disposal and Destruction

When records reach the end of their retention period:

- they must be reviewed to confirm eligibility for destruction  
- confidential records must be destroyed securely  

A log is kept of all records destroyed.

## 5. Access and Transparency

Retention and archiving support public access:

- residents can request older records through established access to information procedures  
- key records (bylaws, budgets, minutes) are proactively published on the city’s website  

![](aa625717-2d61-48b8-a02e-8030d30a5441)
