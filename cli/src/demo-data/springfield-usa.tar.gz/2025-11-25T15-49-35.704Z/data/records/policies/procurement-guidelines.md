---
id: "record-1717200000000"
title: 'Procurement Guidelines Policy'
type: policy
status: published

author: "admin"
authors:
  - name: 'City Clerk'
    username: 'admin'
    role: 'clerk'

created: "2024-06-01T10:00:00Z"
updated: "2025-01-11T14:30:00Z"

tags: ['procurement', 'contracts', 'transparency', 'finance']
module: legal-register
slug: 'procurement-guidelines'
version: "1.0.0"

attached_files:
  - id: "8f681044-e570-4be0-bd07-064e1533e231"
    path: "public/pexels-cottonbro-5990036.8f681044-e570-4be0-bd07-064e1533e231.jpg"
    original_name: "pexels-cottonbro-5990036.jpg"
    description: "IMAGE"
    category: "Reference"
  - id: "6db9eb93-d107-405e-abce-ed4e6b056e2b"
    path: "public/patrick-hendry-RKRya8iWBnc-unsplash.6db9eb93-d107-405e-abce-ed4e6b056e2b.jpg"
    original_name: "patrick-hendry-RKRya8iWBnc-unsplash.jpg"
    description: "IMAGE"
    category: "Reference"
---

# Procurement Guidelines Policy

This policy defines how the City of Springfield purchases goods and services in a fair, transparent, and efficient manner.

![](8f681044-e570-4be0-bd07-064e1533e231)

## 1. Principles

All procurement activities must:

- obtain best value for taxpayers  
- be fair, open, and transparent  
- support local and regional suppliers where possible  

## 2. Thresholds and Methods

Depending on the value of the contract:

- Under 10,000 USD: direct purchase with at least one written quote  
- 10,000 to 100,000 USD: at least three written quotes  
- Over 100,000 USD: formal public tender or request for proposals (RFP)  

## 3. Conflict of Interest

Employees and elected officials must declare and avoid conflicts of interest at all stages of procurement.  

No person involved in procurement may:

- accept gifts or favors from potential suppliers  
- participate in decisions where they have a personal interest  

## 4. Documentation

Each procurement process must be documented sufficiently to allow for audit and public disclosure where appropriate.

## 5. Sustainability and Social Considerations

Where relevant, evaluation criteria may include:

- environmental impact  
- community benefits  
- supplier diversity  

![](6db9eb93-d107-405e-abce-ed4e6b056e2b)

## 6. Review Cycle

This policy is reviewed at least every three years or sooner if legislation or best practices evolve.
