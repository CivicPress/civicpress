---
id: "record-1720137600000"
title: 'Signage and Outdoor Advertising Bylaw'
type: bylaw
status: published

author: "admin"
authors:
  - name: 'City Clerk'
    username: 'admin'
    role: 'clerk'

created: "2024-07-05T10:00:00Z"
updated: "2025-01-09T14:30:00Z"

tags: ['signage', 'advertising', 'urban-design', 'business']
module: legal-register
slug: 'signage-advertising'
version: "1.0.0"

attached_files:
  - id: "087e46b3-5aa1-4321-bdb4-e93c20abd9de"
    path: "public/anil-baki-durmus-mNQxHBFOAjA-unsplash.087e46b3-5aa1-4321-bdb4-e93c20abd9de.jpg"
    original_name: "anil-baki-durmus-mNQxHBFOAjA-unsplash.jpg"
    description: "IMAGE"
    category: "Reference"
  - id: "2057d04d-d772-430a-bba8-7cd97f6c3090"
    path: "public/marco-d-abramo-LCTWDRz7BjQ-unsplash.2057d04d-d772-430a-bba8-7cd97f6c3090.jpg"
    original_name: "marco-d-abramo-LCTWDRz7BjQ-unsplash.jpg"
    description: "IMAGE"
    category: "Reference"
---

# Signage and Outdoor Advertising Bylaw

This bylaw regulates signage and outdoor advertising in Springfield to support safety, accessibility, and a visually coherent public realm.

![](087e46b3-5aa1-4321-bdb4-e93c20abd9de)

## 1. Objectives

The objectives of this bylaw are to:

- prevent visual clutter  
- protect sightlines and traffic safety  
- support accessible wayfinding for residents and visitors  

## 2. Sign Types

Common sign types include:

- wall-mounted signs  
- freestanding signs  
- window decals  
- temporary event banners  

Each sign type has specific size, placement, and illumination rules.

## 3. Permits

Most permanent signs require a sign permit.

Applicants must provide:

- a scaled drawing of the proposed sign  
- materials and lighting details  
- location relative to property lines and sidewalks  

## 4. Prohibited Signs

The following signs are prohibited:

- flashing or strobe-light signs visible from public streets  
- signs that mimic traffic signals or official road signs  
- rooftop billboards in residential zones  

## 5. Heritage and Downtown Areas

Stricter rules apply in designated heritage and downtown districts to preserve architectural character.

![](2057d04d-d772-430a-bba8-7cd97f6c3090)

## 6. Enforcement

Violations may result in:

- written notice to remove or modify the sign  
- removal by the City at the owner’s expense if non-compliance persists  
- fines for repeated offences  

The City may also refuse new applications from owners with unresolved violations.
