---
id: building-codes
title: Building Codes
type: bylaw
status: published

author: drodriguez
authors:
  - name: David Rodriguez
    username: drodriguez
    role: building-inspector
  - name: Lisa Thompson
    username: lthompson
    role: council

created: 2025-11-24T22:24:03.000Z
updated: 2025-11-25T13:20:09.381Z

tags:
  - building
  - construction
  - safety
  - codes
module: legal-register
slug: building-codes
version: 1.0.0
priority: low
department: Building & Planning

source:
  reference: file-sync

linked_records:
  - id: record-1710460800000
    type: bylaw
    description: Zoning code that defines land use requirements for building construction
    category: references

metadata:
  metadata:
    file_path: bylaws/bylaw-building-codes.md
    author: drodriguez
    authorId: admin
    authorName: David Rodriguez
    created: 2024-01-10T09:00:00.000Z
    updated: 2024-11-15T16:45:00.000Z
    metadata:
      document_number: BYL-2024-001
      effective_date: 2024-01-10T09:00:00.000Z
      approval_date: 2024-01-10T09:00:00.000Z
      public_access: true
      classification: public
      legal_authority: Building Code Act, Section 5; Municipal Building Authority
      review_date: 2025-01-10T09:00:00.000Z
      approval_chain:
        - role: building-inspector
          username: drodriguez
          action: drafted
          date: 2024-01-05T10:00:00.000Z
        - role: council
          username: lthompson
          action: approved
          date: 2024-01-10T09:00:00.000Z
  file_path: bylaws/bylaw-building-codes.md

---

# Building Codes

## Section 1: Adoption of International Codes

The City of Springfield hereby adopts the following International Codes as
amended:

- International Building Code (IBC) 2021
- International Residential Code (IRC) 2021
- International Mechanical Code (IMC) 2021
- International Plumbing Code (IPC) 2021
- International Electrical Code (IEC) 2021

## Section 2: Building Permits

### 2.1 Permit Required

No person shall construct, alter, repair, or demolish any building or structure
without first obtaining a building permit.

### 2.2 Application Requirements

Building permit applications shall include:

- Completed application form
- Site plan showing property lines and building location
- Construction drawings and specifications
- Payment of applicable fees

### 2.3 Permit Fees

Building permit fees shall be calculated based on construction value:

- $0-$10,000: $150
- $10,001-$50,000: $300
- $50,001-$100,000: $500
- Over $100,000: $750 + $2 per $1,000 over $100,000

## Section 3: Inspections

### 3.1 Required Inspections

The following inspections are required:

- Foundation inspection
- Framing inspection
- Electrical inspection
- Plumbing inspection
- Final inspection

### 3.2 Inspection Scheduling

Inspections must be scheduled at least 24 hours in advance.

## Section 4: Violations and Penalties

### 4.1 Stop Work Orders

The building official may issue stop work orders for violations.

### 4.2 Penalties

Violations may result in fines up to $500 per day and legal action.

## Section 5: Appeals

Appeals of building official decisions may be made to the Building Code Board of
Appeals.