---
id: "record-1723248000000"
title: 'Building Safety Bylaw'
type: bylaw
status: published

author: "admin"
authors:
  - name: 'City Clerk'
    username: 'admin'
    role: 'clerk'

created: "2024-08-10T10:00:00Z"
updated: "2025-01-08T14:30:00Z"

tags: ['building', 'code', 'inspections', 'safety']
module: legal-register
slug: 'building-safety'
version: "1.0.0"

attached_files:
  - id: "4da407dd-f96f-4bf2-a102-c5af4a360ced"
    path: "public/narno-beats-VylFceArtLI-unsplash.4da407dd-f96f-4bf2-a102-c5af4a360ced.jpg"
    original_name: "narno-beats-VylFceArtLI-unsplash.jpg"
    description: "IMAGE"
    category: "Reference"
  - id: "9c3b1e9b-ccd5-4f9f-880d-6354707defb9"
    path: "public/amsterdam-city-archives-1hSh1aDG6Mg-unsplash.9c3b1e9b-ccd5-4f9f-880d-6354707defb9.jpg"
    original_name: "amsterdam-city-archives-1hSh1aDG6Mg-unsplash.jpg"
    description: "IMAGE"
    category: "Reference"
---

# Building Safety Bylaw

The Building Safety Bylaw establishes minimum standards for the construction, maintenance, and occupancy of buildings within Springfield.

![](4da407dd-f96f-4bf2-a102-c5af4a360ced)

## 1. Scope

This bylaw applies to:

- all new construction  
- major renovations  
- changes of use in existing buildings  

## 2. Permit Requirements

No construction or major alteration may commence without a valid building permit issued by the City.

Applicants must submit:

- complete plans and specifications  
- structural calculations where required  
- proof of contractor licensing where applicable  

## 3. Inspections

The City’s Building Inspection Division conducts inspections at key stages:

1. Foundation  
2. Framing  
3. Mechanical and electrical rough-in  
4. Final occupancy inspection  

Inspections must be booked at least 48 hours in advance.

## 4. Unsafe Buildings

A building may be declared unsafe if it:

- is structurally unsound  
- poses fire or health risks  
- has been severely damaged by disaster  

In such cases, the City may:

- order immediate evacuation  
- secure the property  
- require remedial work or demolition  

![](9c3b1e9b-ccd5-4f9f-880d-6354707defb9)

## 5. Compliance and Penalties

Failure to comply with this bylaw may result in:

- stop-work orders  
- fines  
- refusal of future permits until compliance is restored  

## 6. Relationship to Other Codes

This bylaw is interpreted in harmony with applicable state and federal building codes. Where conflicts arise, the more stringent standard applies.
