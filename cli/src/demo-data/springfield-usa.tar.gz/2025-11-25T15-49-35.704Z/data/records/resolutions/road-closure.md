---
id: "record-1738368000000"
title: 'Public Notice – Temporary Road Closure on Main Street'
type: resolution
status: published

author: "admin"
authors:
  - name: 'Public Works Department'
    username: 'admin'
    role: 'public-works'

created: "2025-02-01T10:00:00Z"
updated: "2025-02-01T10:00:00Z"

tags: ['road-closure', 'construction', 'detour', 'transportation']
module: legal-register
slug: 'road-closure'
version: "1.0.0"

attached_files:
  - id: "e618c705-a16c-4074-9f83-47650240600d"
    path: "public/john-melara-xYpzRcwcdUI-unsplash.e618c705-a16c-4074-9f83-47650240600d.jpg"
    original_name: "john-melara-xYpzRcwcdUI-unsplash.jpg"
    description: "IMAGE"
    category: "Reference"
---

# Public Notice – Temporary Road Closure on Main Street

The City of Springfield advises residents and businesses of a temporary road closure on **Main Street** between 3rd Avenue and 5th Avenue.

![](e618c705-a16c-4074-9f83-47650240600d)

## Dates and Times

- Start: Monday, 17 February 2025, at 7:00 a.m.  
- End: Friday, 21 February 2025, at 6:00 p.m.  

## Reason for Closure

The closure is required to:

- replace aging water mains  
- upgrade underground utilities  
- repave the street surface  

## Detours

Signed detours will direct traffic via:

- Elm Street for east–west travel  
- 2nd Avenue for north–south connections  

Pedestrian access to sidewalks and local businesses will be maintained whenever possible.

## Contact

Questions can be directed to the Public Works Department at 555-0100 or via the City’s website contact form.
