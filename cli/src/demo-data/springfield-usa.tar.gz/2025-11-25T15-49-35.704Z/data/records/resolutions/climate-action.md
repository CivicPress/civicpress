---
id: "record-1726790400000"
title: 'Climate Action Resolution'
type: resolution
status: published

author: "admin"
authors:
  - name: 'City Council'
    username: 'admin'
    role: 'council'

created: "2024-09-20T10:00:00Z"
updated: "2025-01-16T14:30:00Z"

tags: ['climate', 'sustainability', 'greenhouse-gas-emissions', 'environment']
module: legal-register
slug: 'climate-action'
version: "1.0.0"

attached_files:
  - id: "53fcb379-24bc-43a7-aa92-bdffb8748da1"
    path: "public/kenny-u9o5g98pUq0-unsplash.53fcb379-24bc-43a7-aa92-bdffb8748da1.jpg"
    original_name: "kenny-u9o5g98pUq0-unsplash.jpg"
    description: "IMAGE"
    category: "Reference"
---

# Climate Action Resolution

The City Council of Springfield recognizes that climate change poses a direct risk to the health, safety, and prosperity of its residents.

![](53fcb379-24bc-43a7-aa92-bdffb8748da1)

## 1. Acknowledgment

Council acknowledges that:

- Springfield experiences more frequent extreme weather events  
- vulnerable residents are disproportionately affected  
- local governments play a key role in mitigation and adaptation  

## 2. Commitments

Through this resolution, Council commits to:

- develop a Climate Action Plan within 18 months  
- set interim and long-term emissions reduction targets  
- prioritize active and public transportation  
- improve energy efficiency in municipal buildings  

## 3. Reporting

City staff must report annually on:

- progress toward emissions targets  
- key actions taken  
- funding and partnership opportunities  

Adopted by Council at its regular meeting held on 16 January 2025.
