---
id: "record-1737417600000"
title: 'Public Consultation Notice – Downtown Revitalization Plan'
type: resolution
status: published

author: "admin"
authors:
  - name: 'Planning Department'
    username: 'admin'
    role: 'planning'

created: "2025-01-20T10:00:00Z"
updated: "2025-01-20T10:00:00Z"

tags: ['public-consultation', 'downtown', 'planning', 'participation']
module: legal-register
slug: 'public-consultation'
version: "1.0.0"

attached_files:
  - id: "2d043027-3a7c-4ce3-86ad-752ad0cb6a3f"
    path: "public/chris-mok-cr-mok-28RYY9I9zAI-unsplash.2d043027-3a7c-4ce3-86ad-752ad0cb6a3f.jpg"
    original_name: "chris-mok-cr-mok-28RYY9I9zAI-unsplash.jpg"
    description: "IMAGE"
    category: "Reference"
---

# Public Consultation Notice – Downtown Revitalization Plan

The City of Springfield invites residents, businesses, and community organizations to participate in a public consultation on the **Downtown Revitalization Plan**.

![](2d043027-3a7c-4ce3-86ad-752ad0cb6a3f)

## Meeting Details

- Date: Wednesday, 26 February 2025  
- Time: 6:30 p.m. to 8:30 p.m.  
- Location: Springfield Community Center, Main Hall  

## Purpose

The consultation will:

- present draft concepts for public spaces and streets  
- share proposed changes to zoning and land use  
- gather feedback on mobility, accessibility, and public amenities  

## Ways to Participate

Residents can:

- attend the in-person meeting  
- submit written comments through the City’s website  
- respond to an online survey open for three weeks after the meeting  

All feedback will inform the final Downtown Revitalization Plan, to be presented to Council later in 2025.
