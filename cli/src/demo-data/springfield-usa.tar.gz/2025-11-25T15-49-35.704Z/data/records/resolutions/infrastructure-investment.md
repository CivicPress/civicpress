---
id: "record-1728086400000"
title: 'Infrastructure Investment Resolution'
type: resolution
status: published

author: "admin"
authors:
  - name: 'City Council'
    username: 'admin'
    role: 'council'

created: "2024-10-05T10:00:00Z"
updated: "2025-01-17T14:30:00Z"

tags: ['infrastructure', 'capital-plan', 'funding', 'finance']
module: legal-register
slug: 'infrastructure-investment'
version: "1.0.0"

attached_files:
  - id: "a4030ae2-642b-4944-bf6d-97c614f4e602"
    path: "public/ava-tyler-gqd7_Tx5jLQ-unsplash.a4030ae2-642b-4944-bf6d-97c614f4e602.jpg"
    original_name: "ava-tyler-gqd7_Tx5jLQ-unsplash.jpg"
    description: "IMAGE"
    category: "Reference"
---

# Infrastructure Investment Resolution

This resolution establishes priorities for the City of Springfield's multi-year capital investment plan.

![](a4030ae2-642b-4944-bf6d-97c614f4e602)

## 1. Strategic Priorities

Investment will focus on:

- maintaining and renewing existing infrastructure  
- improving road safety and accessibility  
- upgrading water and wastewater systems  
- supporting climate-resilient projects  

## 2. Funding Principles

Projects should:

- leverage external funding where possible  
- align with community needs and master plans  
- consider life-cycle costs, not just initial expenses  

## 3. Public Reporting

Each year, the City will publish:

- a list of approved capital projects  
- budgeted and actual expenditures  
- project status updates  

This information will be accessible through the City’s online open data portal and in the annual budget documents.
