---
id: "record-1741132800000"
title: 'Public Notice – Planned Water Service Interruption'
type: resolution
status: published

author: "admin"
authors:
  - name: 'Public Works Department'
    username: 'admin'
    role: 'public-works'

created: "2025-03-05T10:00:00Z"
updated: "2025-03-05T10:00:00Z"

tags: ['water-service', 'maintenance', 'outage', 'utilities']
module: legal-register
slug: 'water-interruption'
version: "1.0.0"

attached_files:
  - id: "c4d1d047-54a3-469e-ab31-027650d250ce"
    path: "public/diosming--HrFx4pmeQc-unsplash.c4d1d047-54a3-469e-ab31-027650d250ce.jpg"
    original_name: "diosming--HrFx4pmeQc-unsplash.jpg"
    description: "IMAGE"
    category: "Reference"
---

# Public Notice – Planned Water Service Interruption

The City of Springfield will conduct maintenance on the water distribution system affecting certain properties in the Eastside neighborhood.

![](c4d1d047-54a3-469e-ab31-027650d250ce)

## Service Interruption Details

- Date: Thursday, 20 March 2025  
- Time: Approximately 9:00 a.m. to 3:00 p.m.  
- Affected Area: Addresses on Oak Street between 10th and 14th Avenue  

Residents may experience:

- loss of water pressure  
- temporary discoloration after service resumes  

## Recommendations

Residents are advised to:

- store sufficient water for essential needs in advance  
- avoid using dishwashers and washing machines during the interruption  
- run cold water taps for a few minutes after service resumes  

## Contact

For more information, contact the Water Services division at 555-0123 or consult the notice on the City website.
