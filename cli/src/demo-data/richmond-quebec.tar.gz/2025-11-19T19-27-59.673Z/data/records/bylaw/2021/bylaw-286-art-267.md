---
id: bylaw-286-art-267
title: Article 267 - Normes de garde d’un animal
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:09.144Z

module: public-bylaws
slug: bylaw-286-art-267

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-11
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-266
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-268
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-267.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 267
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE XI - LES ANIMAUX
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-267.md

---

# Article 267 - Normes de garde d’un animal

Sur le terrain sur lequel est située l’unité d’occupation du gardien ou sur tout autre terrain privé où il se trouve avec l’autorisation du propriétaire ou de l’occupant de ce terrain, tout animal, à l’exception des chats qui peuvent circuler librement, doit être gardé, selon le cas :

1) dans un bâtiment d’où il ne peut sortir;
2) sur un terrain sous le contrôle direct du gardien. Celui-ci doit avoir une maîtrise constante de l’animal;
3) sur un terrain clôturé de manière à contenir l’animal à l’intérieur des limites de celui-ci;
4) dans un enclos extérieur aménagé conformément à l’article 258 du présent règlement;
5) au moyen d’un dispositif de contention d’empêchant de sortir lorsque le terrain n’est pas clôturé.

Le gardien doit prendre toutes les mesures nécessaires pour s’assurer que la ou les normes de garde qu’il privilégie sont efficaces et qu’ils contiennent l’animal dans l’unité d’occupation du gardien eu égard à la race, à l’âge, au poids et aux caractéristiques de l’animal.