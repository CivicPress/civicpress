---
id: bylaw-286-art-306
title: Article 306 - Contre-expertise
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:14.373Z

module: public-bylaws
slug: bylaw-286-art-306

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-11
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-305
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-307
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-306.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 306
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE XI - LES ANIMAUX
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-306.md

---

# Article 306 - Contre-expertise

Le gardien qui désire demander une contre-expertise doit, dans les 72 heures de la
réception de l’avis prévu à l’article 305, aviser par écrit la ville de ses motifs et des nom, coordonnées et qualité du médecin vétérinaire qu’il a mandaté pour procéder, de concert avec le vétérinaire mandaté par la ville, à une seconde évaluation du chien dans un délai maximal de 5 jours afin de déterminer si le niveau de risque pour la santé ou la sécurité publique et, le cas échéant, les recommandations établies dans le premier rapport du médecin vétérinaire sont justifiés eu égard aux circonstances. Pendant ce délai, le gardien de l’animal doit respecter les conditions de garde imposées dans l’avis prévu à l’article 305 ou, si l’euthanasie est ordonnée, il doit respecter les mesures ordonnées par la ville conformément à l’article 298.

Une fois la contre-expertise réalisée, l’une ou l’autre des situations suivantes peut survenir :

1) les médecins vétérinaires confirment le résultat de l’évaluation comportementale initiale et maintiennent la conclusion quant au risque et, le cas échéant, les recommandations du rapport du médecin vétérinaire mandaté par la ville. Les déclarations, ordonnances, mesures ou recommandations de la ville demeurent alors inchangées;
2) les médecins vétérinaires s’entendent sur une autre conclusion quant au risque et aux recommandations, le cas échéant, que celles déjà fournies par le médecin vétérinaire mandaté par la ville et rédigent et contresignent un nouveau rapport. La ville analyse le nouveau rapport et rend les conclusions, ordonnances, mesures ou recommandations appropriées quant au risque du chien en fonction de celui-ci,

conformément aux articles 300 à 304;

3) les médecins vétérinaires ne s’entendent pas sur le résultat de l’évaluation comportementale. La ville décide alors parmi les options suivantes :
a) elle maintient ses déclarations, ordonnances, mesures ou recommandations découlant du rapport initial du médecin vétérinaire qu’elle a mandaté ; ou
b) elle modifie ses déclarations, ordonnances, mesures ou recommandations en fonction du rapport du médecin vétérinaire retenu par le gardien et notifie un nouvel avis au gardien du chien en lui donnant l’ordre de s’y conformer dans le délai prescrit.

Tous les frais rattachés à la garde de l’animal et à la contre-expertise sont à la charge
du gardien de l’animal.