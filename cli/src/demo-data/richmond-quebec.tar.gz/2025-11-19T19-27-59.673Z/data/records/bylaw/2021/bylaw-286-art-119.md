---
id: bylaw-286-art-119
title: Article 119 - Nettoyage
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:41:50.557Z

module: public-bylaws
slug: bylaw-286-art-119

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-04
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-118
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-120
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-119.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 119
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE IV - LA CIRCULATION
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-119.md

---

# Article 119 - Nettoyage

Le conducteur et le propriétaire du véhicule doivent immédiatement nettoyer ou faire nettoyer la chaussée concernée. À défaut, la ville est autorisée à effectuer le nettoyage et les frais leur seront réclamés.