---
id: bylaw-286-art-399
title: Article 399 - Le présent règlement abroge toute disposition antérieure ayant le même objet
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    username: civicpress-ingest
    role: automation

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:26.586Z

module: public-bylaws

source:
  reference: file-sync

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-16
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-398
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-400
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-399.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 399
    chapter: CHAPITRE XVI – ABROGATION
    kind: article
  file_path: bylaw/2021/bylaw-286-art-399.md

---

# Article 399 - Le présent règlement abroge toute disposition antérieure ayant le même objet

contenue dans tout règlement municipal, incompatible ou contraire au présent règlement et plus particulièrement les dispositions contenues dans le règlement numéro 275 de la Ville de Richmond. .


CHAPITRE XVII - ENTRÉE EN VIGUEUR