---
id: bylaw-286-art-174
title: Article 174 - Mineur
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:41:57.360Z

module: public-bylaws
slug: bylaw-286-art-174

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-07
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-173
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-175
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-174.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 174
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE VII - PRÊTEUR SUR GAGE, REGRATTIER ET MARCHAND DE BRIC-À-BRAC
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-174.md

---

# Article 174 - Mineur

Il est interdit à tout regrattier d’acquérir ou de prendre en gage un bien d’une personne âgée de moins de dix-huit (18) ans, à moins que cette dernière ne lui remette une autorisation écrite en forme authentique de son père, sa mère, son tuteur ou son gardien et il doit garder en sa possession ladite autorisation en vue d’en permettre l’examen, en présence du père ou de la mère ou du tuteur ou du gardien, selon le cas.