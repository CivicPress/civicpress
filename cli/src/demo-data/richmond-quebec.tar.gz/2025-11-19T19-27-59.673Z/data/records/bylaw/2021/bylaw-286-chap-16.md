---
id: bylaw-286-chap-16
title: CHAPITRE XVI – ABROGATION
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    username: civicpress-ingest
    role: automation

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:28.929Z

module: public-bylaws

source:
  reference: file-sync

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-399
    type: bylaw
    category: referenced_by
    description: Child record

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-chap-16.md
    created: {}
    year: 2021
    language: fr-CA
    kind: chapter
  file_path: bylaw/2021/bylaw-286-chap-16.md

---

# CHAPITRE XVI – ABROGATION

- [Article 399 - Le présent règlement abroge toute disposition antérieure ayant le même objet](bylaw-286-art-399.md)