---
id: bylaw-286-chap-01
title: CHAPITRE I - DISPOSITIONS DÉCLARATOIRES ET INTERPRÉTATIVES
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:26.868Z

module: public-bylaws
slug: bylaw-286-chap-01

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-001
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-002
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-003
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-004
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-005
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-006
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-007
    type: bylaw
    category: referenced_by
    description: Child record

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-chap-01.md
    created: {}
    year: 2021
    language: fr-CA
    jurisdiction: municipal
    classification: public
    public_access: true
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: chapter
  file_path: bylaw/2021/bylaw-286-chap-01.md

---

# CHAPITRE I - DISPOSITIONS DÉCLARATOIRES ET INTERPRÉTATIVES

- [Article 1 - Titre abrégé](bylaw-286-art-001.md)
- [Article 2 - Territoire assujetti](bylaw-286-art-002.md)
- [Article 3 - Responsabilité de la ville](bylaw-286-art-003.md)
- [Article 4 - Validité](bylaw-286-art-004.md)
- [Article 5 - Titres](bylaw-286-art-005.md)
- [Article 6 - Définitions](bylaw-286-art-006.md)
- [Article 7 - Définitions additionnelles](bylaw-286-art-007.md)