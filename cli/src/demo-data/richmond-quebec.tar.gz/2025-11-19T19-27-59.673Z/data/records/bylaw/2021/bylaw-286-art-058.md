---
id: bylaw-286-art-058
title: Article 58 - Rebuts sur la propriété privée
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:41:43.089Z

module: public-bylaws
slug: bylaw-286-art-058

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-02
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-057
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-059
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-058.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 58
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE II - LES NUISANCES
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-058.md

---

# Article 58 - Rebuts sur la propriété privée

Constitue une nuisance, le fait par le propriétaire, le locataire ou l’occupant de laisser des déchets, des ordures ménagères ou des rebuts s’accumuler à l’intérieur ou autour d’un bâtiment, ou sur un terrain privé incluant l’emprise excédentaire de la voie publique, de façon à nuire au bien-être et au confort d’une ou de plusieurs personnes du voisinage.

Il est défendu de laisser de telles nuisances ou de ne pas prendre tous les moyens nécessaires pour faire disparaître de telles nuisances en contravention du présent article.

Lorsque le propriétaire, le locataire ou l’occupant est déclaré coupable de l’infraction, le tribunal peut, en sus des amendes et des frais, ordonner que les nuisances qui ont fait l’objet de l’infraction soient enlevées, dans le délai qu’il fixe, par le propriétaire, le locataire ou l’occupant et qu’à défaut par cette ou ces personnes de s’exécuter dans le délai, les nuisances soient enlevées par la ville aux frais de cette ou de ces personnes.