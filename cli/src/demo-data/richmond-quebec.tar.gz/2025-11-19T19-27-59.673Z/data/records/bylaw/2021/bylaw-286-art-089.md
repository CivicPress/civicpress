---
id: bylaw-286-art-089
title: Article 89 - Stationnement des personnes handicapées
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:41:46.875Z

module: public-bylaws
slug: bylaw-286-art-089

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-03
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-088
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-090
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-089.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 89
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE III – LE STATIONNEMENT
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-089.md

---

# Article 89 - Stationnement des personnes handicapées

Nul ne peut immobiliser un véhicule routier dans un espace de stationnement réservé à l'usage exclusif des personnes handicapées et identifié au moyen d’une signalisation conforme aux normes établies par le ministre des Transports, à moins que ce véhicule ne soit muni :

1) d'une vignette d'identification délivrée conformément à l'article 11 du Code de la sécurité routière (L.R.Q., c. C-24.2) au nom du conducteur, d’une personne qui l’accompagne ou de l’établissement pour lequel il agit et placée à l’endroit déterminé par un règlement du gouvernement;
2) d’une vignette, d’une plaque ou d’un permis affichant le symbole international de fauteuil roulant délivré par une autre autorité administrative au Canada ou par un pays membre ou associé de la Conférence européenne des ministres des Transports.

En outre des chemins publics, le présent article s'applique sur les chemins privés ouverts à la circulation publique des véhicules routiers ainsi que sur les terrains des centres commerciaux et autres terrains où le public est autorisé à circuler.