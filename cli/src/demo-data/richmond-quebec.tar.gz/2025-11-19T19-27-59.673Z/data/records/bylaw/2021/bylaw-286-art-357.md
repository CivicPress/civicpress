---
id: bylaw-286-art-357
title: Article 357 - Accès interdit
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:21.010Z

module: public-bylaws
slug: bylaw-286-art-357

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-13
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-356
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-358
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-357.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 357
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE XIII - SALLES DE DANSE PUBLIQUES POUR ADOLESCENTS
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-357.md

---

# Article 357 - Accès interdit

Il est défendu à toute personne autre qu'un adolescent d'avoir accès, d'être admis ou de séjourner dans une salle de danse pour adolescents à l'exception des gardiens ou toute personne en charge de l'organisation ou du maintien de l'ordre.