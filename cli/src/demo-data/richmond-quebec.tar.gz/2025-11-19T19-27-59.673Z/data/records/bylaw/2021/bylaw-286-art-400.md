---
id: bylaw-286-art-400
title: Article 400
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:26.729Z

module: public-bylaws
slug: bylaw-286-art-400

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-17
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-398
    type: bylaw
    category: follows
    description: Previous record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-400.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 400
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE XVII - ENTRÉE EN VIGUEUR
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-400.md

---

# Article 400

Le présent règlement entre en vigueur conformément à la Loi.






ADOPTÉ À RICHMOND (QUÉBEC) Ce 15e jour de mars deux mille vingt-et-un (2021).

MAIRE

DIRECTEUR GÉNÉRAL ET SECRÉTAIRE-TRÉSORIER

Je, Rémi-Mario Mayette, directeur général et secrétaire-trésorier de la ville de Richmond, certifie, par la présente, que le présent règlement est une vraie copie de l’original passé à la date ci-haut mentionnée. L’original étant gardé au Bureau de la ville.

Rémi-Mario Mayette, OMA directeur général et secrétaire-trésorier