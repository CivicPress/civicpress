---
id: bylaw-286-art-066
title: Article 66 - Appel 9-1-1 sans urgence
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:41:44.062Z

module: public-bylaws
slug: bylaw-286-art-066

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-02
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-065
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-067
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-066.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 66
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE II - LES NUISANCES
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-066.md

---

# Article 66 - Appel 9-1-1 sans urgence

Il est défendu de provoquer par son comportement, un appel au 9-1-1 pour un évènement futile ou ne nécessitant pas un déplacement des services d’urgence ou ayant nécessité un déplacement des services d’urgence inutile.