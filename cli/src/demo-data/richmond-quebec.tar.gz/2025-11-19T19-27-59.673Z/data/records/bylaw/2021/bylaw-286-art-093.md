---
id: bylaw-286-art-093
title: Article 93 - Espaces de stationnement réservés aux véhicules électriques
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:41:47.366Z

module: public-bylaws
slug: bylaw-286-art-093

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-03
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-092
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-094
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-093.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 93
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE III – LE STATIONNEMENT
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-093.md

---

# Article 93 - Espaces de stationnement réservés aux véhicules électriques

Il est interdit de stationner un véhicule, autre qu’un véhicule électrique ou hybride rechargeable, dans un espace de stationnement réservé à la recharge en énergie.

Le véhicule électrique ou hybride rechargeable qui occupe un tel espace doit être branché à la borne de recharge électrique de manière à ce qu’une recharge soit en cours et il doit être déplacé lorsque la recharge est terminée. Il est défendu d’occuper un tel espace pendant plus de quatre (4) heures.

En outre des chemins publics, le présent article s'applique sur les chemins privés ouverts à la circulation publique des véhicules routiers ainsi que sur les terrains des centres commerciaux et autres terrains où le public est autorisé à circuler.