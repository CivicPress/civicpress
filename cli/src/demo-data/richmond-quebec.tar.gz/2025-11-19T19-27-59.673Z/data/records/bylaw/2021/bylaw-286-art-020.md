---
id: bylaw-286-art-020
title: Article 20 - De la vente d’articles sur les rues, trottoirs et places publiques
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:41:38.413Z

module: public-bylaws
slug: bylaw-286-art-020

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-02
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-019
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-021
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-020.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 20
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE II - LES NUISANCES
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-020.md

---

# Article 20 - De la vente d’articles sur les rues, trottoirs et places publiques

La vente d’objets, de nourriture, de provisions, de produits ou de quelques articles ou objets sur les rues, trottoirs et places publiques est interdite à moins que la personne qui effectue la vente ne soit détentrice d’un permis préalablement émis à cet effet, selon les conditions suivantes :

1) En avoir fait la demande par écrit, sur la formule fournie par la ville à cet effet, et l’avoir signée;
2) En avoir payé les droits requis par véhicule automobile, bicyclette, tricycle, chariot, charrette ou autres véhicules ou supports similaires pour son émission.

Le permis n’est valide que pour la période mentionnée.

Le permis doit être affiché sur la partie extérieure du véhicule automobile, bicyclette, tricycle, chariot, charrette ou autre véhicule ou support similaire qui sert à la vente, de façon à être visible.