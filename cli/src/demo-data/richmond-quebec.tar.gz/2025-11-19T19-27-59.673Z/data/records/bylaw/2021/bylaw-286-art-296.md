---
id: bylaw-286-art-296
title: Article 296 - Comportements canins jugés inacceptables nécessitant une évaluation
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:13.071Z

module: public-bylaws
slug: bylaw-286-art-296

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-11
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-295
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-297
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-296.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 296
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE XI - LES ANIMAUX
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-296.md

---

# Article 296 - Comportements canins jugés inacceptables nécessitant une évaluation

Sauf dans les cas visés aux paragraphes 1) et 2) de l’article 290, une évaluation comportementale est ordonnée par la ville à l’égard d’un chien qui a mordu une personne ou un autre animal lorsque cette morsure a causé une lacération de la peau nécessitant une intervention médicale.

La ville peut également ordonner l’évaluation comportementale d’un chien dès qu’elle a des motifs raisonnables de croire qu’il constitue un risque pour la santé ou la sécurité publique.

Le gardien d’un chien qui reçoit l’ordre de soumettre son animal à une évaluation comportementale doit s’y conformer à la date, à l’heure et au lieu prescrits dans l’avis transmis par la ville. Le gardien est également responsable du paiement des frais à débourser pour l’évaluation tel que prévu à cet avis.