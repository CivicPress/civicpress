---
id: bylaw-286-art-060
title: Article 60 - Nuisance – Intérieur d’un bâtiment
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:41:43.333Z

module: public-bylaws
slug: bylaw-286-art-060

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-02
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-059
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-061
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-060.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 60
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE II - LES NUISANCES
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-060.md

---

# Article 60 - Nuisance – Intérieur d’un bâtiment

Constitue une nuisance, le fait par le propriétaire, le locataire ou l’occupant d’un bâtiment de laisser s’accumuler à l’intérieur des tissus, chiffons, linges, papiers, cartons, boites, circulaires, journaux, revues, livres, plastiques, cannes, bouteilles, emballages vides, vaisselles, ballots, bois, vieux matériaux, débris de matériaux, appareils électriques, appareils hors d’usage, meubles meublants ou tout autre objet dont la présence en trop grande quantité peut soit affecter la charge portante des planchers, limiter le passage des occupants ou de toute personne, augmenter les risques d’incendie, restreindre le libre accès aux issues telles les portes et les fenêtres, limiter le bon fonctionnement des appareils de chauffage ou de climatisation, restreindre l’aération du bâtiment ou encore limiter l’accès à toute personne aux lieux en cas d’urgence.

Il est défendu de laisser de telles nuisances ou de ne pas prendre tous les moyens nécessaires pour faire disparaître de telles nuisances en contravention du présent article.

Lorsque le propriétaire, le locataire ou l’occupant est déclaré coupable de l’infraction, le tribunal peut, en sus des amendes et des frais, ordonner que les nuisances qui ont fait l’objet de l’infraction soient enlevées, dans le délai qu’il fixe, par le propriétaire, le locataire ou l’occupant et qu’à défaut par cette ou ces personnes de s’exécuter dans le délai, les nuisances soient enlevées par la ville aux frais de cette ou de ces personnes.