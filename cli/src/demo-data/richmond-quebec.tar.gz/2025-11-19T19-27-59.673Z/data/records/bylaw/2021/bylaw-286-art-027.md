---
id: bylaw-286-art-027
title: Article 27 - Bruit extérieur
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:41:39.265Z

module: public-bylaws
slug: bylaw-286-art-027

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-02
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-026
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-028
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-027.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 27
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE II - LES NUISANCES
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-027.md

---

# Article 27 - Bruit extérieur

Là où sont présentées, à l’intérieur ou à l’extérieur d’un édifice, des œuvres musicales, instrumentales ou vocales pré-enregistrées ou non, provenant d’un appareil de reproduction sonore ou provenant d’un musicien présent sur place ou des spectacles, nul ne peut émettre ou permettre que ne soit émis ou laisser émettre un bruit ou une musique en tout temps, de façon à ce qu’il soit entendu à une distance
de quinze mètres (15 m) ou plus de la limite du terrain sur lequel l’activité génératrice du son est située.