---
id: bylaw-286-art-010
title: Article 10 - Véhicules et appareils hors d’état de fonctionnement
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:41:37.193Z

module: public-bylaws
slug: bylaw-286-art-010

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-02
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-009
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-011
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-010.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 10
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE II - LES NUISANCES
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-010.md

---

# Article 10 - Véhicules et appareils hors d’état de fonctionnement

Le fait par le propriétaire, locataire ou occupant d’un terrain vacant ou en partie construit, incluant l’emprise excédentaire de la voie publique, d’y laisser un ou des véhicules hors d’état de fonctionner, des appareils électriques ou mécaniques hors d’état de fonctionner ou des carcasses, débris ou parties de véhicules automobiles ou d’appareils électriques ou mécaniques, constitue une nuisance et est prohibé.

Il est défendu de laisser de telles nuisances ou de ne pas prendre tous les moyens nécessaires pour faire disparaitre de telles nuisances en contravention du présent article.

Lorsque le propriétaire, locataire ou occupant est reconnu coupable de l’infraction, le tribunal peut, en sus des amendes et des frais, ordonner que les nuisances qui ont fait l’objet de l’infraction soient enlevées, dans le délai qu’il fixe, par le propriétaire, le locataire ou l’occupant et qu’à défaut par cette ou ces personnes de s’exécuter dans le délai, les nuisances soient enlevées par la ville aux frais de cette ou de ces personnes.