---
id: bylaw-286-art-164
title: Article 164 - Définitions
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:41:56.104Z

module: public-bylaws
slug: bylaw-286-art-164

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-07
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-163
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-165
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-164.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 164
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE VII - PRÊTEUR SUR GAGE, REGRATTIER ET MARCHAND DE BRIC-À-BRAC
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-164.md

---

# Article 164 - Définitions

À moins de déclaration contraire, expresse ou résultant du contexte de la disposition, les expressions, termes et mots suivants ont dans la présente section, le sens et l’application que leur sont ci-après attribués :

1) L’expression « marchand de bric-à-brac ou d’effets d’occasion » désigne toute personne qui fait le commerce d’articles usagés de quelques natures qu’ils soient, et aussi toute personne qui reçoit sans les acheter des articles usagés et se charge de les vendre. Cette expression ne comprend pas la personne qui fait le commerce d’antiquités ou de friperies;
2) L’expression « prêteur sur gage » désigne toute personne qui fait métier de prêter de l’argent contre remise d’un bien pour garantir le paiement de l’emprunt, à l’exclusion des institutions financières reconnues comme telles par la loi;
3) Le mot « regrattier » désigne un marchand de bric-à-brac ou d’effets d’occasion, un prêteur sur gage ou toute personne qui fait métier d’acquérir par achat, échange ou autrement des biens d’une personne autre qu’un commerçant en semblable matière. Ce mot ne désigne cependant pas la personne qui, dans le cours de son commerce habituel, accepte comme paiement entier ou partiel des marchandises neuves, un ou des articles usagés.