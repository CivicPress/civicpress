---
id: bylaw-286-art-006
title: Article 6 - Définitions
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:41:36.701Z

module: public-bylaws
slug: bylaw-286-art-006

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-01
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-005
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-007
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-006.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 6
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE I - DISPOSITIONS DÉCLARATOIRES ET INTERPRÉTATIVES
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-006.md

---

# Article 6 - Définitions

À moins de déclaration contraire, expresse ou résultant du contexte de la disposition, les expressions, termes et mots suivants, ont dans le présent règlement, le sens et l'application que leur attribue le présent article :

Adolescent :

Désigne toute personne âgée de quatorze (14) ans à dix- sept (17) ans.

Aire de jeux :

Désigne la partie d’un terrain, accessible au public, occupée par des équipements destinés à l’amusement des enfants, tels que balançoire, glissoire, trapèze, carré de sable, piscine ou pataugeoire.

Aire de service :

Désigne la partie d’un terrain ou d’une chaussée, accessible au public servant habituellement aux institutions aux heures d’ouverture.

Animal agricole :

Désigne un animal que l’on retrouve habituellement sur une exploitation agricole.

Animal sauvage :

Désigne un animal exclu de la liste des « animaux autorisés » au Chapitre XI du présent règlement.

Arrêt :

Désigne l'immobilisation complète d'un véhicule.

Autorité compétente :

Aux fins du Chapitre XI, désigne la Société protectrice des
animaux de l’Estrie et son personnel, tout membre de la Sûreté du Québec et tout fonctionnaire autorisé.

Bordure :

Désigne le bord de la chaussée.

Camion :

Signifie tout véhicule routier désigné communément comme camion, fourgon, tracteur, remorque ou semi- remorque, ensemble de véhicules routiers, habitation motorisée ou autres véhicules du même genre. Les véhicules automobiles du type "éconoline", "station-wagon" ou "pick up" ne sont pas considérés comme camion pour l'application du présent règlement.

Chatterie :

Désigne le bâtiment dans lequel sont gardés des chats.

Chaussée :

Désigne la partie du chemin public utilisée normalement pour la circulation des véhicules.

Chenil :

Désigne le bâtiment dans lequel sont gardés des chiens.

Chien d’assistance :

Désigne un chien dressé ou en formation, incluant la période initiale où il est confié à une famille pour des fins de socialisation, dont une personne a besoin pour l’assister et qui fait l’objet d’un certificat valide attestant qu’il a été dressé, ou est en formation à cette fin, par un organisme professionnel de dressage de chiens d’assistance.

Cité, ville, municipalité :

Désignent la Ville de Richmond, Québec.

Colporteur :

Signifie toute personne qui porte elle-même ou transporte avec elle des objets, effets ou marchandises avec l'intention de les vendre dans les limites de la ville.

Conseil, membre du conseil :

Désignent et comprennent le maire et les conseillers de la ville.

Demi-tour :

Désigne la manœuvre effectuée sur un chemin public avec un véhicule en vue de la diriger dans une direction opposée.

Enclos extérieur :

Désigne une enceinte fermée dans laquelle un ou plusieurs animaux peuvent être mis en liberté et conçue de façon à ce que l’animal ne puisse en sortir.

Endroit privé :

Désigne tout endroit qui n'est pas un endroit public tel que défini au présent article.

Endroit public :

Désigne les parcs, les cimetières, les arénas, les aires à caractère public, les véhicules de transport public, les magasins, les garages, les églises, les hôpitaux, les écoles, les centres communautaires, les édifices municipaux ou gouvernementaux, les restaurants, les bars, les brasseries ou tout autre établissement du genre et où des services sont offerts au public.

Enseigne d’identification :

Désigne les enseignes de bienvenue aux entrées de la ville, les enseignes aux sorties de la ville, les enseignes identifiant les propriétaires des secteurs de villégiatures, les enseignes directionnelles.

Espace de stationnement :

Désigne la partie d'une chaussée ou d'un terrain de stationnement prévue comme surface de stationnement
pour un véhicule automobile.

Établissement :

Désigne tout local commercial dans lequel des biens ou des services sont offerts en vente au public.

Évaluation comportementale :

Désigne l’examen de l’état et de la dangerosité d’un chien par un médecin vétérinaire conformément au Règlement
d’application de la Loi visant à favoriser la protection des personnes par la mise en place d’un encadrement concernant les chiens (c. P-38.002, a. 1, 2e al.).

Exploitation agricole :

Désigne toute entreprise qui fait une production agricole carte et commerciale d’enregistrement valide émise par le Ministère de l’Agriculture, des Pêcheries et de l’Alimentation du Québec (MAPAQ), en vertu du règlement sur l’enregistrement des exploitations agricoles.

titulaire
d’une
qui
est

Famille d’accueil :

Aux fins du Chapitre XI, désigne un lieu où sont gardés temporairement des animaux autorisés au présent règlement en convalescence ou en période de sevrage en vue de leur adoption. Seuls les animaux confiés par la SPA de l’Estrie ou un refuge sont visés par cette expression. Les animaux appartenant à la famille d’accueil sont par ailleurs visés par les dispositions du présent règlement.

Fausse alarme policière :

Une alarme déclenchée sans qu’il y ait urgence pour toutes autres fins que celles auxquelles elle a été prévue, sans qu’il y ait preuve de la présence d’effraction ou sans raison apparente, ou une alarme déclenchée à cause d’une panne mécanique, d’une défectuosité, d’une installation inadéquate, d’un mauvais entretien, d’une erreur humaine ou par négligence; une alarme déclenchée par un ouragan, une tornade ou un séisme n’est pas, au sens du présent règlement, une fausse alarme.

Fausse alarme incendie :

Une alarme déclenchée sans qu’il y ait urgence pour toutes autres fins que celles auxquelles elle a été prévue, sans qu’il y ait preuve de la présence d’incendie ou sans raison apparente, ou une alarme qui nécessite un déplacement des services d’incendie.

Feu de circulation :

Désigne le dispositif situé en bordure de la chaussée ou au- dessus et destiné à contrôler la circulation au moyen de messages lumineux.

Fourrière :

Désigne un lieu où sont recueillis des chats ou des chiens errants ou abandonnés par leur gardien. Le but visé est de favoriser la reprise en charge de l’animal par son gardien ou à défaut, l’adoption, c’est-à-dire le transfert vers un autre lieu de garde, ou l’euthanasie par l’exploitant ou par un tiers.

Fumer :

En plus du sens commun, notre définition désigne également l’usage d’une pipe, d’un bong, d’une cigarette électronique ou tout autre dispositif de cette nature.

Gardien :

Aux fins du Chapitre XI, désigne une personne qui a la propriété, la possession ou la garde d’un animal. La personne qui donne refuge, nourrit ou entretient un animal est présumé en avoir l’autorité compétente à la garde de l’animal, le mot « gardien » fait référence à son propriétaire ou son gardien habituel pour toute obligation, mesure ou norme de garde ainsi que pour le paiement des frais.

la garde. Lorsque

Immeuble :

Tout immeuble au sens des articles 899 à 904 du Code civil du Québec.

Imprimé érotique :

Désigne tout livre, magazine, journal, dépliant ou autre publication qui fait appel ou est destiné à faire appel aux appétits sexuels ou érotiques au moyen d’illustrations de seins ou de parties génitales.

Incendie :

Feu destructeur d’intensité variable qui se produit hors d’un foyer normal de combustion dans des circonstances souvent incontrôlables et qui peut produire un dégagement de fumée.

Intersection :

Désigne l’endroit de croisement ou de rencontre de plusieurs chaussées, peu importe l’angle formé par l’axe de
ces chaussées.

Licence :

Désigne le permis de garder un chien ou un chat sous forme d’un document fourni par le responsable de l’application du présent règlement à titre de facture contenant les coordonnées du gardien ou du propriétaire ainsi que les caractéristiques de l’animal.

Lieu d’élevage :

Se définit comme l’endroit où se fait la reproduction d’un animal en vue de sa vente. L’élevage peut inclure le dressage d’un animal.

Lieu protégé :

Un terrain, une construction, un ouvrage, une embarcation, un véhicule routier ou une motocyclette protégée par un système d’alarme.

Motoneige :

Véhicule à moteur d’un poids maximal de 450 kilogrammes, autopropulsé, construit pour se déplacer principalement sur la neige ou la glace, muni d’un ou plusieurs skis ou patins de direction, mus par une ou plusieurs courroies sans fin en contact avec le sol; le mot motoneige comprend la motoneige de compétition.

Nuisance :

Signifie tout acte ou omission qui peut mettre en danger la vie, la sécurité, la santé, la propriété ou le confort du public ou d’un individu. Il peut signifier aussi tout acte ou omission par lequel, le public ou un individu est gêné dans l’exercice ou la jouissance d’un droit commun.

Objet érotique :

Désigne tout objet ou gadget qui fait appel ou est destiné à faire appel aux appétits sexuels ou érotiques.

Occupant :

Signifie toute personne qui occupe un immeuble en son nom propre, à titre autre que celui de propriétaire, d’usufruitier ou de grevé et qui jouit des revenus provenant dudit immeuble.

Officier municipal :

Tout fonctionnaire ou employé de incluant l’inspecteur municipal, à l’exclusion des membres du conseil;

la ville,

Parade :

Désigne tout groupe de personnes d’au moins vingt (20) personnes ou tout groupe de dix (10) véhicules qui défilent sur la chaussée ou sur le trottoir dans le but de manifester, ne comprend pas un cortège funèbre.

Parc :

Signifie tout terrain possédé ou acheté par la ville pour y établir un parc, un parc canin, un îlot de verdure, une zone écologique, un sentier multifonctionnel, une piste cyclable, qu’il soit aménagé ou non, ou tout terrain situé sur le territoire de la ville servant de parc-école, propriété d’une commission scolaire.

Parc canin :

Signifie tout terrain appartenant à la ville où est aménagé un enclos destiné à permettre aux chiens de circuler librement sans être tenus en laisse et identifié à cette fin.

Parc public :

Désigne un espace vaste en plein air destiné aux repos et loisir du public.

Passage pour piétons :

Désigne le passage destiné au passage des piétons identifiés comme tel par une signalisation ou la partie de la
chaussée comprise dans le prolongement des trottoirs.

Pension :

Aux fins du Chapitre XI, désigne un établissement où sont nourris et logés temporairement des chats et des chiens, contre rémunération.

Périmètre d’urbanisation :

La limite prévue de l’extension future de l’habitat de type urbain dans la ville telle que prévue au plan d’urbanisme et représentée sur le plan de zonage de la ville.


Personne :

Signifie et comprend tout individu, société ou corporation.

Piéton :

Désigne une personne qui circule à pied, dans un fauteuil roulant motorisé ou non, dans un carrosse, sur un tricycle ou sur un véhicule de trottoir.

Place privée :

Désigne toute place qui n’est pas une place publique telle que définie au présent article.

Place publique :

Désigne tout chemin, rue, ruelle, allée, passage, place ou voie publique, aire de repos, piscine, aréna, patinoire, centre communautaire, terrain sportif et récréatif, sentier pédestre, fossé, trottoir, escalier,
jardin, piste cyclable, sentier multifonctionnel, parc, parc canin, promenade, terrain de jeux, estrade, stationnement à l’usage du public, tout lieu de rassemblement extérieur où le public a accès.

Propriétaire :

Signifie toute personne qui possède un immeuble en son nom propre à titre de propriétaire, d’usufruitier ou de grevé dans le cas de substitution ou de possesseur avec promesse de vente de terres de la Couronne.

Refuge :

Aux fins du Chapitre XI, désigne un lieu supervisé par un recueillis organisme à but non temporairement des animaux autorisés, errants ou abandonnés par leur gardien. Le but visé est de favoriser la reprise en charge de l’animal par son gardien ou à défaut, l’adoption c’est-à-dire le transfert vers un autre lieu de garde, ou l’euthanasie par l’exploitant ou par un tiers. Un permis de refuge doit être délivré par le MAPAQ.


lucratif où sont

Remise :

Désigne un bâtiment accessoire, dépendant, détaché, destiné à améliorer l’utilité et la commodité du bâtiment
principal situé sur le même terrain et servant à remiser principalement des choses. Une remise ne doit pas servir au stationnement ni au remisage des véhicules automobiles.

Rue :

Et toute autre désignation similaire signifiant l’espace compris entre les lignes qui séparent les terrains privés.

Salles de danse publiques pour adolescents :

Signifie tout bâtiment ou endroit où le public adolescent est admis et où l’on se livre à la danse, qu’un prix d’entrée soit exigé ou non.

SPA de l’Estrie :

Désigne la Société protectrice des animaux de l’Estrie étant un organisme à but non lucratif dont le rôle principal est axésur la protection des animaux où ces derniers sont recueillis, hébergés temporairement, soignés et donnés en adoption, le cas échéant. À défaut, les animaux peuvent également lieu de garde ou
être transférés vers un nouveau euthanasiés s’ils sont malades, blessés, interdits sur le territoire, en surnombre ou s’ils possèdent des problèmes de comportement. Les locaux où sont gardés les animaux sont désignés comme le refuge de la SPA de l’Estrie.

Sentier multifonctionnel :

Signifie une surface de terrain qui n’est pas adjacente à une chaussée, possédée par la ville ou dont elle est propriétaire et qui est aménagée pour la circulation de différents moyens de locomotion.

Signal de circulation :

Désigne toute affiche, signal, marque sur la chaussée ou autre dispositif, compatible avec le Code de la sécurité routière (L.R.Q., c.C-24.2) et le présent règlement, installé par un officier municipal ou gouvernemental et permettant de contrôler et de régulariser la circulation des piétons et des véhicules ainsi que le stationnement des véhicules.

Solliciteur :

Signifie toute personne qui sollicite ou collecte de l’argent après une sollicitation téléphonique ou autre, ou toute personne qui vend des annonces, de la publicité, des insignes ou des menus objets, ou toute personne qui exerce quelque forme de sollicitation monétaire que ce soit dans les rues de la ville de porte-à-porte ou autrement.

Système d’alarme :

Dans un lieu protégé situé sur le territoire de la ville de Richmond tout appareil, bouton de panique ou dispositif destiné à avertir :
a) de la présence d’un incendie;
b) de la présence d’un intrus;
c) de la commission d’une infraction ou d’une tentative d’infraction;
d) d’une entrée non autorisée;
e) dans toute autre situation.

Terrain de stationnement privé :

Désigne un terrain où retrouve des espaces l’on stationnement dont la ville n’est pas propriétaire et qui est assujetti par entente au présent règlement.

Trottoir :

Désigne la partie d’une rue réservée à la circulation des piétons.

Unité d’occupation :

Signifie un local formé d’une pièce ou d’un groupe de pièces complémentaires et communicantes, y compris ses dépendances et le terrain où est situé cette unité dont le gardien de locataire ou occupant.

l’animal est propriétaire,
le

Utilisateur :

Toute personne physique ou morale qui est propriétaire ou occupant d’un lieu protégé. Est réputé utilisateur, le propriétaire de l’immeuble.

Véhicule :

Tout véhicule au sens du Code de la sécurité routière (L.R.Q., c. C-24.2).

Voie :

Désigne la partie de la chaussée ayant une largeur suffisante pour permettre à des véhicules d’y circuler, les uns à la suite des autres et qui est délimitée par des lignes de chaussée.

Zone agricole permanente :

Désigne la partie du territoire de la ville reconnue par Décret du gouvernement ou par inclusion conformément à la Loi sur la protection du territoire et des activités agricoles (RLRQ c. P-41.1).


Zone blanche :

Désigne la partie du territoire de la ville qui est située à l’extérieur de la zone agricole permanente.

Zone résidentielle :

Désigne la portion du territoire de la ville définie comme telle par le règlement de zonage en vigueur et ses
amendements.


L’expression « Règlement sur les animaux en captivité » réfère au règlement adopté en vertu de la Loi sur la conservation et la mise en valeur de la faune (L.R.Q. 1977,

C-61.1 r.0.0001).