---
id: bylaw-286-art-161
title: Article 161 - Définitions
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:41:55.724Z

module: public-bylaws
slug: bylaw-286-art-161

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-06
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-160
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-162
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-161.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 161
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE VI – DISTRIBUTION DES SACS D’EMPLETTES
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-161.md

---

# Article 161 - Définitions

À moins de déclaration contraire, expresse ou résultant du contexte de la disposition, les expressions, termes et mots suivants ont dans la présente section, le sens et l’application qui leur sont ci-après attribués :

1) Activité commerciale : Tout contrat conclu entre un consommateur et un commerçant dans le cours des activités d’un commerce et ayant pour l’objet un bien

ou un service;

2) Sac d’emplettes constitué de plastique : Contenant souple dont l’ouverture se situe sur le dessus visant un usage unique et pouvant servir au transport de produits, constitué de composantes à base de pétrole brut, notamment de polyéthylène, de polymères ou tout autre matériau similaire.

Sans restreindre la généralité de ce qui précède, les sacs de plastique conventionnels,
oxo-biodégradables et photo dégradables font partie intégrante de la présente définition;

3) Sac d’emplettes compostable : Contenant souple dont l’ouverture se situe sur le dessus, conforme à la norme CAN/BNQ 0017-088 et composé principalement de polyester et d’amidon;
4) Sac d’emplettes en papier : Contenant dont l’ouverture s’ouvre par le dessus constitué exclusivement de matière papier recyclable, incluant les poignées ou tout autre élément faisant partie intégrante du sac;
5) Sac d’emplettes réutilisable : Contenant constitué de polyéthylène, de polypropylène ou de polyester dont l’ouverture s’ouvre par le dessus spécifiquement conçu pour de multiples usages ayant une épaisseur supérieure à 0,1 mm ou contenant dont l’ouverture s’ouvre par le dessus spécifiquement conçu pour de multiples usages constitués de matière textile résistante.