---
id: bylaw-286-chap-02
title: CHAPITRE II - LES NUISANCES
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:27.006Z

module: public-bylaws
slug: bylaw-286-chap-02

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-008
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-009
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-010
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-011
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-012
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-013
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-014
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-015
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-016
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-017
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-018
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-019
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-020
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-021
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-022
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-023
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-024
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-025
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-026
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-027
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-028
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-029
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-030
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-031
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-032
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-033
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-034
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-035
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-036
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-037
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-038
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-039
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-040
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-041
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-042
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-043
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-044
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-045
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-046
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-047
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-048
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-049
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-050
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-051
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-052
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-053
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-054
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-055
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-056
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-057
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-058
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-059
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-060
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-061
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-062
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-063
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-064
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-065
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-066
    type: bylaw
    category: referenced_by
    description: Child record

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-chap-02.md
    created: {}
    year: 2021
    language: fr-CA
    jurisdiction: municipal
    classification: public
    public_access: true
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: chapter
  file_path: bylaw/2021/bylaw-286-chap-02.md

---

# CHAPITRE II - LES NUISANCES

- [Article 8 - Eaux sales, immondices, fumier, matières malsaines](bylaw-286-art-008.md)
- [Article 9 - Branches mortes, débris, ferraille, déchets, substances nauséabondes](bylaw-286-art-009.md)
- [Article 10 - Véhicules et appareils hors d’état de fonctionnement](bylaw-286-art-010.md)
- [Article 11 - Hautes herbes](bylaw-286-art-011.md)
- [Article 12 - Mauvaises herbes](bylaw-286-art-012.md)
- [Article 13 - Disposition des huiles](bylaw-286-art-013.md)
- [Article 14 - Disposition de la neige, de la glace, des feuilles de l’herbe ou de la cendre](bylaw-286-art-014.md)
- [Article 15 - Fossés, cours d’eau et lacs](bylaw-286-art-015.md)
- [Article 16 - Embarcation à moteur](bylaw-286-art-016.md)
- [Article 17 - Utilisation des égouts](bylaw-286-art-017.md)
- [Article 18 - Déversement des eaux usées dans une place publique](bylaw-286-art-018.md)
- [Article 19 - Véhicule en marche](bylaw-286-art-019.md)
- [Article 20 - De la vente d’articles sur les rues, trottoirs et places publiques](bylaw-286-art-020.md)
- [Article 21 - Endroit](bylaw-286-art-021.md)
- [Article 22 - Immobilisation du véhicule qui sert à la vente](bylaw-286-art-022.md)
- [Article 23 - Bruit répété ou continu](bylaw-286-art-023.md)
- [Article 24 - Bruit et ordre](bylaw-286-art-024.md)
- [Article 25 - Haut-parleur extérieur](bylaw-286-art-025.md)
- [Article 26 - Haut-parleur intérieur](bylaw-286-art-026.md)
- [Article 27 - Bruit extérieur](bylaw-286-art-027.md)
- [Article 28 - Exception](bylaw-286-art-028.md)
- [Article 29 - Tondeuse à gazon, scie à chaîne ou autre appareil similaire](bylaw-286-art-029.md)
- [Article 30 - Défense de faire du bruit la nuit](bylaw-286-art-030.md)
- [Article 31 - Exceptions](bylaw-286-art-031.md)
- [Article 32 - Bruit ou tumulte dans une place publique ou un endroit public](bylaw-286-art-032.md)
- [Article 33 - Bruit ou tumulte dans une place privée ou un endroit privé](bylaw-286-art-033.md)
- [Article 34 - Bruit entre 23 h 00 et 7 h 00](bylaw-286-art-034.md)
- [Article 35 - Travaux de construction](bylaw-286-art-035.md)
- [Article 36 - Bruit provenant d’un véhicule](bylaw-286-art-036.md)
- [Article 37 - Bruit perturbateur – Embarcation de plaisance](bylaw-286-art-037.md)
- [Article 38 - Bruit tapage - Embarcation de plaisance](bylaw-286-art-038.md)
- [Article 39 - Instrument de musique](bylaw-286-art-039.md)
- [Article 40 - Fumée ou odeurs](bylaw-286-art-040.md)
- [Article 41 - Feux en plein air](bylaw-286-art-041.md)
- [Article 42 - Feux de broussailles](bylaw-286-art-042.md)
- [Article 43 - Pétards, feux pyrotechniques](bylaw-286-art-043.md)
- [Article 44 - Coût et validité du permis](bylaw-286-art-044.md)
- [Article 45 - Conditions](bylaw-286-art-045.md)
- [Article 46 - Feux prohibés](bylaw-286-art-046.md)
- [Article 47 - Foyer extérieur préfabriqué](bylaw-286-art-047.md)
- [Article 48 - Normes d’installation d’un foyer extérieur](bylaw-286-art-048.md)
- [Article 49 - Conditions d’utilisation d’un foyer extérieur](bylaw-286-art-049.md)
- [Article 50 - Fumées nocives](bylaw-286-art-050.md)
- [Article 51 - Étincelle ou suie](bylaw-286-art-051.md)
- [Article 52 - Projection de source de lumière ou de laser](bylaw-286-art-052.md)
- [Article 53 - Provoquer de la poussière](bylaw-286-art-053.md)
- [Article 54 - Bâtiment désuet](bylaw-286-art-054.md)
- [Article 55 - Endommager un terrain](bylaw-286-art-055.md)
- [Article 56 - Herbicides ou pesticides](bylaw-286-art-056.md)
- [Article 57 - État de propreté du terrain](bylaw-286-art-057.md)
- [Article 58 - Rebuts sur la propriété privée](bylaw-286-art-058.md)
- [Article 59 - Salubrité](bylaw-286-art-059.md)
- [Article 60 - Nuisance – Intérieur d’un bâtiment](bylaw-286-art-060.md)
- [Article 61 - Pose d’affiches sans permis](bylaw-286-art-061.md)
- [Article 62 - Exceptions](bylaw-286-art-062.md)
- [Article 63 - Obligation d’enlever les affiches](bylaw-286-art-063.md)
- [Article 64 - Identification civique des immeubles](bylaw-286-art-064.md)
- [Article 65 - Appel aux services d’urgence](bylaw-286-art-065.md)
- [Article 66 - Appel 9-1-1 sans urgence](bylaw-286-art-066.md)