---
id: bylaw-286-chap-10
title: CHAPITRE X - DE L'ORDRE ET DE LA PAIX PUBLIQUE
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:28.090Z

module: public-bylaws
slug: bylaw-286-chap-10

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-191
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-192
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-193
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-194
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-195
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-196
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-197
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-198
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-199
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-200
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-201
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-202
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-203
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-204
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-205
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-206
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-207
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-208
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-209
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-210
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-211
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-212
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-213
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-214
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-215
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-216
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-217
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-218
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-219
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-220
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-221
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-222
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-223
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-224
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-225
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-226
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-227
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-228
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-229
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-230
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-231
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-232
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-233
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-234
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-235
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-236
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-237
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-238
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-239
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-240
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-241
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-242
    type: bylaw
    category: referenced_by
    description: Child record

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-chap-10.md
    created: {}
    year: 2021
    language: fr-CA
    jurisdiction: municipal
    classification: public
    public_access: true
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: chapter
  file_path: bylaw/2021/bylaw-286-chap-10.md

---

# CHAPITRE X - DE L'ORDRE ET DE LA PAIX PUBLIQUE

- [Article 191 - Consommation de boissons alcoolisées](bylaw-286-art-191.md)
- [Article 192 - Consommation de boissons alcoolisées dans un endroit privé](bylaw-286-art-192.md)
- [Article 193 - Consommation de boissons alcoolisées dans un véhicule](bylaw-286-art-193.md)
- [Article 194 - Intoxication par l’alcool, la drogue ou les médicaments](bylaw-286-art-194.md)
- [Article 195 - Ivresse place privée ou endroit privé](bylaw-286-art-195.md)
- [Article 196 - Réunion tumultueuse](bylaw-286-art-196.md)
- [Article 197 - Organisateur - nuisance](bylaw-286-art-197.md)
- [Article 198 - Rassemblements sur une place privée](bylaw-286-art-198.md)
- [Article 199 - Uriner ou déféquer](bylaw-286-art-199.md)
- [Article 200 - Indécence](bylaw-286-art-200.md)
- [Article 201 - Ouverture des parcs municipaux](bylaw-286-art-201.md)
- [Article 202 - Accès interdit dans les places publiques](bylaw-286-art-202.md)
- [Article 203 - Événement spécial](bylaw-286-art-203.md)
- [Article 204 - Heures de baignade](bylaw-286-art-204.md)
- [Article 205 - Étang](bylaw-286-art-205.md)
- [Article 206 - Être avachi, étendu ou endormi dans une place publique](bylaw-286-art-206.md)
- [Article 207 - Être avachi, étendu ou endormi dans une place privée](bylaw-286-art-207.md)
- [Article 208 - Errer dans une place publique ou un endroit public](bylaw-286-art-208.md)
- [Article 209 - Intrus sur un terrain privé](bylaw-286-art-209.md)
- [Article 210 - École](bylaw-286-art-210.md)
- [Article 211 - Mendier](bylaw-286-art-211.md)
- [Article 212 - Refus de quitter un endroit public ou une place publique](bylaw-286-art-212.md)
- [Article 213 - Refus de quitter une place privée ou un endroit privé](bylaw-286-art-213.md)
- [Article 214 - Ordre d'un agent de la paix](bylaw-286-art-214.md)
- [Article 215 - Refus de circuler](bylaw-286-art-215.md)
- [Article 216 - Injures](bylaw-286-art-216.md)
- [Article 217 - Injures à une personne](bylaw-286-art-217.md)
- [Article 218 - Crachat endroit public ou place publique](bylaw-286-art-218.md)
- [Article 219 - Crachat endroit privé ou place privée](bylaw-286-art-219.md)
- [Article 220 - Mégot](bylaw-286-art-220.md)
- [Article 221 - Entrave](bylaw-286-art-221.md)
- [Article 222 - Sonner et frapper aux portes](bylaw-286-art-222.md)
- [Article 223 - Obstruction](bylaw-286-art-223.md)
- [Article 224 - Détériorer la propriété](bylaw-286-art-224.md)
- [Article 225 - Graffiti](bylaw-286-art-225.md)
- [Article 226 - Violence dans une place publique ou un endroit public](bylaw-286-art-226.md)
- [Article 227 - Violence dans une place privée ou un endroit privé](bylaw-286-art-227.md)
- [Article 228 - Arme dans une place publique](bylaw-286-art-228.md)
- [Article 229 - Endommager les endroits publics ou les places publiques](bylaw-286-art-229.md)
- [Article 230 - Grimper](bylaw-286-art-230.md)
- [Article 231 - Disposition des déchets](bylaw-286-art-231.md)
- [Article 232 - Projectiles](bylaw-286-art-232.md)
- [Article 233 - Armes blanches](bylaw-286-art-233.md)
- [Article 234 - Terrain privé](bylaw-286-art-234.md)
- [Article 235 - Armes](bylaw-286-art-235.md)
- [Article 236 - Clubs ou associations de tir](bylaw-286-art-236.md)
- [Article 237 - Exceptions pour activités communautaires](bylaw-286-art-237.md)
- [Article 238 - Pouvoir du Service compétent en matière de lieux récréatifs](bylaw-286-art-238.md)
- [Article 239 - Troubler la paix](bylaw-286-art-239.md)
- [Article 240 - Règles de conduite](bylaw-286-art-240.md)
- [Article 241 - Expulsion](bylaw-286-art-241.md)
- [Article 242 - Interdiction de fumer du tabac](bylaw-286-art-242.md)