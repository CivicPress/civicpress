---
id: bylaw-286-art-312
title: Article 312 - Licence
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:15.160Z

module: public-bylaws
slug: bylaw-286-art-312

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-11
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-311
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-313
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-312.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 312
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE XI - LES ANIMAUX
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-312.md

---

# Article 312 - Licence

a) Sous réserve du paragraphe 3 du présent article, nul gardien ne peut posséder ou garder un chien à l’intérieur des limites de la ville sans s’être procuré une licence auprès de la SPA de l’Estrie ou du responsable de l’application du présent règlement conformément à la présente section.
b) Sous réserve du paragraphe 3 du présent article, nul ne peut posséder ou garder un chat à l’intérieur des limites de la ville sans s’être procuré une licence auprès de la SPA de l’Estrie ou du responsable de l’application du présent règlement conformément à la présente section.
c) Les deux premiers paragraphes ne s’appliquent pas aux animaux qui sont gardés dans une animalerie, un établissement vétérinaire, un établissement d’enseignement ou un établissement qui exerce des activités de recherche, une fourrière, un service animalier, un refuge ou toute personne ou organisme voué à la protection des animaux titulaire d’un permis visé à l’article 19 de la Loi sur le bien-être et la sécurité animal (RLRQ, c. B-3.1) ou une famille d’accueil. Il ne s’applique pas non plus aux chats gardés sur une exploitation agricole.