---
id: bylaw-286-art-293
title: Article 293 - Défaut de se conformer à la décision et pouvoir d’intervention
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:12.687Z

module: public-bylaws
slug: bylaw-286-art-293

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-11
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-292
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-294
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-293.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 293
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE XI - LES ANIMAUX
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-293.md

---

# Article 293 - Défaut de se conformer à la décision et pouvoir d’intervention

Lorsqu’un gardien ne respecte pas l’ordre d’euthanasier son chien découlant de la décision de la ville prévue à l’article 292, la ville le met en demeure de se conformer dans un délai de 24 heures.

Suivant ce délai, l’autorité compétente peut saisir le chien et l’euthanasier ou le faire euthanasier.

Si le gardien du chien s’oppose à la saisie de l’animal, l’autorité compétente peut s’adresser au tribunal afin d’obtenir la permission de capturer et saisir cet animal à la résidence de son gardien, ou ailleurs.