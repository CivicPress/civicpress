---
id: bylaw-286-art-266
title: Article 266 - Animal mort
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:09.010Z

module: public-bylaws
slug: bylaw-286-art-266

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-11
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-265
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-267
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-266.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 266
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE XI - LES ANIMAUX
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-266.md

---

# Article 266 - Animal mort

Le gardien d’un animal mort doit, dans les vingt-quatre (24) heures de son décès en
disposer, à ses frais, selon l’une ou l’autre des options suivantes :

1) le remettre à un vétérinaire;
2) en disposer à tout endroit légalement autorisé à recevoir les animaux morts;
3) s’il s’agit d’un chien, d’un chat ou d’un animal de moins de 5 kilogrammes, l’animal peut être remis à la SPA de l’Estrie;

Cet article ne s’applique pas aux activités agricoles.

SOUS-SECTION IV – Normes de garde et de contrôle des animaux