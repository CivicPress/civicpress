---
id: bylaw-286-art-250
title: Article 250 - Exception - Stérilisation
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:06.921Z

module: public-bylaws
slug: bylaw-286-art-250

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-11
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-249
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-251
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-250.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 250
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE XI - LES ANIMAUX
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-250.md

---

# Article 250 - Exception - Stérilisation

Malgré l’article 249, le gardien d’un animal visé à cet article n’est pas soumis à l’exigence de faire stériliser cet animal s’il se trouve dans l’une ou l’autre des situations suivantes :

1) l’animal est âgé de moins de 4 mois ou de 10 ans ou plus;
2) la stérilisation est proscrite par un vétérinaire pour des raisons de santé de l’animal;
3) le chat est enregistré auprès de l’Association féline canadienne;
4) le chien est enregistré auprès du Club canin canadien.

Les exceptions prévues aux paragraphes 3 et 4 du premier alinéa ne s’appliquent pas aux animaux confiés à l’adoption par la SPA de l’Estrie ou un refuge.

SOUS-SECTION III – Conditions minimales de garde des animaux