---
id: bylaw-286-art-316
title: Article 316 - Demande de licence
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:15.679Z

module: public-bylaws
slug: bylaw-286-art-316

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-11
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-315
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-317
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-316.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 316
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE XI - LES ANIMAUX
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-316.md

---

# Article 316 - Demande de licence

Pour obtenir une licence, le gardien doit être âgé d’au moins 16 ans et fournir les renseignements suivants :

1) ses nom, prénom, date de naissance, adresse et numéro de téléphone;
2) le nom, la race ou le type, la date de naissance, le poids si l’animal est un chien, le sexe, la couleur et les signes distinctifs de l’animal;
3) pour un chien, sa provenance;
4) le nombre d'animaux dont il est le gardien;
5) la preuve de stérilisation de l'animal, le cas échéant;
6) le numéro de la micropuce, le cas échéant;
7) la preuve que le statut vaccinal du chien contre la rage est à jour, si requis;
8) la preuve de l’âge de l’animal, si requis;
9) le nom des villes où le chien a déjà été enregistré;
10) toute décision rendue par une ville en vertu du Règlement d’application de la Loi visant à favoriser la protection des personnes par la mise en place d’un encadrement concernant les chiens ou en vertu d’un règlement municipal concernant les chiens à l’égard du chien, à son égard ou à l’égard de toute personne qui réside dans la même unité d’occupation que lui.

Le gardien doit, dans les 21 jours de la demande de licence, acquitter le paiement total du coût de la licence. Une licence n’est valide que lorsque le paiement total du coût a été effectué. À l’expiration du délai de 21 jours, les frais de retard prévus dans le règlement de tarification de la ville s’ajoutent au coût de la licence.

Le gardien doit aviser la SPA de l’Estrie ou le responsable de l’application du présent règlement de toute modification aux renseignements fournis en vertu du présent article au plus tard 15 jours suivant leur survenance. Le poids de l’animal peut être mis à jour lors du renouvellement annuel de la licence.

Quiconque fournit aux fins visées par le présent article un renseignement faux ou trompeur ou un renseignement qu’il aurait dû savoir faux ou trompeur contrevient au présent règlement et commet une infraction.