---
id: bylaw-286-chap-13
title: CHAPITRE XIII - SALLES DE DANSE PUBLIQUES POUR ADOLESCENTS
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:28.521Z

module: public-bylaws
slug: bylaw-286-chap-13

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-356
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-357
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-358
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-359
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-360
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-361
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-362
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-363
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-364
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-365
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-366
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-367
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-368
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-369
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-370
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-371
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-372
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-373
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-374
    type: bylaw
    category: referenced_by
    description: Child record

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-chap-13.md
    created: {}
    year: 2021
    language: fr-CA
    jurisdiction: municipal
    classification: public
    public_access: true
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: chapter
  file_path: bylaw/2021/bylaw-286-chap-13.md

---

# CHAPITRE XIII - SALLES DE DANSE PUBLIQUES POUR ADOLESCENTS

- [Article 356 - Horaire](bylaw-286-art-356.md)
- [Article 357 - Accès interdit](bylaw-286-art-357.md)
- [Article 358 - Admission interdite](bylaw-286-art-358.md)
- [Article 359 - Carte d'identité](bylaw-286-art-359.md)
- [Article 360 - Endroits prohibés](bylaw-286-art-360.md)
- [Article 361 - Spectacles et représentations](bylaw-286-art-361.md)
- [Article 362 - Responsable](bylaw-286-art-362.md)
- [Article 363 - Éclairage](bylaw-286-art-363.md)
- [Article 364 - Compartiments](bylaw-286-art-364.md)
- [Article 365 - Vitres](bylaw-286-art-365.md)
- [Article 366 - Permis d'exploitation](bylaw-286-art-366.md)
- [Article 367 - Demande de permis](bylaw-286-art-367.md)
- [Article 368 - Exigences non respectées](bylaw-286-art-368.md)
- [Article 369 - Gardien](bylaw-286-art-369.md)
- [Article 370 - Coût du permis régulier](bylaw-286-art-370.md)
- [Article 371 - Validité du permis](bylaw-286-art-371.md)
- [Article 372 - Coût du permis temporaire](bylaw-286-art-372.md)
- [Article 373 - Affichage](bylaw-286-art-373.md)
- [Article 374 - Conformité](bylaw-286-art-374.md)