---
id: bylaw-286-chap-07
title: CHAPITRE VII - PRÊTEUR SUR GAGE, REGRATTIER ET MARCHAND DE BRIC-À-BRAC
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:27.681Z

module: public-bylaws
slug: bylaw-286-chap-07

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-164
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-165
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-166
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-167
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-168
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-169
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-170
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-171
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-172
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-173
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-174
    type: bylaw
    category: referenced_by
    description: Child record

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-chap-07.md
    created: {}
    year: 2021
    language: fr-CA
    jurisdiction: municipal
    classification: public
    public_access: true
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: chapter
  file_path: bylaw/2021/bylaw-286-chap-07.md

---

# CHAPITRE VII - PRÊTEUR SUR GAGE, REGRATTIER ET MARCHAND DE BRIC-À-BRAC

- [Article 164 - Définitions](bylaw-286-art-164.md)
- [Article 165 - Permis](bylaw-286-art-165.md)
- [Article 166 - Enseigne](bylaw-286-art-166.md)
- [Article 167 - Registre](bylaw-286-art-167.md)
- [Article 168 - Forme du fichier](bylaw-286-art-168.md)
- [Article 169 - Fichier informatique](bylaw-286-art-169.md)
- [Article 170 - Registre papier](bylaw-286-art-170.md)
- [Article 171 - Biens inscrits au registre](bylaw-286-art-171.md)
- [Article 172 - Exhibition du registre](bylaw-286-art-172.md)
- [Article 173 - Revente](bylaw-286-art-173.md)
- [Article 174 - Mineur](bylaw-286-art-174.md)