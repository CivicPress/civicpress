---
id: bylaw-286-art-245
title: Article 245 - Animaux autorisés
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:06.290Z

module: public-bylaws
slug: bylaw-286-art-245

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-11
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-244
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-246
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-245.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 245
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE XI - LES ANIMAUX
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-245.md

---

# Article 245 - Animaux autorisés

Seule la garde en captivité dans une unité d’occupation des animaux suivants est autorisée dans les limites de la ville à moins que l’un d’entre eux ne soit ou ne devienne énuméré à l’annexe 1 de la Convention sur le commerce international des espèces de faune et de flore sauvages menacées d’extinction (CITES) :

1) les animaux nés en captivité des espèces suivantes :
a) mammifères et poissons : chiens, chats, petits rongeurs de compagnie (souris et rats sélectionnés par l’homme), cochons d’Inde, lapins, gerbilles, hamsters, chinchillas, furets, degus, gerboises et poissons d’aquarium;
b) oiseaux : perruches calopsittes (cockatiels), perruches ondulées, inséparables, pinsons, canaris (serins), tourterelles, colombes, psittacidés, roselins et autres oiseaux de cage connus.
2) Tous les reptiles sauf :
a) Les crocodiliens;
b) Les lézard venimeux et ceux dont la longueur à maturité excède 1 mètre;
c) Les tortues marines ainsi que la tortu verte à oreilles rouges;
d) Les serpents venimeux et ceux dont la longueur à maturité excède 1 mètre;
3) Tous les amphibiens, à l’exception des amphibiens venimeux ou toxiques.
4) Les animaux agricoles situés en zone agricole permanente ou en zone blanche, aux endroits autorisés par les règlements d’urbanisme ou lors d’une exposition, un concours ou une foire agricole.

Malgré le premier alinéa du présent article, il est également permis de garder en captivité dans l’un ou l’autre des endroits suivants des animaux autres que ceux spécifiquement autorisés :

1) Un établissement vétérinaire, pourvu que l’animal soit sous la garde d’un vétérinaire;
2) Un établissement d’enseignement ou un centre de recherche lorsque l’animal est gardé à des fins de recherche, d’étude ou d’enseignement;
3) Un zoo dûment autorisé par permis et accrédité par l’AZAC (Aquariums et zoos accrédités du Canada) ou un endroit autorisé par les règlements d’urbanisme où sont gardés les animaux en captivité dont leur conservation sert uniquement à des fins pédagogiques, éducatives et d’exposition;
4) Le refuge de la SPA de l’Estrie.