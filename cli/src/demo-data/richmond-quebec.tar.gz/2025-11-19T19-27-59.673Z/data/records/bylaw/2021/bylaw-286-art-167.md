---
id: bylaw-286-art-167
title: Article 167 - Registre
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:41:56.480Z

module: public-bylaws
slug: bylaw-286-art-167

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-07
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-166
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-168
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-167.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 167
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE VII - PRÊTEUR SUR GAGE, REGRATTIER ET MARCHAND DE BRIC-À-BRAC
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-167.md

---

# Article 167 - Registre

Un regrattier doit, pour chaque bien usagé se trouvant dans son lieu d’affaires, inscrire dans un fichier :

1) une description du bien acheté, échangé ou reçu en gage, en indiquant le modèle, la couleur, le numéro de série ou un numéro qui y fait référence, s’il y a lieu (ce numéro devra être buriné sur les objets non identifiés);
2) la date et l’heure auxquelles il en a pris possession;
3) une description de la transaction et, le cas échéant, le prix versé ou la nature de l’échange;
4) le nom, prénom, date de naissance, adresse domiciliaire complète et numéro de téléphone de la personne qui lui remet ce bien;
5) une attestation à l’effet qu’il a vérifié l’identité de cette personne;
6) la date et l’heure auxquelles il s’en est dessaisi;
7) le nom, la date de naissance et l’adresse de la personne en faveur de qui on a disposé du bien par la suite, le cas échéant;
8) l’adresse exacte de tout local où sont entreposés tout ou partie des biens mobiliers dont il fait le commerce. Ces entrepôts ne pourront servir de point de vente, seule la place d’affaires étant reconnue à cette fin.

Ces inscriptions sont faites, en français et de manière lisible, dès que le regrattier prend possession d’un bien usagé. Elles sont également numérotées consécutivement selon l’ordre des transactions.