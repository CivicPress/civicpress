---
id: f5350eee-1c90-495d-9f15-00540af19cf1
name: Établissements de santé et services sociaux
type: geojson
category: facility
description: |-
  Localisation des points de service du réseau de la santé, incluant le CLSC de Richmond, dérivés de la couche thématique fournie par la MRC du Val-Saint-François.

  Source : MRC du Val-Saint-François – Carte « Établissements de santé et des services sociaux »
  URL : https://vsf.maps.arcgis.com/
srid: 4326
bounds:
  minLon: -72.1480033978497
  minLat: 45.66017336827896
  maxLon: -72.1400892401966
  maxLat: 45.668077364630996
metadata:
  source: CivicPress Geography System
  created: 2025-11-17T18:14:35.974Z
  updated: 2025-11-17T18:14:35.974Z
  version: 1.0.0
  accuracy: Standard
  icon_mapping: &a1
    property: FID
    type: property
    icons:
      "1":
        url: 9e905939-f063-43ff-9e57-9af8af93c3b8
        size:
          - 32
          - 32
        anchor:
          - 16
          - 32
      "10":
        url: 9e905939-f063-43ff-9e57-9af8af93c3b8
        size:
          - 32
          - 32
        anchor:
          - 16
          - 32
    default_icon: circle
    apply_to:
      - Point
created_at: 2025-11-17T18:14:35.974Z
updated_at: 2025-11-17T18:14:35.974Z
icon_mapping: *a1
---

```json
{
"type": "FeatureCollection",
"name": "EtablissementsSante",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "FID": 1, "OBJECTID": 2, "instal_cod": "51219319", "instal_nom": "CLSC DE RICHMOND", "instal_n_1": "CLSC DE RICHMOND", "etab_code": "11045150", "etab_nom": "Centre intégré universitaire de santé et de services sociaux de l'Estrie – Centre hospitalier universitaire de Sherbrooke", "etab_nom_a": "CIUSSS DE L'ESTRIE – CHUS", "rss_code": "5", "rss_nom": "Estrie", "adresse": "110, rue Barlow", "case_post": " ", "code_posta": "J0B2H0", "telephone": "(819) 826-3781", "mun_code": "42098", "mun_nom": "Richmond", "clsc_code": "5161", "clsc_nom": "Val Saint-François", "mrc_code": "420", "mrc_nom": "Le Val-Saint-François", "rls_code": "516", "rls_nom": "RLS de Val Saint-François", "ruis_code": "4", "ruis_nom": "RUIS Université de Sherbrooke", "statut_cod": "1", "md_cons_co": "2", "md_finan_c": "1", "design_min": " ", "instance": "N", "date_incor": null, "date_ouver": 844128000000, "longitude": -72.140088, "latitude": 45.660164, "chpsy": "Non", "chsgs": "Non", "chsld": "Non", "clsc": "Oui", "cpej": "Non", "crdited": "Non", "crdpa": "Non", "crdpm": "Non", "crdpv": "Non", "crdpl": " ", "crjda": "Non", "crmda": "Non", "crd": "Non", "version": "2017-03-21" }, "geometry": { "type": "Point", "coordinates": [ -72.140089240196602, 45.660173368278961 ] } },
{ "type": "Feature", "properties": { "FID": 10, "OBJECTID": 11, "instal_cod": "55617666", "instal_nom": "CHSLD DE RICHMOND", "instal_n_1": "CHSLD DE RICHMOND", "etab_code": "11045150", "etab_nom": "Centre intégré universitaire de santé et de services sociaux de l'Estrie – Centre hospitalier universitaire de Sherbrooke", "etab_nom_a": "CIUSSS DE L'ESTRIE – CHUS", "rss_code": "5", "rss_nom": "Estrie", "adresse": "980, rue McGauran", "case_post": " ", "code_posta": "J0B2H0", "telephone": "(819) 826-3711", "mun_code": "42098", "mun_nom": "Richmond", "clsc_code": "5161", "clsc_nom": "Val Saint-François", "mrc_code": "420", "mrc_nom": "Le Val-Saint-François", "rls_code": "516", "rls_nom": "RLS de Val Saint-François", "ruis_code": "4", "ruis_nom": "RUIS Université de Sherbrooke", "statut_cod": "1", "md_cons_co": "2", "md_finan_c": "1", "design_min": " ", "instance": "N", "date_incor": null, "date_ouver": 778291200000, "longitude": -72.148002, "latitude": 45.668067, "chpsy": "Non", "chsgs": "Non", "chsld": "Oui", "clsc": "Non", "cpej": "Non", "crdited": "Non", "crdpa": "Non", "crdpm": "Non", "crdpv": "Non", "crdpl": " ", "crjda": "Non", "crmda": "Non", "crd": "Non", "version": "2017-03-21" }, "geometry": { "type": "Point", "coordinates": [ -72.148003397849706, 45.668077364630996 ] } }
]
}

```
