---
id: 76d9224e-2803-4489-af76-46fe4215dad0
name: Poste de la Sûreté du Québec
type: geojson
category: facility
description: |
  Position géographique du poste de la Sûreté du Québec responsable du secteur Richmond, telle qu’indiquée sur la carte thématique de la MRC du Val-Saint-François.

  Source : MRC du Val-Saint-François – Carte « Sûreté du Québec »
  URL : https://vsf.maps.arcgis.com/
srid: 4326
bounds:
  minLon: -72.14678168906329
  minLat: 45.66560395436789
  maxLon: -72.14678168906329
  maxLat: 45.66560395436789
metadata:
  source: CivicPress Geography System
  created: 2025-11-17T18:17:48.376Z
  updated: 2025-11-18T18:35:35.355Z
  version: 1.0.0
  accuracy: Standard
  icon_mapping: &a1
    property: type
    type: property
    icons:
      Sûreté du Québec:
        url: 8600823e-ba87-4d41-bcde-0624fdfe62b4
        size:
          - 32
          - 32
        anchor:
          - 16
          - 32
    default_icon: circle
    apply_to:
      - Point
created_at: 2025-11-17T18:17:48.376Z
updated_at: 2025-11-18T18:35:35.355Z
icon_mapping: *a1
---

```json
{
"type": "FeatureCollection",
"name": "SureteQuebec",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "FID": 0, "coord_x_ll": 0, "type": "Sûreté du Québec", "Adresse": "735 Rue Gouin, Richmond, QC J0B 2H0", "lien": "https://www.sq.gouv.qc.ca/postes-de-police/poste-mrc-du-val-saint-francois/" }, "geometry": { "type": "Point", "coordinates": [ -72.146781689063289, 45.665603954367889 ] } }
]
}
```
