---
id: 4085730a-8bdd-43af-9656-e98aa91aec8b
name: Écoles publiques
type: geojson
category: facility
description: |-
  Localisation des écoles publiques (primaires, secondaires, francophones ou anglophones) présentes sur le territoire de Richmond, provenant de la carte thématique des établissements publics.

  Source : MRC du Val-Saint-François – Carte « Écoles publiques »
  URL : https://vsf.maps.arcgis.com/
srid: 4326
bounds:
  minLon: -72.142442826241
  minLat: 45.65395736895838
  maxLon: -72.13191457111111
  maxLat: 45.66550350900231
metadata:
  source: CivicPress Geography System
  created: 2025-11-17T16:12:17.308Z
  updated: 2025-11-17T17:54:50.582Z
  version: 1.0.0
  accuracy: Standard
  color_mapping: &a1
    property: TYPE
    type: property
    colors:
      Bureau: "#3b82f6"
      Bibliothèque: "#10b981"
      Centre communautaire: "#f59e0b"
      Hôtel de ville: "#ef4444"
    default_color: "#6b7280"
  icon_mapping: &a2
    property: FID
    type: property
    icons:
      "1":
        url: 742a2caa-f46d-4910-b210-f59ec4ed6ce7
        size:
          - 32
          - 32
        anchor:
          - 16
          - 32
      "18":
        url: 742a2caa-f46d-4910-b210-f59ec4ed6ce7
        size:
          - 32
          - 32
        anchor:
          - 16
          - 32
      "19":
        url: 742a2caa-f46d-4910-b210-f59ec4ed6ce7
        size:
          - 32
          - 32
        anchor:
          - 16
          - 32
    default_icon: circle
    apply_to:
      - Point
created_at: 2025-11-17T16:12:17.308Z
updated_at: 2025-11-17T17:54:50.582Z
color_mapping: *a1
icon_mapping: *a2
---

```json
{
"type": "FeatureCollection",
"name": "EcolesPubliques_Richmond_3857",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "FID": 1, "dt_maj_gdu": 1507075200000, "combine_nu": "110695310", "cd_orgns": "753058", "nom_court_": "École du Plein-Coeur", "nom_offcl_": "École du Plein-Coeur", "adrs_geo_l": "555, 7e  Avenue Nord", "adrs_geo_1": " ", "cd_postl_g": "J0B2H0", "cd_muncp_g": "42098", "nom_muncp_": "Richmond", "cd_imm": "753064", "nom_imm": "Plein-Coeur, du", "adrs_geo_2": "555, 7e Avenue Nord", "adrs_geo_3": " ", "cd_muncp_1": "42098", "nom_muncp1": "Richmond", "cd_postl_1": "J0B2H0", "presc": 1, "prim": 1, "sec": 0, "form_pro": 0, "adulte": 0, "site_web_o": "https://pleincoeur.csdessommets.qc.ca/", "coord_x_ll": -72.142442, "coord_y_ll": 45.665492, "ordre_ens": "Primaire", "style_cart": "1_OrgImm_Franco_primaire", "cd_cs": "753000", "type_cs": "Franco" }, "geometry": { "type": "Point", "coordinates": [ -72.142442826240995, 45.665503509002313 ] } },
{ "type": "Feature", "properties": { "FID": 18, "dt_maj_gdu": 1507075200000, "combine_nu": "136183504", "cd_orgns": "883024", "nom_court_": "École secondaire de Richmond", "nom_offcl_": "École secondaire régionale de Richmond", "adrs_geo_l": "375, rue Armstrong", "adrs_geo_1": " ", "cd_postl_g": "J0B2H0", "cd_muncp_g": "42098", "nom_muncp_": "Richmond", "cd_imm": "883025", "nom_imm": "Richmond Regional", "adrs_geo_2": "375, rue Armstrong", "adrs_geo_3": " ", "cd_muncp_1": "42098", "nom_muncp1": "Richmond", "cd_postl_1": "J0B2H0", "presc": 0, "prim": 0, "sec": 1, "form_pro": 0, "adulte": 0, "site_web_o": "http://richmondhigh.etsb.qc.ca/", "coord_x_ll": -72.131909, "coord_y_ll": 45.655377, "ordre_ens": "Secondaire - anglophone", "style_cart": "3_OrgImm_Anglo_secondaire", "cd_cs": "883000", "type_cs": "Anglo" }, "geometry": { "type": "Point", "coordinates": [ -72.13191457111111, 45.655388993595921 ] } },
{ "type": "Feature", "properties": { "FID": 19, "dt_maj_gdu": 1507075200000, "combine_nu": "136115192", "cd_orgns": "883018", "nom_court_": "École primaire Saint-Françis", "nom_offcl_": "École primaire Saint-Françis", "adrs_geo_l": "355, rue Collège Sud", "adrs_geo_1": " ", "cd_postl_g": "J0B2H0", "cd_muncp_g": "42098", "nom_muncp_": "Richmond", "cd_imm": "883031", "nom_imm": "St. Francis", "adrs_geo_2": "355, rue du Collège Sud", "adrs_geo_3": " ", "cd_muncp_1": "42098", "nom_muncp1": "Richmond", "cd_postl_1": "J0B2H0", "presc": 1, "prim": 1, "sec": 0, "form_pro": 0, "adulte": 0, "site_web_o": "http://stfrancis.etsb.qc.ca/", "coord_x_ll": -72.138655, "coord_y_ll": 45.653948, "ordre_ens": "Primaire - anglophone", "style_cart": "1_OrgImm_Anglo_primaire", "cd_cs": "883000", "type_cs": "Anglo" }, "geometry": { "type": "Point", "coordinates": [ -72.138651935742018, 45.65395736895838 ] } }
]
}
```
