---
id: 2d6a9336-1684-4bdf-8aa5-1d44e61c2e02
name: Bureaux municipaux
type: geojson
category: facility
description: |-
  Localisation des bureaux municipaux et bâtiments administratifs de Richmond, extraits de la couche thématique Bureaux municipaux publiée par la MRC du Val-Saint-François.

  Source : MRC du Val-Saint-François – Carte « Bureaux municipaux »
  URL : https://vsf.maps.arcgis.com/
srid: 4326
bounds:
  minLon: -72.14702423419001
  minLat: 45.66553489819842
  maxLon: -72.14702423419001
  maxLat: 45.66553489819842
metadata:
  source: CivicPress Geography System
  created: 2025-11-17T18:18:59.917Z
  updated: 2025-11-18T18:36:04.063Z
  version: 1.0.0
  accuracy: Standard
  icon_mapping: &a1
    property: FID
    type: property
    icons:
      "9":
        url: 4d0fbd13-9aa6-4a78-b976-58aa2d91e3c1
        size:
          - 32
          - 32
        anchor:
          - 16
          - 32
    default_icon: circle
    apply_to:
      - Point
created_at: 2025-11-17T18:18:59.917Z
updated_at: 2025-11-18T18:36:04.063Z
icon_mapping: *a1
---

```json
{
"type": "FeatureCollection",
"name": "BureauxMunicipaux",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "FID": 9, "FIELD3": 0, "Municipali": "Ville de Richmond", "adresse": "745, Gouin, Richmond, J0B 2H0", "LOGO": "https://image.ibb.co/gJYzhc/Ville_de_Richmond_horizontal2.jpg", "photo": " ", "Lien": "http://www.ville.richmond.qc.ca", "SiteMRC": "http://www.val-saint-francois.qc.ca/richmond" }, "geometry": { "type": "Point", "coordinates": [ -72.147024234190013, 45.665534898198423 ] } }
]
}
```
