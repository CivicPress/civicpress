---
id: 7c14aedb-956d-46fe-b1c6-5ae982ea5370
name: Bureaux de Poste Canada
type: geojson
category: facility
description: |-
  Localisation des services postaux desservant la Ville de Richmond, extraite de la carte thématique municipale de la MRC du Val-Saint-François.

  Source : MRC du Val-Saint-François – Carte « Poste Canada »
  URL : https://vsf.maps.arcgis.com/
srid: 4326
bounds:
  minLon: -72.1417870560836
  minLat: 45.65860373660351
  maxLon: -72.1417870560836
  maxLat: 45.65860373660351
metadata:
  source: CivicPress Geography System
  created: 2025-11-17T18:16:35.532Z
  updated: 2025-11-18T18:27:52.590Z
  version: 1.0.0
  accuracy: Standard
  icon_mapping: &a1
    property: type
    type: property
    icons:
      BP RICHMOND:
        url: 4db4680a-5a89-4690-9e2f-aea26b9694f4
        size:
          - 32
          - 32
        anchor:
          - 16
          - 32
    default_icon: circle
    apply_to:
      - Point
created_at: 2025-11-17T18:16:35.532Z
updated_at: 2025-11-18T18:27:52.590Z
icon_mapping: *a1
---

```json
{
"type": "FeatureCollection",
"name": "PosteCanada",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "FID": 0, "coord_x_ll": 0, "type": "BP RICHMOND", "Adresse": "10 RUE PRINCIPALE N, RICHMOND QC J0B 2H0", "lien": "https://www.canadapost.ca/cpotools/apps/fpo/personal/findPostOfficeDetail?outletId=%20gb936e36960ebb9d0_0000273686" }, "geometry": { "type": "Point", "coordinates": [ -72.141787056083601, 45.65860373660351 ] } }
]
}
```
