---
id: 16c51e7a-b200-4a02-bd38-99e3ebf043af
name: Réseau routier
type: geojson
category: route
description: |-
  Ensemble des lignes représentant les routes locales, collectrices, artères et chemins municipaux extraits de la couche ReseauRoutier utilisée par la MRC du Val-Saint-François.

  Source : MRC du Val-Saint-François – Carte thématique du territoire
  URL : https://vsf.maps.arcgis.com/
srid: 4326
bounds:
  minLon: -72.16115473360921
  minLat: 45.647985286347044
  maxLon: -72.12317396339664
  maxLat: 45.67923138719209
metadata:
  source: CivicPress Geography System
  created: 2025-11-17T16:10:27.441Z
  updated: 2025-11-17T16:10:58.822Z
  version: 1.0.0
  accuracy: Standard
  color_mapping: &a1
    property: FID
    type: property
    colors:
      "14": "#10b981"
      "21": "#06b6d4"
      "22": "#f97316"
      "24": "#ec4899"
      "25": "#14b8a6"
      "27": "#6366f1"
      "28": "#84cc16"
      "30": "#a855f7"
      "58": "#6366f1"
      "62": "#8b5cf6"
      "63": "#ec4899"
      "72": "#06b6d4"
      "135": "#3b82f6"
      "145": "#f59e0b"
      "176": "#ef4444"
      "197": "#8b5cf6"
      "315": "#3b82f6"
      "325": "#10b981"
      "338": "#f59e0b"
      "364": "#ef4444"
      "367": "#8b5cf6"
      "368": "#06b6d4"
      "378": "#f97316"
      "381": "#ec4899"
      "386": "#14b8a6"
      "387": "#6366f1"
      "390": "#84cc16"
      "394": "#a855f7"
      "406": "#3b82f6"
      "412": "#10b981"
      "415": "#f59e0b"
      "423": "#ef4444"
      "424": "#8b5cf6"
      "445": "#06b6d4"
      "485": "#f97316"
      "486": "#ec4899"
      "490": "#14b8a6"
      "494": "#6366f1"
      "495": "#84cc16"
      "527": "#a855f7"
      "530": "#3b82f6"
      "538": "#10b981"
      "543": "#f59e0b"
      "550": "#ef4444"
      "554": "#8b5cf6"
      "555": "#06b6d4"
      "556": "#f97316"
      "558": "#ec4899"
      "566": "#14b8a6"
      "585": "#84cc16"
      "588": "#a855f7"
      "601": "#3b82f6"
      "605": "#10b981"
      "612": "#f59e0b"
      "613": "#ef4444"
      "620": "#06b6d4"
      "628": "#f97316"
      "634": "#14b8a6"
      "638": "#6366f1"
      "644": "#84cc16"
      "656": "#a855f7"
      "658": "#3b82f6"
      "660": "#10b981"
      "664": "#f59e0b"
      "668": "#ef4444"
      "673": "#8b5cf6"
      "678": "#06b6d4"
      "683": "#f97316"
      "685": "#ec4899"
      "687": "#14b8a6"
      "688": "#6366f1"
      "694": "#84cc16"
      "696": "#a855f7"
      "700": "#3b82f6"
      "701": "#10b981"
      "702": "#f59e0b"
      "709": "#ef4444"
      "712": "#8b5cf6"
      "720": "#f97316"
      "723": "#ec4899"
      "725": "#14b8a6"
      "726": "#6366f1"
      "734": "#84cc16"
      "741": "#a855f7"
      "742": "#3b82f6"
      "743": "#10b981"
      "748": "#f59e0b"
      "749": "#ef4444"
      "750": "#8b5cf6"
      "753": "#06b6d4"
      "754": "#f97316"
      "758": "#ec4899"
      "762": "#14b8a6"
    default_color: "#6b7280"
created_at: 2025-11-17T16:10:27.441Z
updated_at: 2025-11-17T16:10:58.822Z
color_mapping: *a1
---

```json
{
"type": "FeatureCollection",
"name": "ReseauRoutier",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "FID": 0, "clsrte": "Artère", "gaodoreclg": "Rue Principale Nord" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.142029601210297, 45.658352591452072 ], [ -72.143691484485927, 45.662615627665559 ], [ -72.144095726363787, 45.663142991027634 ], [ -72.144994041647891, 45.664015640917818 ], [ -72.145524047665518, 45.664348374344229 ], [ -72.148497471255951, 45.665522342522088 ], [ -72.149099342496314, 45.665968067307233 ] ] } },
{ "type": "Feature", "properties": { "FID": 14, "clsrte": "Collectrice de transit", "gaodoreclg": "Route 143" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.158441937694079, 45.665509863282701 ], [ -72.158271141547189, 45.665453286251953 ] ] } },
{ "type": "Feature", "properties": { "FID": 21, "clsrte": "Collectrice de transit", "gaodoreclg": "Rue Bridge" }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ -72.148084246225267, 45.657272654465061 ], [ -72.145712677233334, 45.657668281963652 ] ], [ [ -72.143020144638925, 45.658117452929716 ], [ -72.142927916494429, 45.658132838520537 ] ] ] } },
{ "type": "Feature", "properties": { "FID": 22, "clsrte": "Collectrice de transit", "gaodoreclg": "Rue Craig" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.142927916494429, 45.658132838520537 ], [ -72.142029601210297, 45.658352591452072 ] ] } },
{ "type": "Feature", "properties": { "FID": 24, "clsrte": "Collectrice de transit", "gaodoreclg": "Rue Fair" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.149099342496314, 45.665968067307233 ], [ -72.148326791351977, 45.666269400362559 ], [ -72.147141015176942, 45.666325900129848 ] ] } },
{ "type": "Feature", "properties": { "FID": 25, "clsrte": "Collectrice de transit", "gaodoreclg": "Rue Gouin" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.147141015176942, 45.666325900129848 ], [ -72.147167964635457, 45.667072947246623 ] ] } },
{ "type": "Feature", "properties": { "FID": 27, "clsrte": "Collectrice de transit", "gaodoreclg": "Rue Principale Nord" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.149099342496314, 45.665968067307233 ], [ -72.14941375284576, 45.666495399089563 ], [ -72.150500714339543, 45.669558847375377 ], [ -72.151111568732745, 45.670299574043355 ], [ -72.15323159280328, 45.670839419507047 ], [ -72.156956637842868, 45.67088958407308 ] ] } },
{ "type": "Feature", "properties": { "FID": 28, "clsrte": "Collectrice municipale", "gaodoreclg": "Rue Craig" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.142029601210297, 45.658352591452072 ], [ -72.139738897235802, 45.65907463072633 ], [ -72.138696851506211, 45.659545520888983 ], [ -72.133953746806071, 45.663852412476167 ] ] } },
{ "type": "Feature", "properties": { "FID": 30, "clsrte": "Locale", "gaodoreclg": "10e Avenue" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.132956616840687, 45.664794108476698 ], [ -72.131195918883819, 45.66402819693208 ], [ -72.123721935719942, 45.663802188244532 ], [ -72.123353626453451, 45.663814744306663 ], [ -72.123245828619361, 45.663971694845728 ], [ -72.123173963396638, 45.665001279471021 ] ] } },
{ "type": "Feature", "properties": { "FID": 58, "clsrte": "Locale", "gaodoreclg": "6e Avenue" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.136154619252167, 45.661755512476653 ], [ -72.140116189655132, 45.66396541683261 ] ] } },
{ "type": "Feature", "properties": { "FID": 62, "clsrte": "Locale", "gaodoreclg": "7e Avenue Nord" }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ -72.13520240505099, 45.662665852961688 ], [ -72.142900967035899, 45.666231733819352 ] ], [ [ -72.142900967035899, 45.666231733819352 ], [ -72.143350124677951, 45.666275678117294 ], [ -72.14335910783079, 45.666093622944082 ], [ -72.142900967035899, 45.666231733819352 ] ] ] } },
{ "type": "Feature", "properties": { "FID": 63, "clsrte": "Locale", "gaodoreclg": "7e Avenue Sud" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.13520240505099, 45.662665852961688 ], [ -72.131977453180994, 45.661246971003138 ], [ -72.123611189979371, 45.660908548295403 ] ] } },
{ "type": "Feature", "properties": { "FID": 72, "clsrte": "Locale", "gaodoreclg": "9e Avenue" }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ -72.132687122255462, 45.663733129852453 ], [ -72.130935407451418, 45.662891866236663 ], [ -72.130441334045159, 45.662766303418763 ], [ -72.126264167974, 45.6625842368326 ] ], [ [ -72.132687122255462, 45.663733129852453 ], [ -72.132076267862246, 45.66437976418802 ] ], [ [ -72.13318119566172, 45.663952860804272 ], [ -72.132687122255462, 45.663733129852453 ] ] ] } },
{ "type": "Feature", "properties": { "FID": 135, "clsrte": "Locale", "gaodoreclg": "Chemin d'Ely" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.157205146927609, 45.653396189311025 ], [ -72.157193163206244, 45.653398523093898 ] ] } },
{ "type": "Feature", "properties": { "FID": 145, "clsrte": "Locale", "gaodoreclg": "Chemin de la Rivière" }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ -72.137678250304944, 45.647985286347044 ], [ -72.13799616558461, 45.648418897440507 ], [ -72.138200219964588, 45.648797279683215 ] ], [ [ -72.138696199196687, 45.649716984196296 ], [ -72.138849565104508, 45.650001373760311 ] ] ] } },
{ "type": "Feature", "properties": { "FID": 176, "clsrte": "Locale", "gaodoreclg": "Chemin Doyle" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.157606485412231, 45.666375128896156 ], [ -72.155836707127207, 45.665603954367889 ], [ -72.155728909293117, 45.665340284898868 ] ] } },
{ "type": "Feature", "properties": { "FID": 197, "clsrte": "Locale", "gaodoreclg": "Chemin Durocher" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.147787802181512, 45.67688407764976 ], [ -72.146188800975764, 45.677292052860864 ], [ -72.144955209461671, 45.677716636198475 ] ] } },
{ "type": "Feature", "properties": { "FID": 315, "clsrte": "Locale", "gaodoreclg": "Chemin Spooner Pond" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.148075263072428, 45.679187529442515 ], [ -72.148107960910608, 45.67923138719209 ] ] } },
{ "type": "Feature", "properties": { "FID": 325, "clsrte": "Locale", "gaodoreclg": "Chemin Thomas" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.15267332053314, 45.650981948327932 ], [ -72.14553303081837, 45.653574340371613 ] ] } },
{ "type": "Feature", "properties": { "FID": 338, "clsrte": "Locale", "gaodoreclg": "Montée du Parc" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.144122675822302, 45.667173389796091 ], [ -72.145937272696216, 45.6674809939827 ], [ -72.147158981482619, 45.6674809939827 ] ] } },
{ "type": "Feature", "properties": { "FID": 364, "clsrte": "Locale", "gaodoreclg": "Rue Aberdeen" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.140484498921609, 45.654371790380367 ], [ -72.135247320815196, 45.655081322967483 ] ] } },
{ "type": "Feature", "properties": { "FID": 367, "clsrte": "Locale", "gaodoreclg": "Rue Adams Est" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.143538770887631, 45.662151041540376 ], [ -72.141903837070529, 45.662741190821386 ], [ -72.139226857523852, 45.664549269040428 ], [ -72.138094980265862, 45.665641621333513 ] ] } },
{ "type": "Feature", "properties": { "FID": 368, "clsrte": "Locale", "gaodoreclg": "Rue Adams Ouest" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.143538770887631, 45.662151041540376 ], [ -72.144787429132549, 45.661918747032068 ] ] } },
{ "type": "Feature", "properties": { "FID": 378, "clsrte": "Locale", "gaodoreclg": "Rue Ann" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.151506827457766, 45.668115029932309 ], [ -72.150797158383298, 45.667493549219714 ] ] } },
{ "type": "Feature", "properties": { "FID": 381, "clsrte": "Locale", "gaodoreclg": "Rue Armstrong" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.133522555469696, 45.656795466370909 ], [ -72.133055431521939, 45.654842720091871 ] ] } },
{ "type": "Feature", "properties": { "FID": 386, "clsrte": "Locale", "gaodoreclg": "Rue Ball" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.137448193261292, 45.659231594553894 ], [ -72.136882254632297, 45.658792094727858 ], [ -72.135894107819766, 45.654993416763162 ] ] } },
{ "type": "Feature", "properties": { "FID": 387, "clsrte": "Locale", "gaodoreclg": "Rue Barlow" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.140241953794899, 45.659589470435449 ], [ -72.14125705006596, 45.661667616749696 ] ] } },
{ "type": "Feature", "properties": { "FID": 390, "clsrte": "Locale", "gaodoreclg": "Rue Bédard" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.140250936947751, 45.657228703100088 ], [ -72.141400780511418, 45.656820581635138 ] ] } },
{ "type": "Feature", "properties": { "FID": 394, "clsrte": "Locale", "gaodoreclg": "Rue Belmont" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.148084246225267, 45.657272654465061 ], [ -72.15271955309133, 45.655188066030064 ], [ -72.157193163206244, 45.653398523093898 ] ] } },
{ "type": "Feature", "properties": { "FID": 406, "clsrte": "Locale", "gaodoreclg": "Rue Bonnan" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.146943385814438, 45.670123809280391 ], [ -72.146781689063289, 45.66959023429748 ] ] } },
{ "type": "Feature", "properties": { "FID": 412, "clsrte": "Locale", "gaodoreclg": "Rue Brouillette" }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ -72.137960232973242, 45.663952860804272 ], [ -72.137520058484014, 45.664229092777255 ], [ -72.137008018772065, 45.664266760667957 ] ], [ [ -72.137008018772065, 45.664266760667957 ], [ -72.136451063295922, 45.664222814793 ], [ -72.136217501322051, 45.664354652314387 ], [ -72.136549877977174, 45.664423709939783 ], [ -72.137008018772065, 45.664266760667957 ] ] ] } },
{ "type": "Feature", "properties": { "FID": 415, "clsrte": "Locale", "gaodoreclg": "Rue Carpenter" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.142918933341591, 45.660600300482727 ], [ -72.140933656563675, 45.660970724316016 ] ] } },
{ "type": "Feature", "properties": { "FID": 423, "clsrte": "Locale", "gaodoreclg": "Rue Cleevemont" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.137340395427202, 45.660681919503958 ], [ -72.139514318414768, 45.661014672743768 ], [ -72.141310948983005, 45.66168017329057 ], [ -72.142326045254066, 45.662201267253288 ], [ -72.142577573533615, 45.662188710829284 ] ] } },
{ "type": "Feature", "properties": { "FID": 424, "clsrte": "Locale", "gaodoreclg": "Rue Coiteux" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.141212134301753, 45.659325772639235 ], [ -72.140241953794899, 45.659589470435449 ] ] } },
{ "type": "Feature", "properties": { "FID": 445, "clsrte": "Locale", "gaodoreclg": "Rue de l'Hévéa" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.14952155067985, 45.673237274798474 ], [ -72.14817407775368, 45.673067796253989 ], [ -72.147868650557072, 45.67309290421889 ], [ -72.147680004347407, 45.673237274798474 ] ] } },
{ "type": "Feature", "properties": { "FID": 485, "clsrte": "Locale", "gaodoreclg": "Rue des Bouleaux" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.156303831074965, 45.66204431175084 ], [ -72.157929781739213, 45.661454155124012 ], [ -72.158226225782983, 45.661466711712755 ], [ -72.158819113870507, 45.661711564630423 ], [ -72.159600648167682, 45.660914219143919 ], [ -72.159879125905746, 45.660788651890648 ] ] } },
{ "type": "Feature", "properties": { "FID": 486, "clsrte": "Locale", "gaodoreclg": "Rue des Bruyères" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.134654432727686, 45.665158226683566 ], [ -72.135229354509519, 45.665415619159603 ] ] } },
{ "type": "Feature", "properties": { "FID": 490, "clsrte": "Locale", "gaodoreclg": "Rue des Cèdres" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.131977453180994, 45.6657295108214 ], [ -72.134384938142446, 45.666947393806332 ] ] } },
{ "type": "Feature", "properties": { "FID": 494, "clsrte": "Locale", "gaodoreclg": "Rue des Chênes" }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ -72.129803530193428, 45.66768187743704 ], [ -72.132040335250892, 45.668943660148905 ] ], [ [ -72.132040335250892, 45.668943660148905 ], [ -72.132264914071925, 45.668836943309195 ], [ -72.132408644517383, 45.668987602317884 ], [ -72.132255930919086, 45.669062931670162 ], [ -72.132040335250892, 45.668943660148905 ] ] ] } },
{ "type": "Feature", "properties": { "FID": 495, "clsrte": "Locale", "gaodoreclg": "Rue des Érables" }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ -72.15549534731926, 45.661460433418732 ], [ -72.15519890327549, 45.66125952763835 ], [ -72.155315684262419, 45.661115126163395 ], [ -72.155755858751647, 45.661165352805618 ], [ -72.15549534731926, 45.661460433418732 ] ], [ [ -72.157291977887496, 45.663080209935494 ], [ -72.156806887634062, 45.66243983877429 ], [ -72.15549534731926, 45.661460433418732 ] ] ] } },
{ "type": "Feature", "properties": { "FID": 527, "clsrte": "Locale", "gaodoreclg": "Rue des Saules" }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ -72.134654432727686, 45.665158226683566 ], [ -72.13331594295434, 45.666407510804149 ] ], [ [ -72.133217128273088, 45.666369844353873 ], [ -72.132309829836132, 45.667229888650972 ] ] ] } },
{ "type": "Feature", "properties": { "FID": 530, "clsrte": "Locale", "gaodoreclg": "Rue des Sous-Bois" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.155396532638008, 45.66404703094819 ], [ -72.155288734803904, 45.663733129852453 ], [ -72.155486364166421, 45.663613846974592 ], [ -72.157857916516491, 45.662904422502969 ], [ -72.158576568743783, 45.662847919282441 ], [ -72.159762344918818, 45.662935813156395 ], [ -72.160004890045542, 45.662822806721671 ], [ -72.161154733609209, 45.661516938039576 ], [ -72.159879125905746, 45.660788651890648 ] ] } },
{ "type": "Feature", "properties": { "FID": 538, "clsrte": "Locale", "gaodoreclg": "Rue Desmarais" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.129426237774112, 45.661083734489125 ], [ -72.129345389398537, 45.662709800058835 ] ] } },
{ "type": "Feature", "properties": { "FID": 543, "clsrte": "Locale", "gaodoreclg": "Rue Donnelly" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.150617495326486, 45.66977855546051 ], [ -72.151650557903224, 45.669433299510942 ], [ -72.152279378602103, 45.669000157216971 ] ] } },
{ "type": "Feature", "properties": { "FID": 550, "clsrte": "Locale", "gaodoreclg": "Rue du Centre" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.139002278702819, 45.66215731975695 ], [ -72.137385311191409, 45.663682905513802 ] ] } },
{ "type": "Feature", "properties": { "FID": 554, "clsrte": "Locale", "gaodoreclg": "Rue du Collège" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.138184811794261, 45.650472340222272 ], [ -72.138156151886136, 45.650159803327014 ] ] } },
{ "type": "Feature", "properties": { "FID": 555, "clsrte": "Locale", "gaodoreclg": "Rue du Collège Nord" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.140924673410836, 45.658685358535188 ], [ -72.142721303979073, 45.662395891465223 ] ] } },
{ "type": "Feature", "properties": { "FID": 556, "clsrte": "Locale", "gaodoreclg": "Rue du Collège Sud" }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ -72.13811577100995, 45.64935828811403 ], [ -72.138199790786402, 45.648814998183333 ] ], [ [ -72.140924673410836, 45.658685358535188 ], [ -72.140331785323312, 45.657523804460212 ], [ -72.138705834659063, 45.651734510811892 ], [ -72.138184811794261, 45.650472340222272 ] ] ] } },
{ "type": "Feature", "properties": { "FID": 558, "clsrte": "Locale", "gaodoreclg": "Rue du Couvent" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.150078506156007, 45.668403796400341 ], [ -72.148668151159953, 45.66862978651011 ] ] } },
{ "type": "Feature", "properties": { "FID": 566, "clsrte": "Locale", "gaodoreclg": "Rue du Hêtre" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.159879125905746, 45.660788651890648 ], [ -72.159888109058585, 45.660518681342523 ], [ -72.160211502560884, 45.660085470068189 ], [ -72.160040822656896, 45.659758989791499 ] ] } },
{ "type": "Feature", "properties": { "FID": 585, "clsrte": "Locale", "gaodoreclg": "Rue Dufferin" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.140807892423908, 45.65527597192883 ], [ -72.135534781706127, 45.655834799058354 ] ] } },
{ "type": "Feature", "properties": { "FID": 588, "clsrte": "Locale", "gaodoreclg": "Rue Dyson" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.134340022378225, 45.662270327534969 ], [ -72.133297976648663, 45.663249718722696 ] ] } },
{ "type": "Feature", "properties": { "FID": 601, "clsrte": "Locale", "gaodoreclg": "Rue Futurama" }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ -72.137466159566969, 45.664241648743641 ], [ -72.137609890012428, 45.664455099741346 ] ], [ [ -72.137609890012428, 45.664455099741346 ], [ -72.137798536222107, 45.664750163015711 ], [ -72.137708704693679, 45.664976167876176 ], [ -72.137493109025499, 45.664881999295204 ], [ -72.137609890012428, 45.664455099741346 ] ] ] } },
{ "type": "Feature", "properties": { "FID": 605, "clsrte": "Locale", "gaodoreclg": "Rue Geoffroy" }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ -72.13293865053501, 45.65865396549863 ], [ -72.132767970631036, 45.658490721424769 ], [ -72.132570341268519, 45.65853467179916 ], [ -72.132633223338402, 45.658691637140393 ], [ -72.13293865053501, 45.65865396549863 ] ], [ [ -72.133271027190148, 45.659401114993443 ], [ -72.13293865053501, 45.65865396549863 ] ] ] } },
{ "type": "Feature", "properties": { "FID": 612, "clsrte": "Locale", "gaodoreclg": "Rue Gouin" }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ -72.136702591575471, 45.661297197527084 ], [ -72.137322429121525, 45.66140392874086 ], [ -72.142595539839292, 45.663789632179579 ], [ -72.145901340084862, 45.665428174859869 ], [ -72.146736773299082, 45.665942956146068 ], [ -72.147141015176942, 45.666325900129848 ] ], [ [ -72.147167964635457, 45.667072947246623 ], [ -72.147212880399664, 45.667939258309353 ], [ -72.14820102721221, 45.670657379176745 ] ] ] } },
{ "type": "Feature", "properties": { "FID": 613, "clsrte": "Locale", "gaodoreclg": "Rue Goupil" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.146000154766114, 45.654277603962839 ], [ -72.148479504950274, 45.653505269364054 ] ] } },
{ "type": "Feature", "properties": { "FID": 620, "clsrte": "Locale", "gaodoreclg": "Rue Hayes" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.126111454375703, 45.663852412476167 ], [ -72.126264167974, 45.6625842368326 ] ] } },
{ "type": "Feature", "properties": { "FID": 628, "clsrte": "Locale", "gaodoreclg": "Rue James" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.148829847911088, 45.66923242234212 ], [ -72.146260666198501, 45.669678117585747 ] ] } },
{ "type": "Feature", "properties": { "FID": 634, "clsrte": "Locale", "gaodoreclg": "Rue King" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.144904210119478, 45.663915192702355 ], [ -72.143547754040469, 45.665013835264212 ] ] } },
{ "type": "Feature", "properties": { "FID": 638, "clsrte": "Locale", "gaodoreclg": "Rue Laflamme" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.135507832247598, 45.659030680775757 ], [ -72.133783066902083, 45.659338329705307 ], [ -72.131959486875317, 45.659482735762772 ] ] } },
{ "type": "Feature", "properties": { "FID": 644, "clsrte": "Locale", "gaodoreclg": "Rue Laurier" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.13988262768126, 45.656079676605046 ], [ -72.135786309985676, 45.656820581635138 ], [ -72.133522555469696, 45.656795466370909 ], [ -72.132597290727048, 45.656902206166095 ], [ -72.129390305162744, 45.65793192079984 ] ] } },
{ "type": "Feature", "properties": { "FID": 656, "clsrte": "Locale", "gaodoreclg": "Rue Lorne" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.1391280428426, 45.653310614248063 ], [ -72.136271400239096, 45.653787832038205 ], [ -72.133055431521939, 45.654842720091871 ] ] } },
{ "type": "Feature", "properties": { "FID": 658, "clsrte": "Locale", "gaodoreclg": "Rue Manning" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.140098223349455, 45.656764072274775 ], [ -72.137564974248221, 45.657209866790261 ], [ -72.137744637305047, 45.657957035554347 ], [ -72.137663788929473, 45.658088887830736 ], [ -72.13675649049253, 45.658308640934763 ] ] } },
{ "type": "Feature", "properties": { "FID": 660, "clsrte": "Locale", "gaodoreclg": "Rue Market" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.150240202907142, 45.668855775707456 ], [ -72.150833090994681, 45.668749058700179 ], [ -72.151506827457766, 45.668115029932309 ] ] } },
{ "type": "Feature", "properties": { "FID": 664, "clsrte": "Locale", "gaodoreclg": "Rue McGauran" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.148668151159953, 45.66862978651011 ], [ -72.148829847911088, 45.66923242234212 ], [ -72.149458668609967, 45.670387456217853 ] ] } },
{ "type": "Feature", "properties": { "FID": 668, "clsrte": "Locale", "gaodoreclg": "Rue Mulvena" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.152108698698129, 45.669125706052952 ], [ -72.151614625291856, 45.668711393825511 ] ] } },
{ "type": "Feature", "properties": { "FID": 673, "clsrte": "Locale", "gaodoreclg": "Rue Old Bridge" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.139388554274987, 45.651433099524951 ], [ -72.140610263061404, 45.651181922213404 ] ] } },
{ "type": "Feature", "properties": { "FID": 678, "clsrte": "Locale", "gaodoreclg": "Rue Pearl" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.147060166801367, 45.65580968335199 ], [ -72.148461538644597, 45.655577362534146 ] ] } },
{ "type": "Feature", "properties": { "FID": 683, "clsrte": "Locale", "gaodoreclg": "Rue Pine" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.149880876793503, 45.658446771015875 ], [ -72.149611382208263, 45.658434213749842 ], [ -72.149350870775876, 45.658095166502818 ], [ -72.148542387020157, 45.658227018453935 ] ] } },
{ "type": "Feature", "properties": { "FID": 685, "clsrte": "Locale", "gaodoreclg": "Rue Principale Sud" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.142029601210297, 45.658352591452072 ], [ -72.138849565104508, 45.650001373760311 ] ] } },
{ "type": "Feature", "properties": { "FID": 687, "clsrte": "Locale", "gaodoreclg": "Rue Queen" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.14238892732395, 45.664561824934999 ], [ -72.143547754040469, 45.665013835264212 ] ] } },
{ "type": "Feature", "properties": { "FID": 688, "clsrte": "Locale", "gaodoreclg": "Rue Quinn" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.149826977876458, 45.667663044643831 ], [ -72.150797158383298, 45.667493549219714 ] ] } },
{ "type": "Feature", "properties": { "FID": 694, "clsrte": "Locale", "gaodoreclg": "Rue Riverside" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.146539143936579, 45.657479853292372 ], [ -72.146844571133187, 45.658283526337954 ] ] } },
{ "type": "Feature", "properties": { "FID": 696, "clsrte": "Locale", "gaodoreclg": "Rue Roger-Martel" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.150500714339543, 45.669558847375377 ], [ -72.149458668609967, 45.670387456217853 ], [ -72.14820102721221, 45.670657379176745 ] ] } },
{ "type": "Feature", "properties": { "FID": 700, "clsrte": "Locale", "gaodoreclg": "Rue Roy" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.135265287120873, 45.657586591782994 ], [ -72.133756117443554, 45.657536361930397 ], [ -72.132678139102623, 45.657668215197361 ] ] } },
{ "type": "Feature", "properties": { "FID": 701, "clsrte": "Locale", "gaodoreclg": "Rue Sage" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.135804276291353, 45.66012314074684 ], [ -72.135283253426564, 45.658208182479932 ], [ -72.135355118649287, 45.656851975699588 ] ] } },
{ "type": "Feature", "properties": { "FID": 702, "clsrte": "Locale", "gaodoreclg": "Rue Saint-André" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.149494601221335, 45.67188770919747 ], [ -72.15065342793784, 45.671730780852734 ], [ -72.151650557903224, 45.671893986322104 ] ] } },
{ "type": "Feature", "properties": { "FID": 709, "clsrte": "Locale", "gaodoreclg": "Rue Saint-Jean" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.151156484496951, 45.670318405949502 ], [ -72.150752242619092, 45.671046568128219 ], [ -72.150617495326486, 45.671730780852734 ] ] } },
{ "type": "Feature", "properties": { "FID": 712, "clsrte": "Locale", "gaodoreclg": "Rue Saint-Laurent" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.152468024811768, 45.670707597258037 ], [ -72.153159727580544, 45.669979430669343 ] ] } },
{ "type": "Feature", "properties": { "FID": 720, "clsrte": "Locale", "gaodoreclg": "Rue Savoie" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.135283253426564, 45.658208182479932 ], [ -72.133935780500394, 45.658377706017909 ], [ -72.133540521775373, 45.657938199489521 ], [ -72.133441707094121, 45.657561476862327 ] ] } },
{ "type": "Feature", "properties": { "FID": 723, "clsrte": "Locale", "gaodoreclg": "Rue Spooner Pond" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.149458668609967, 45.670387456217853 ], [ -72.149647314819632, 45.671065399783032 ], [ -72.149485618068496, 45.673080350237846 ], [ -72.149862910487826, 45.673701768919102 ], [ -72.14992579255771, 45.674159982314741 ], [ -72.149593415902586, 45.674837880183361 ], [ -72.148299841893461, 45.675810774811808 ], [ -72.147949498932647, 45.676350567116366 ], [ -72.147545257054801, 45.678227246351376 ], [ -72.148075263072428, 45.679187529442515 ] ] } },
{ "type": "Feature", "properties": { "FID": 725, "clsrte": "Locale", "gaodoreclg": "Rue Stanley" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.140331785323312, 45.657523804460212 ], [ -72.139559234178975, 45.657737281070418 ], [ -72.136343265461818, 45.659997571719423 ], [ -72.133360858718547, 45.660568908519807 ] ] } },
{ "type": "Feature", "properties": { "FID": 726, "clsrte": "Locale", "gaodoreclg": "Rue Sylvio-Richard" }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ -72.148030347308222, 45.676181098000107 ], [ -72.144697597604136, 45.675936308370545 ], [ -72.144392170407528, 45.67619365128558 ] ], [ [ -72.144392170407528, 45.67619365128558 ], [ -72.144230473656393, 45.676350567116366 ], [ -72.144320305184806, 45.676551418737709 ], [ -72.144607766075737, 45.676450993017149 ], [ -72.144392170407528, 45.67619365128558 ] ] ] } },
{ "type": "Feature", "properties": { "FID": 734, "clsrte": "Locale", "gaodoreclg": "Rue Trudeau" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.133360858718547, 45.660568908519807 ], [ -72.133028482063423, 45.659426229088993 ] ] } },
{ "type": "Feature", "properties": { "FID": 741, "clsrte": "Locale", "gaodoreclg": "Rue Wilfrid" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.152468024811768, 45.670707597258037 ], [ -72.151461911693559, 45.672138793633827 ], [ -72.149898843099194, 45.67383358411594 ] ] } },
{ "type": "Feature", "properties": { "FID": 742, "clsrte": "Locale", "gaodoreclg": "Rue William" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.143323175219436, 45.664147478927099 ], [ -72.143862164389901, 45.663638959180524 ] ] } },
{ "type": "Feature", "properties": { "FID": 743, "clsrte": "Locale", "gaodoreclg": "Rue Wood" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.148434589186067, 45.657806346858294 ], [ -72.14714999832978, 45.658088887830736 ] ] } },
{ "type": "Feature", "properties": { "FID": 748, "clsrte": "Nationale", "gaodoreclg": "Route 116" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.160113942254426, 45.663779064047532 ], [ -72.159582681861991, 45.663664071375194 ], [ -72.157588421931251, 45.663626403078965 ], [ -72.156142134323815, 45.663846134449678 ] ] } },
{ "type": "Feature", "properties": { "FID": 749, "clsrte": "Nationale", "gaodoreclg": "Route 143" }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ -72.156142134323815, 45.663846134449678 ], [ -72.154623981493657, 45.664329540429492 ], [ -72.15255355894466, 45.665190201815165 ] ], [ [ -72.150820018161454, 45.665910823609643 ], [ -72.14941375284576, 45.666495399089563 ] ], [ [ -72.14941375284576, 45.666495399089563 ], [ -72.147778819028659, 45.666991337542463 ], [ -72.146548127089417, 45.667104335562691 ], [ -72.145416249831428, 45.667035281244104 ], [ -72.138211761252791, 45.665673010452167 ], [ -72.137142766064684, 45.665308895593647 ], [ -72.133953746806071, 45.663852412476167 ] ], [ [ -72.14941375284576, 45.666495399089563 ], [ -72.147518307596272, 45.66714827917562 ], [ -72.146260666198501, 45.667229888650972 ], [ -72.145380317220074, 45.667142001518741 ], [ -72.138068030807332, 45.66576089989077 ], [ -72.136855305173768, 45.665327729178891 ], [ -72.133854932124819, 45.663940304773114 ] ] ] } },
{ "type": "Feature", "properties": { "FID": 750, "clsrte": "Nationale", "gaodoreclg": "Rue Craig" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.133953746806071, 45.663852412476167 ], [ -72.131124053661097, 45.666533065455361 ], [ -72.128320096273498, 45.668938979668326 ] ] } },
{ "type": "Feature", "properties": { "FID": 753, "clsrte": "Régionale", "gaodoreclg": "Avenue de Melbourne Nord" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.148084246225267, 45.657272654465061 ], [ -72.148470521797435, 45.657881691257018 ], [ -72.148731033229836, 45.659219037463885 ], [ -72.1490095109679, 45.65976526827631 ], [ -72.152872266689627, 45.663952860804272 ], [ -72.154273638532857, 45.664794108476698 ], [ -72.15573789244597, 45.665340284898868 ], [ -72.157768084988078, 45.665742066451259 ], [ -72.158055545878995, 45.665673010452167 ], [ -72.158271141547189, 45.665453286251953 ] ] } },
{ "type": "Feature", "properties": { "FID": 754, "clsrte": "Régionale", "gaodoreclg": "Avenue de Melbourne Sud" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.148084246225267, 45.657272654465061 ], [ -72.144877260660962, 45.652613617800405 ] ] } },
{ "type": "Feature", "properties": { "FID": 758, "clsrte": "Régionale", "gaodoreclg": "Route 143" }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ -72.128832472502992, 45.656784738594141 ], [ -72.128905214909324, 45.65692104257942 ] ], [ [ -72.131124053661097, 45.661152796149288 ], [ -72.128905214909324, 45.65692104257942 ] ], [ [ -72.133953746806071, 45.663852412476167 ], [ -72.132848819006597, 45.663230884438356 ], [ -72.131734908054298, 45.662144763323091 ], [ -72.128905214909324, 45.65692104257942 ] ], [ [ -72.133854932124819, 45.663940304773114 ], [ -72.132750004325345, 45.663343890049369 ], [ -72.132085251015098, 45.662766303418763 ], [ -72.131124053661097, 45.661159074477808 ] ], [ [ -72.158271141547189, 45.665453286251953 ], [ -72.156815870786915, 45.664825498070577 ], [ -72.156393662603364, 45.66437976418802 ], [ -72.156142134323815, 45.663846134449678 ] ] ] } },
{ "type": "Feature", "properties": { "FID": 762, "clsrte": "Régionale", "gaodoreclg": "Route 243" }, "geometry": { "type": "LineString", "coordinates": [ [ -72.14486717088235, 45.652602279633172 ], [ -72.144877260660962, 45.652613617800405 ] ] } }
]
}
```
