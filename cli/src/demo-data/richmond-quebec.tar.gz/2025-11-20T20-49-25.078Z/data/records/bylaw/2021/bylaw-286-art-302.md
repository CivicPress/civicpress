---
id: bylaw-286-art-302
title: Article 302 - Chien déclaré potentiellement dangereux
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:13.853Z

module: public-bylaws
slug: bylaw-286-art-302

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-11
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-301
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-303
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-302.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 302
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE XI - LES ANIMAUX
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-302.md

---

# Article 302 - Chien déclaré potentiellement dangereux

Lorsque le résultat de l’évaluation comportementale et les circonstances révèlent certaines problématiques qui nécessitent l’observation rigoureuse de normes de garde sévères en fonction du risque que constitue le chien pour la santé ou la sécurité publique, la ville peut déclarer le chien potentiellement dangereux.

La ville peut également déclarer potentiellement dangereux un chien qui a mordu ou attaqué une personne ou un animal domestique et lui a infligé une blessure.

Lorsqu’un chien est déclaré potentiellement dangereux, les normes suivantes s’appliquent :

1) il doit avoir un statut vaccinal à jour contre la rage, à moins d’une contre-indication établie par un médecin vétérinaire;
2) il doit être stérilisé, à moins d’une contre-indication établie par un médecin vétérinaire;
3) il doit être micropucé, à moins d’une contre-indication établie par un médecin vétérinaire;
4) il ne peut être gardé en présence d’un enfant de 10 ans ou moins, sauf sous la supervision constante d’une personne âgée de 18 ans ou plus;
5) sur un terrain privé, il doit être gardé à l’intérieur des limites du terrain au moyen d’une clôture ou d’un autre dispositif;
6) sur un terrain privé, le gardien doit placer une affiche à un endroit visible par toute personne qui se présente sur ce terrain annonçant la présence d’un chien déclaré potentiellement dangereux;
7) dans un endroit public ou une place publique, il doit porter en tout temps une muselière-panier;
8) dans un endroit public ou une place publique, il doit être tenu au moyen d’une laisse d’une longueur maximale de 1,25 mètre, sauf dans une aire d’exercice canin;

À l’égard d’un tel chien ou de son gardien, la ville peut également ordonner ou recommander l’une ou l’autre des mesures ou normes suivantes :

1) modifier toute norme prévue au deuxième alinéa du présent article afin de la rendre plus sévère;
2) suivre des cours d’obéissance;
3) soumettre le chien à une thérapie comportementale;
4) soumettre périodiquement le chien à évaluation comportementale;
5) isoler le chien ou le maintenir en détention;
6) obliger le gardien à se départir du chien. Dans ce cas, la ville peut demander à la SPA de l’Estrie de garder le chien au refuge afin de procéder elle-même au choix du prochain gardien ou exiger qu’elle autorise le prochain gardien préalablement au transfert;
7) l’une ou l’autre des mesures prévues à l’article 301;
8) toute autre norme ou mesure appropriée en fonction du risque que constitue le chien pour la santé ou la sécurité publique.