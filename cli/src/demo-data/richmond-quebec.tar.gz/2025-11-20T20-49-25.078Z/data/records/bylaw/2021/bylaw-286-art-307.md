---
id: bylaw-286-art-307
title: Article 307 - Décision suivant l’évaluation ou la contre-expertise
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:14.503Z

module: public-bylaws
slug: bylaw-286-art-307

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-11
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-306
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-308
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-307.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 307
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE XI - LES ANIMAUX
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-307.md

---

# Article 307 - Décision suivant l’évaluation ou la contre-expertise

Lorsqu’aucune contre-expertise n’a été demandée par le gardien, la ville peut, après avoir tenu compte des observations et documents fournis par le gardien, le cas échéant, confirmer ou modifier sa décision initiale et les mesures ordonnées suivant le délai prévu dans l’avis au gardien transmis en vertu de l’article 305.

Lorsqu’une contre-expertise a été demandée par le gardien, la ville rend sa décision et les mesures ordonnées dans les meilleurs délais suivant la contre-expertise, le tout conformément à l’article 306.

Dans tous les cas, la ville motive sa décision et les mesures ordonnées par écrit, fait référence à tout document ou renseignement qui ont été pris en considération et la notifie au gardien du chien.

Le gardien du chien doit se conformer à la décision et aux mesures ordonnées transmises par la ville, et ce, dans le délai prescrit.

Dans le cas où la décision exige l’euthanasie d’un chien toujours en possession de son gardien et que ce dernier refuse ou néglige de se conformer à l’ordre d’euthanasie dans le délai prescrit, l’autorité compétente peut recourir à ses pouvoirs d’intervention prévus au présent règlement et faire exécuter l’ordre d’euthanasie. Si le gardien du chien s’oppose à la saisie de l’animal, l’autorité compétente peut s’adresser à un juge pour obtenir la permission de capturer et saisir cet animal au domicile de son gardien, ou ailleurs, afin de procéder à son euthanasie.