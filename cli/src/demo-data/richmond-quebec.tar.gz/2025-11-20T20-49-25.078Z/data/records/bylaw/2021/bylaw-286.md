---
id: bylaw-286
title: Règlement général numéro 286
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:29.212Z

module: public-bylaws
slug: bylaw-286

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286-art-001
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-002
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-003
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-004
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-005
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-006
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-007
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-008
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-009
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-010
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-011
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-012
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-013
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-014
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-015
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-016
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-017
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-018
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-019
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-020
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-021
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-022
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-023
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-024
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-025
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-026
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-027
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-028
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-029
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-030
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-031
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-032
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-033
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-034
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-035
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-036
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-037
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-038
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-039
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-040
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-041
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-042
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-043
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-044
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-045
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-046
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-047
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-048
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-049
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-050
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-051
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-052
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-053
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-054
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-055
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-056
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-057
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-058
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-059
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-060
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-061
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-062
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-063
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-064
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-065
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-066
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-067
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-068
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-069
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-070
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-071
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-072
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-073
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-074
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-075
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-076
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-077
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-078
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-079
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-080
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-081
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-082
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-083
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-084
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-085
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-086
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-087
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-088
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-089
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-090
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-091
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-092
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-093
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-094
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-095
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-096
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-097
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-098
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-099
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-100
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-101
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-102
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-103
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-104
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-105
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-106
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-107
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-108
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-109
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-110
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-111
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-112
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-113
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-114
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-115
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-116
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-117
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-118
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-119
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-120
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-121
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-122
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-123
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-124
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-125
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-126
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-127
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-128
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-129
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-130
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-131
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-132
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-133
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-134
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-135
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-136
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-137
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-138
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-139
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-140
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-141
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-142
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-143
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-144
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-145
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-146
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-147
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-148
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-149
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-150
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-151
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-152
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-153
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-154
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-155
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-156
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-157
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-158
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-159
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-160
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-161
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-162
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-163
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-164
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-165
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-166
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-167
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-168
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-169
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-170
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-171
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-172
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-173
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-174
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-175
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-176
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-177
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-178
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-179
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-180
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-181
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-182
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-183
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-184
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-185
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-186
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-187
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-188
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-189
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-190
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-191
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-192
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-193
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-194
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-195
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-196
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-197
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-198
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-199
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-200
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-201
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-202
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-203
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-204
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-205
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-206
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-207
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-208
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-209
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-210
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-211
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-212
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-213
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-214
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-215
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-216
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-217
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-218
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-219
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-220
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-221
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-222
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-223
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-224
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-225
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-226
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-227
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-228
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-229
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-230
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-231
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-232
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-233
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-234
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-235
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-236
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-237
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-238
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-239
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-240
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-241
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-242
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-243
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-244
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-245
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-246
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-247
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-248
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-249
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-250
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-251
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-252
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-253
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-254
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-255
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-256
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-257
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-258
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-259
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-260
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-261
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-262
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-263
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-264
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-265
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-266
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-267
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-268
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-269
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-270
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-271
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-272
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-273
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-274
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-275
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-276
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-277
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-278
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-279
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-280
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-281
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-282
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-283
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-284
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-285
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-286
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-287
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-288
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-289
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-290
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-291
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-292
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-293
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-294
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-295
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-296
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-297
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-298
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-299
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-300
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-301
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-302
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-303
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-304
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-305
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-306
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-307
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-308
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-309
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-310
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-311
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-312
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-313
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-314
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-315
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-316
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-317
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-318
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-319
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-320
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-321
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-322
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-323
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-324
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-325
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-326
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-327
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-328
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-329
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-330
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-331
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-332
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-333
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-334
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-335
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-336
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-337
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-338
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-339
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-340
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-341
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-342
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-343
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-344
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-345
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-346
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-347
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-348
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-349
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-350
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-351
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-352
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-353
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-354
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-355
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-356
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-357
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-358
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-359
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-360
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-361
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-362
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-363
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-364
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-365
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-366
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-367
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-368
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-369
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-370
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-371
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-372
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-373
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-374
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-375
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-376
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-377
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-378
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-379
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-380
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-381
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-382
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-383
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-384
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-385
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-386
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-387
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-388
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-389
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-390
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-391
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-392
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-393
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-394
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-395
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-396
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-397
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-398
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-400
    type: bylaw
    category: referenced_by
    description: Child record

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286.md
    created: {}
    year: 2021
    language: fr-CA
    jurisdiction: municipal
    classification: public
    public_access: true
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: root
  file_path: bylaw/2021/bylaw-286.md

---

# Règlement général numéro 286

PROVINCE DE QUÉBEC
MRC DU VAL-SAINT-FRANÇOIS
VILLE DE RICHMOND

L’assemblée régulière du conseil de la Ville de Richmond a eu lieu par visioconférence, le lundi 15 mars 2021 à 19 h, sous la présidence du maire, Bertrand Ménard, à laquelle participent également le maire suppléant, Charles Mallette, les conseillères Céline Bourbeau et Cathy Varnier, les conseillers Guy Boutin, Clifford Lancaster et Gérard Tremblay, le directeur général Rémi-Mario Mayette ainsi que le
directeur général adjoint Alexis Grondin-Landry.

RÈGLEMENT GÉNÉRAL NUMÉRO 286 ABROGEANT LE RÈGLEMENT GÉNÉRAL NUMÉRO 275

ATTENDU QUE le Conseil a déjà adopté divers règlements relatifs aux affaires de la Ville;

ATTENDU QU’il y a lieu de refondre certains règlements déjà en vigueur;

ATTENDU QU’un avis de motion de la présentation de ce règlement a régulièrement été donné à l’occasion de l'assemblée régulière du 18 janvier 2021;

EN CONSÉQUENCE, IL EST proposé par la conseiller Tremblay et appuyé par le conseiller Mallette et RÉSOLU à l’unanimité par les conseillers d’adopter le Règlement général numéro 286 abrogeant le Règlement général numéro 275 et qu’il soit statué et décrété ce qui suit, savoir;

## TABLE DES MATIÈRES

### CHAPITRE I - DISPOSITIONS DÉCLARATOIRES ET INTERPRÉTATIVES

[Article 1 - Titre abrégé](bylaw-286-art-001.md)
[Article 2 - Territoire assujetti](bylaw-286-art-002.md)
[Article 3 - Responsabilité de la ville](bylaw-286-art-003.md)
[Article 4 - Validité](bylaw-286-art-004.md)
[Article 5 - Titres](bylaw-286-art-005.md)
[Article 6 - Définitions](bylaw-286-art-006.md)
[Article 7 - Définitions additionnelles](bylaw-286-art-007.md)

### CHAPITRE II - LES NUISANCES

[Article 8 - Eaux sales, immondices, fumier, matières malsaines](bylaw-286-art-008.md)
[Article 9 - Branches mortes, débris, ferraille, déchets, substances nauséabondes 19](bylaw-286-art-009.md)
[Article 10 - Véhicules et appareils hors d’état de fonctionnement](bylaw-286-art-010.md)
[Article 11 - Hautes herbes](bylaw-286-art-011.md)
[Article 12 - Mauvaises herbes](bylaw-286-art-012.md)
[Article 13 - Disposition des huiles](bylaw-286-art-013.md)
[Article 14 - Disposition de la neige, de la glace, des feuilles de l’herbe ou de la cendre](bylaw-286-art-014.md)
[Article 15 - Fossés, cours d’eau et lacs](bylaw-286-art-015.md)
[Article 16 - Embarcation à moteur](bylaw-286-art-016.md)
[Article 17 - Utilisation des égouts](bylaw-286-art-017.md)
[Article 18 - Déversement des eaux usées dans une place publique](bylaw-286-art-018.md)
[Article 19 - Véhicule en marche](bylaw-286-art-019.md)
[Article 20 - De la vente d’articles sur les rues, trottoirs et places publiques](bylaw-286-art-020.md)
[Article 21 - Endroit](bylaw-286-art-021.md)
[Article 22 - Immobilisation du véhicule qui sert à la vente](bylaw-286-art-022.md)
[Article 23 - Bruit répété ou continu](bylaw-286-art-023.md)
[Article 24 - Bruit et ordre](bylaw-286-art-024.md)
[Article 25 - Haut-parleur extérieur](bylaw-286-art-025.md)
[Article 26 - Haut-parleur intérieur](bylaw-286-art-026.md)
[Article 27 - Bruit extérieur](bylaw-286-art-027.md)
[Article 28 - Exception](bylaw-286-art-028.md)
[Article 29 - Tondeuse à gazon, scie à chaîne ou autre appareil similaire](bylaw-286-art-029.md)
[Article 30 - Défense de faire du bruit la nuit](bylaw-286-art-030.md)
[Article 31 - Exceptions](bylaw-286-art-031.md)
[Article 32 - Bruit ou tumulte dans une place publique ou un endroit public](bylaw-286-art-032.md)
[Article 33 - Bruit ou tumulte dans une place privée ou un endroit privé](bylaw-286-art-033.md)
[Article 34 - Bruit entre 23 h 00 et 7 h 00](bylaw-286-art-034.md)
[Article 35 - Travaux de construction](bylaw-286-art-035.md)
[Article 36 - Bruit provenant d’un véhicule](bylaw-286-art-036.md)
[Article 37 - Bruit perturbateur – Embarcation de plaisance](bylaw-286-art-037.md)
[Article 38 - Bruit tapage- Embarcation de plaisance](bylaw-286-art-038.md)
[Article 39 - Instrument de musique](bylaw-286-art-039.md)
[Article 40 - Fumée ou odeurs](bylaw-286-art-040.md)
[Article 41 - Feux en plein air](bylaw-286-art-041.md)
[Article 42 - Feux de broussailles](bylaw-286-art-042.md)
[Article 43 - Pétards, feux pyrotechniques](bylaw-286-art-043.md)
[Article 44 - Coût et validité du permis](bylaw-286-art-044.md)
[Article 45 - Conditions](bylaw-286-art-045.md)
[Article 46 - Feux prohibés](bylaw-286-art-046.md)
[Article 47 - Foyer extérieur préfabriqué](bylaw-286-art-047.md)
[Article 48 - Normes d’installation d’un foyer extérieur](bylaw-286-art-048.md)
[Article 49 - Conditions d’utilisation d’un foyer extérieur](bylaw-286-art-049.md)
[Article 50 - Fumées nocives](bylaw-286-art-050.md)
[Article 51 - Étincelle ou suie](bylaw-286-art-051.md)
[Article 52 - Projection de source de lumière ou de laser](bylaw-286-art-052.md)
[Article 53 - Provoquer de la poussière](bylaw-286-art-053.md)
[Article 54 - Bâtiment désuet](bylaw-286-art-054.md)
[Article 55 - Endommager un terrain](bylaw-286-art-055.md)
[Article 56 - Herbicides ou pesticides](bylaw-286-art-056.md)
[Article 57 - État de propreté du terrain](bylaw-286-art-057.md)
[Article 58 - Rebuts sur la propriété privée](bylaw-286-art-058.md)
[Article 59 - Salubrité](bylaw-286-art-059.md)
[Article 60 - Nuisance – Intérieur d’un bâtiment](bylaw-286-art-060.md)
[Article 61 - Pose d’affiches sans permis](bylaw-286-art-061.md)
[Article 62 - Exceptions](bylaw-286-art-062.md)
[Article 63 - Obligation d’enlever les affiches](bylaw-286-art-063.md)
[Article 64 - Identification civique des immeubles](bylaw-286-art-064.md)
[Article 65 - Appel aux services d’urgence](bylaw-286-art-065.md)
[Article 66 - Appel 9-1-1 sans urgence](bylaw-286-art-066.md)

### CHAPITRE III – LE STATIONNEMENT

[Article 67 - Stationnement sur un chemin public](bylaw-286-art-067.md)
[Article 68 - Stationnement en double](bylaw-286-art-068.md)
[Article 69 - Stationnement pour réparations](bylaw-286-art-069.md)
[Article 70 - Stationnement interdit](bylaw-286-art-070.md)
[Article 71 - Stationnement à angle](bylaw-286-art-071.md)
[Article 72 - Stationnement parallèle](bylaw-286-art-072.md)
[Article 73 - Stationnement dans le but de vendre](bylaw-286-art-073.md)
[Article 74 - Stationnement de camion](bylaw-286-art-074.md)
[Article 75 - Limite de temps de stationnement des camions](bylaw-286-art-075.md)
[Article 76 - Terrain de stationnement privé](bylaw-286-art-076.md)
[Article 77 - Stationnement limité](bylaw-286-art-077.md)
[Article 78 - Abandonner un véhicule](bylaw-286-art-078.md)
[Article 79 - Parc de stationnement - Usage](bylaw-286-art-079.md)
[Article 80 - Parc de stationnement - Transbordement](bylaw-286-art-080.md)
[Article 81 - Parc de stationnement - Entreposage](bylaw-286-art-081.md)
[Article 82 - Travaux de voirie, enlèvement, déblaiement de la neige](bylaw-286-art-082.md)
[Article 83 - Remorquage](bylaw-286-art-083.md)
[Article 84 - Stationnement de nuit durant l'hiver](bylaw-286-art-084.md)
[Article 85 - Stationnement dans une aire de jeux](bylaw-286-art-085.md)
[Article 86 - Stationnement – piste cyclable](bylaw-286-art-086.md)
[Article 87 - Stationnement dans une zone de livraison](bylaw-286-art-087.md)
[Article 88 - Stationnement dans une zone réservée au Service des incendies](bylaw-286-art-088.md)
[Article 89 - Stationnement des personnes handicapées](bylaw-286-art-089.md)
[Article 90 - Véhicule sans surveillance](bylaw-286-art-090.md)
[Article 91 - Zone de feu](bylaw-286-art-091.md)
[Article 92 - Publicité sur véhicule stationné](bylaw-286-art-092.md)
[Article 93 - Espaces de stationnement réservés aux véhicules électriques](bylaw-286-art-093.md)

### CHAPITRE IV - LA CIRCULATION

#### SECTION I - Définitions et Pouvoirs
[Article 94 - Pouvoirs des pompiers](bylaw-286-art-094.md)
[Article 95 - Pouvoirs des employés de la ville](bylaw-286-art-095.md)
[Article 96 - Pouvoirs de diriger la circulation](bylaw-286-art-096.md)
[Article 97 - Pouvoirs de remisage](bylaw-286-art-097.md)
[Article 98 - Constables spéciaux](bylaw-286-art-098.md)

#### SECTION II - Dispositions générales

[Article 99 - Signalisation](bylaw-286-art-099.md)
[Article 100 - Incendie - Signalisation](bylaw-286-art-100.md)
[Article 101 - Travaux - Signalisation](bylaw-286-art-101.md)
[Article 102 - Affiches ou dispositifs](bylaw-286-art-102.md)
[Article 103 - Véhicules d'urgence - Poursuite](bylaw-286-art-103.md)
[Article 104 - Arrêt interdit](bylaw-286-art-104.md)
[Article 105 - Boyau](bylaw-286-art-105.md)
[Article 106 - Enseignes portant une annonce commerciale](bylaw-286-art-106.md)
[Article 107 - Signalisation non autorisée](bylaw-286-art-107.md)
[Article 108 - Dommages aux signaux de circulation](bylaw-286-art-108.md)
[Article 109 - Obstruction aux signaux de circulation](bylaw-286-art-109.md)
[Article 110 - Subtilisation d'un constat d'infraction](bylaw-286-art-110.md)
[Article 111 - Ligne fraîchement peinte](bylaw-286-art-111.md)
[Article 112 - Piste cyclable](bylaw-286-art-112.md)
[Article 113 - Parade, participation](bylaw-286-art-113.md)
[Article 114 - Course, participation](bylaw-286-art-114.md)
[Article 115 - Cortège, nuisance](bylaw-286-art-115.md)
[Article 116 - Véhicule publicitaire](bylaw-286-art-116.md)

#### SECTION III - Usage des rues

[Article 117 - Déchets sur la chaussée - véhicule](bylaw-286-art-117.md)
[Article 118 - Endommager la chaussée](bylaw-286-art-118.md)
[Article 119 - Nettoyage](bylaw-286-art-119.md)
[Article 120 - Responsabilité de l'entrepreneur](bylaw-286-art-120.md)
[Article 121 - Déchets sur la chaussée ou dans les fossés](bylaw-286-art-121.md)
[Article 122 - Obstacle à la circulation](bylaw-286-art-122.md)
[Article 123 - Contrôle des animaux](bylaw-286-art-123.md)
[Article 124 - Lavage de véhicule](bylaw-286-art-124.md)
[Article 125 - Réparation](bylaw-286-art-125.md)
[Article 126 - Panneau de rabattement](bylaw-286-art-126.md)
[Article 127 - Interdiction de circuler sur une place publique](bylaw-286-art-127.md)
[Article 128 - Interdiction de circuler sur la chaussée](bylaw-286-art-128.md)
[Article 129 - Conduite sur un trottoir](bylaw-286-art-129.md)
[Article 130 - Conduite dans un parc ou un espace vert](bylaw-286-art-130.md)
[Article 131 - Conduite dans une aire de jeux](bylaw-286-art-131.md)
[Article 132 - Véhicules hors route](bylaw-286-art-132.md)
[Article 133 - Bruit avec un véhicule](bylaw-286-art-133.md)
[Article 134 - Trace de pneus sur la chaussée](bylaw-286-art-134.md)

#### SECTION IV - Piétons

[Article 135 - Passage pour piétons](bylaw-286-art-135.md)
[Article 136 - Cession de passage](bylaw-286-art-136.md)
[Article 137 - Sollicitation sur la chaussée](bylaw-286-art-137.md)
[Article 138 - Passage pour piétons](bylaw-286-art-138.md)
[Article 139 - Arrêt d’un véhicule](bylaw-286-art-139.md)
[Article 140 - Intersection en diagonale](bylaw-286-art-140.md)
[Article 141 - Trottoir](bylaw-286-art-141.md)
[Article 142 - Circulation des piétons](bylaw-286-art-142.md)
[Article 143 - Circulation des piétons – terrain privé](bylaw-286-art-143.md)
[Article 144 - Chaussée couverte d’eau](bylaw-286-art-144.md)

#### SECTION V - Bruit

[Article 145 - Ferraille](bylaw-286-art-145.md)

### CHAPITRE V – LES COLPORTEURS ET LES SOLLICITEURS

[Article 146 - Licence](bylaw-286-art-146.md)
[Article 147 - Exception - résidants](bylaw-286-art-147.md)
[Article 148 - Exception – producteurs agricoles et coopératives](bylaw-286-art-148.md)
[Article 149 - Exception - étudiants](bylaw-286-art-149.md)
[Article 150 - Exception - association à but non lucratif](bylaw-286-art-150.md)
[Article 151 - Pictogramme](bylaw-286-art-151.md)
[Article 152 - Sollicitation pare-brise](bylaw-286-art-152.md)
[Article 153 - Coût](bylaw-286-art-153.md)
[Article 154 - Conditions d’obtention](bylaw-286-art-154.md)
[Article 155 - Conditions](bylaw-286-art-155.md)
[Article 156 - Politesse](bylaw-286-art-156.md)
[Article 157 - Validité de la licence](bylaw-286-art-157.md)
[Article 158 - Port de la carte d'identité](bylaw-286-art-158.md)
[Article 159 - Port de la licence](bylaw-286-art-159.md)
[Article 160 - Heures d’affaires](bylaw-286-art-160.md)

### CHAPITRE VI – DISTRIBUTION DES SACS D’EMPLETTES

[Article 161 - Définitions](bylaw-286-art-161.md)
[Article 162 - Interdiction relative aux sacs d’emplettes](bylaw-286-art-162.md)
[Article 163 - Exceptions](bylaw-286-art-163.md)

### CHAPITRE VII - PRÊTEUR SUR GAGE, REGRATTIER ET MARCHAND DE BRIC-À-BRAC

[Article 164 - Définitions](bylaw-286-art-164.md)
[Article 165 - Permis](bylaw-286-art-165.md)
[Article 166 - Enseigne](bylaw-286-art-166.md)
[Article 167 - Registre](bylaw-286-art-167.md)
[Article 168 - Forme du fichier](bylaw-286-art-168.md)
[Article 169 - Fichier informatique](bylaw-286-art-169.md)
[Article 170 - Registre papier](bylaw-286-art-170.md)
[Article 171 - Biens inscrits au registre](bylaw-286-art-171.md)
[Article 172 - Exhibition du registre](bylaw-286-art-172.md)
[Article 173 - Revente](bylaw-286-art-173.md)
[Article 174 - Mineur](bylaw-286-art-174.md)

### CHAPITRE VIII – VENTES D’IMPRIMÉS OU D’OBJETS ÉROTIQUES

#### SECTION I - Imprimés érotiques

[Article 175 - Étalage](bylaw-286-art-175.md)
[Article 176 - Manipulation](bylaw-286-art-176.md)

#### SECTION II - Objets érotiques

[Article 177 - Étalage](bylaw-286-art-177.md)

### CHAPITRE IX - LES JEUX ÉLECTRONIQUES ET LES SALLES DE JEUX ÉLECTRONIQUES

[Article 178 - Interprétations](bylaw-286-art-178.md)
[Article 179 - Prohibition des salles de jeux électroniques](bylaw-286-art-179.md)
[Article 180 - Permis d'opération obligatoire](bylaw-286-art-180.md)
[Article 181 - Conditions](bylaw-286-art-181.md)
[Article 182 - Coût du permis](bylaw-286-art-182.md)
[Article 183 - Droit acquis](bylaw-286-art-183.md)
[Article 184 - Nombre de jeux électroniques](bylaw-286-art-184.md)
[Article 185 - Autre activité](bylaw-286-art-185.md)
[Article 186 - Heures d'ouverture](bylaw-286-art-186.md)
[Article 187 - Accès](bylaw-286-art-187.md)
[Article 188 - Bruit](bylaw-286-art-188.md)
[Article 189 - Permis d'exploitation/jeux électroniques](bylaw-286-art-189.md)
[Article 190 - Coût](bylaw-286-art-190.md)

### CHAPITRE X - DE L'ORDRE ET DE LA PAIX PUBLIQUE

[Article 191 - Consommation de boissons alcoolisées](bylaw-286-art-191.md)
[Article 192 - Consommation de boissons alcoolisées dans un endroit privé](bylaw-286-art-192.md)
[Article 193 - Consommation de boissons alcoolisées dans un véhicule](bylaw-286-art-193.md)
[Article 194 - Intoxication par l’alcool, la drogue ou les médicaments](bylaw-286-art-194.md)
[Article 195 - Ivresse place privée ou endroit privé](bylaw-286-art-195.md)
[Article 196 - Réunion tumultueuse](bylaw-286-art-196.md)
[Article 197 - Organisateur- nuisance](bylaw-286-art-197.md)
[Article 198 - Rassemblements sur une place privée](bylaw-286-art-198.md)
[Article 199 - Uriner ou déféquer](bylaw-286-art-199.md)
[Article 200 - Indécence](bylaw-286-art-200.md)
[Article 201 - Ouverture des parcs municipaux](bylaw-286-art-201.md)
[Article 202 - Accès interdit dans les places publiques](bylaw-286-art-202.md)
[Article 203 - Événement spécial](bylaw-286-art-203.md)
[Article 204 - Heures de baignade](bylaw-286-art-204.md)
[Article 205 - Étang](bylaw-286-art-205.md)
[Article 206 - Être avachi, étendu ou endormi dans une place publique](bylaw-286-art-206.md)
[Article 207 - Être avachi, étendu ou endormi dans une place privée](bylaw-286-art-207.md)
[Article 208 - Errer dans une place publique ou un endroit public](bylaw-286-art-208.md)
[Article 209 - Intrus sur un terrain privé](bylaw-286-art-209.md)
[Article 210 - École](bylaw-286-art-210.md)
[Article 211 - Mendier](bylaw-286-art-211.md)
[Article 212 - Refus de quitter un endroit public ou une place publique](bylaw-286-art-212.md)
[Article 213 - Refus de quitter une place privée ou un endroit privé](bylaw-286-art-213.md)
[Article 214 - Ordre d'un agent de la paix](bylaw-286-art-214.md)
[Article 215 - Refus de circuler](bylaw-286-art-215.md)
[Article 216 - Injures](bylaw-286-art-216.md)
[Article 217 - Injures à une personne](bylaw-286-art-217.md)
[Article 218 - Crachat endroit public ou place publique](bylaw-286-art-218.md)
[Article 219 - Crachat endroit privé ou place privée](bylaw-286-art-219.md)
[Article 220 - Mégot](bylaw-286-art-220.md)
[Article 221 - Entrave](bylaw-286-art-221.md)
[Article 222 - Sonner et frapper aux portes](bylaw-286-art-222.md)
[Article 223 - Obstruction](bylaw-286-art-223.md)
[Article 224 - Détériorer la propriété](bylaw-286-art-224.md)
[Article 225 - Graffiti](bylaw-286-art-225.md)
[Article 226 - Violence dans une place publique ou un endroit public](bylaw-286-art-226.md)
[Article 227 - Violence dans une place privée ou un endroit privé](bylaw-286-art-227.md)
[Article 228 - Arme dans une place publique](bylaw-286-art-228.md)
[Article 229 - Endommager les endroits publics ou les places publiques](bylaw-286-art-229.md)
[Article 230 - Grimper](bylaw-286-art-230.md)
[Article 231 - Disposition des déchets](bylaw-286-art-231.md)
[Article 232 - Projectiles](bylaw-286-art-232.md)
[Article 233 - Armes blanches](bylaw-286-art-233.md)
[Article 234 - Terrain privé](bylaw-286-art-234.md)
[Article 235 - Armes](bylaw-286-art-235.md)
[Article 236 - Clubs ou associations de tir](bylaw-286-art-236.md)
[Article 237 - Exceptions pour activités communautaires](bylaw-286-art-237.md)
[Article 238 - Pouvoir du Service compétent en matière de lieux récréatifs](bylaw-286-art-238.md)
[Article 239 - Troubler la paix](bylaw-286-art-239.md)
[Article 240 - Règles de conduite](bylaw-286-art-240.md)
[Article 241 - Expulsion](bylaw-286-art-241.md)
[Article 242 - Interdiction de fumer du tabac](bylaw-286-art-242.md)

### CHAPITRE XI - LES ANIMAUX

#### SECTION I - Dispositions générales relatives à la garde des animaux

[Article 243 - Entente et fonctionnaire désigné](bylaw-286-art-243.md)
[Article 244 - Loi visant à favoriser la protection des personnes par la mise en place d’un encadrement concernant les chiens](bylaw-286-art-244.md)

#### SECTION II – Dispositions générales relatives à la garde des animaux

##### Sous-section I – Animaux autorisés

[Article 245 - Animaux autorisés](bylaw-286-art-245.md)
[Article 246 - Infraction](bylaw-286-art-246.md)

##### Sous-section II – Nombre de chats et de chiens autorisés et stérilisation

[Article 247 - Nombre](bylaw-286-art-247.md)
[Article 248 - Exception](bylaw-286-art-248.md)
[Article 249 - Stérilisation](bylaw-286-art-249.md)
[Article 250 - Exception - Stérilisation](bylaw-286-art-250.md)

##### Sous-section III – Conditions minimales de garde des animaux

[Article 251 - Chien laissé seul](bylaw-286-art-251.md)
[Article 252 - Besoins vitaux](bylaw-286-art-252.md)
[Article 253 - Salubrité](bylaw-286-art-253.md)
[Article 254 - Sécurité](bylaw-286-art-254.md)
[Article 255 - Aire de repos](bylaw-286-art-255.md)
[Article 256 - Abri extérieur](bylaw-286-art-256.md)
[Article 257 - Localisation de l’abri extérieur](bylaw-286-art-257.md)
[Article 258 - Enclos extérieur pour chat ou pour chien](bylaw-286-art-258.md)
[Article 259 - Contention](bylaw-286-art-259.md)
[Article 260 - Collier](bylaw-286-art-260.md)
[Article 261 - Muselière](bylaw-286-art-261.md)
[Article 262 - Transport d'animaux](bylaw-286-art-262.md)
[Article 263 - Animal blessé ou malade](bylaw-286-art-263.md)
[Article 264 - Cession d’un animal](bylaw-286-art-264.md)
[Article 265 - Animal abandonné](bylaw-286-art-265.md)
[Article 266 - Animal mort](bylaw-286-art-266.md)

##### Sous-section IV – Normes de garde et de contrôle des animaux

[Article 267 - Normes de garde d’un animal](bylaw-286-art-267.md)
[Article 268 - Animal errant](bylaw-286-art-268.md)
[Article 269 - Signalement d’un animal errant ou abandonné](bylaw-286-art-269.md)
[Article 270 - Animal tenu en laisse à l’extérieur des limites de son terrain](bylaw-286-art-270.md)
[Article 271 - Animal gênant le passage des gens](bylaw-286-art-271.md)
[Article 272 - Transport d’un chien](bylaw-286-art-272.md)
[Article 273 - Gardien d’âge mineur](bylaw-286-art-273.md)

#### SECTION III - Nuisances

[Article 274 - Combat d'animaux](bylaw-286-art-274.md)
[Article 275 - Attaque](bylaw-286-art-275.md)
[Article 276 - Cruauté](bylaw-286-art-276.md)
[Article 277 - Excréments](bylaw-286-art-277.md)
[Article 278 - Ordures ménagères](bylaw-286-art-278.md)
[Article 279 - Dommages](bylaw-286-art-279.md)
[Article 280 - Poison](bylaw-286-art-280.md)
[Article 281 - Pigeons, écureuils, ratons laveurs, animaux en liberté](bylaw-286-art-281.md)
[Article 282 - Oeufs, nids d'oiseaux](bylaw-286-art-282.md)
[Article 283 - Canards, goélands, bernaches](bylaw-286-art-283.md)
[Article 284 - Animaux agricoles](bylaw-286-art-284.md)
[Article 285 - Événement](bylaw-286-art-285.md)
[Article 286 - Baignade](bylaw-286-art-286.md)
[Article 287 - Fontaine publique](bylaw-286-art-287.md)
[Article 288 - Nuisances causées pour les chats](bylaw-286-art-288.md)
[Article 289 - Nuisances particulières causées par les chiens](bylaw-286-art-289.md)

#### SECTION IV – Chien constituant un risque pour la santé ou la sécurité publique

[Article 290 - Chien dangereux](bylaw-286-art-290.md)
[Article 291 - Avis au gardien](bylaw-286-art-291.md)
[Article 292 - Décision de la ville](bylaw-286-art-292.md)
[Article 293 - Défaut de se conformer à la décision et pouvoir d’intervention](bylaw-286-art-293.md)
[Article 294 - Pouvoir d’intervention](bylaw-286-art-294.md)
[Article 295 - Infraction](bylaw-286-art-295.md)
[Article 296 - Comportements canins jugés inacceptables nécessitant une évaluation](bylaw-286-art-296.md)
[Article 297 - Examen sommaire](bylaw-286-art-297.md)
[Article 298 - Garde du chien](bylaw-286-art-298.md)
[Article 299 - Évaluation comportementale](bylaw-286-art-299.md)
[Article 300 - Déclarations et ordonnances](bylaw-286-art-300.md)
[Article 301 - Chien déclaré dangereux](bylaw-286-art-301.md)
[Article 302 - Chien déclaré potentiellement dangereux](bylaw-286-art-302.md)
[Article 303 - Chien déclaré à faible risque](bylaw-286-art-303.md)
[Article 304 - Chien normal](bylaw-286-art-304.md)
[Article 305 - Avis au gardien](bylaw-286-art-305.md)
[Article 306 - Contre-expertise](bylaw-286-art-306.md)
[Article 307 - Décision suivant l’évaluation ou la contre-expertise](bylaw-286-art-307.md)
[Article 308 - Confidentialité du rapport du médecin vétérinaire, de la décision et des mesures ordonnées](bylaw-286-art-308.md)
[Article 309 - Infraction](bylaw-286-art-309.md)
[Article 310 - Récidive](bylaw-286-art-310.md)
[Article 311 - Gardien irresponsable](bylaw-286-art-311.md)

#### SECTION V – Licences et permis particuliers

##### SOUS-SECTION I – Licences pour animaux

[Article 312 - Licence](bylaw-286-art-312.md)
[Article 313 - Exigibilité](bylaw-286-art-313.md)
[Article 314 - Durée](bylaw-286-art-314.md)
[Article 315 - Animal visiteur](bylaw-286-art-315.md)
[Article 316 - Demande de licence](bylaw-286-art-316.md)
[Article 317 - Durée](bylaw-286-art-317.md)
[Article 318 - Renouvellement](bylaw-286-art-318.md)
[Article 319 - Coûts des licences](bylaw-286-art-319.md)
[Article 320 - Indivisible et non remboursable](bylaw-286-art-320.md)
[Article 321 - Médaille](bylaw-286-art-321.md)
[Article 322 - Transférabilité](bylaw-286-art-322.md)
[Article 323 - Port du médaille](bylaw-286-art-323.md)
[Article 324 - Altération d'une médaille](bylaw-286-art-324.md)
[Article 325 - Gardien sans licence](bylaw-286-art-325.md)
[Article 326 - Duplicata](bylaw-286-art-326.md)
[Article 327 - Délai pour aviser de la disposition d’un animal](bylaw-286-art-327.md)
[Article 328 - Registre](bylaw-286-art-328.md)
[Article 329 - Permis de chenils ou chiens de traîneaux](bylaw-286-art-329.md)
[Article 330 - Renseignements](bylaw-286-art-330.md)
[Article 331 - Application](bylaw-286-art-331.md)

#### SECTION VI – Parcs canins

#### SECTION VII - Garde des poules pondeuses en milieu urbain

#### SECTION VIII - Refuge de la SPA de l’Estrie

[Article 332 - Garde des animaux](bylaw-286-art-332.md)
[Article 333 - Utilisation d’un tranquillisant](bylaw-286-art-333.md)
[Article 334 - Délai de conservation d’un animal gardé au refuge de la SPA de l’Estrie](bylaw-286-art-334.md)
[Article 335 - Disposition d’un animal gardé au refuge de la SPA de l’Estrie](bylaw-286-art-335.md)
[Article 336 - Frais de transport, d’hébergement et de soins vétérinaires](bylaw-286-art-336.md)
[Article 337 - Demande d’euthanasie](bylaw-286-art-337.md)
[Article 338 - Animal mort](bylaw-286-art-338.md)
[Article 339 - Responsabilité – euthanasie ou décès](bylaw-286-art-339.md)
[Article 340 - Responsabilité – dommages ou blessures](bylaw-286-art-340.md)

#### SECTION IX - Pouvoirs de l’autorité compétente

[Article 341 - Pouvoirs](bylaw-286-art-341.md)
[Article 342 - Chien constituant un danger réel et imminent](bylaw-286-art-342.md)
[Article 343 - Avis](bylaw-286-art-343.md)
[Article 344 - Récidive](bylaw-286-art-344.md)

#### SECTION X – Dispositions pénales

[Article 345 - Policier](bylaw-286-art-345.md)
[Article 346 - Patrouilleur de la SPA de l’Estrie](bylaw-286-art-346.md)
[Article 347 - Avocat](bylaw-286-art-347.md)

### CHAPITRE XII - SYSTÈMES D'ALARME

[Article 348 - Fausse alarme policière](bylaw-286-art-348.md)
[Article 349 - Fausse alarme incendie](bylaw-286-art-349.md)
[Article 350 - Responsabilité de l’utilisateur](bylaw-286-art-350.md)
[Article 351 - Déclenchement d'une fausse alarme](bylaw-286-art-351.md)
[Article 352 - Alarme d'incendie](bylaw-286-art-352.md)
[Article 353 - Durée excessive](bylaw-286-art-353.md)
[Article 354 - Autorité de faire cesser une alarme de plus de trente (30) minutes](bylaw-286-art-354.md)
[Article 355 - Remise en fonction](bylaw-286-art-355.md)

### CHAPITRE XIII - SALLES DE DANSE PUBLIQUES POUR ADOLESCENTS

[Article 356 - Horaire](bylaw-286-art-356.md)
[Article 357 - Accès interdit](bylaw-286-art-357.md)
[Article 358 - Admission interdite](bylaw-286-art-358.md)
[Article 359 - Carte d'identité](bylaw-286-art-359.md)
[Article 360 - Endroits prohibés](bylaw-286-art-360.md)
[Article 361 - Spectacles et représentations](bylaw-286-art-361.md)
[Article 362 - Responsable](bylaw-286-art-362.md)
[Article 363 - Éclairage](bylaw-286-art-363.md)
[Article 364 - Compartiments](bylaw-286-art-364.md)
[Article 365 - Vitres](bylaw-286-art-365.md)
[Article 366 - Permis d'exploitation](bylaw-286-art-366.md)
[Article 367 - Demande de permis](bylaw-286-art-367.md)
[Article 368 - Exigences non respectées](bylaw-286-art-368.md)
[Article 369 - Gardien](bylaw-286-art-369.md)
[Article 370 - Coût du permis régulier](bylaw-286-art-370.md)
[Article 371 - Validité du permis](bylaw-286-art-371.md)
[Article 372 - Coût du permis temporaire](bylaw-286-art-372.md)
[Article 373 - Affichage](bylaw-286-art-373.md)
[Article 374 - Conformité](bylaw-286-art-374.md)

### CHAPITRE XIV - DISPOSITIONS ADMINISTRATIVES

[Article 375 - Application](bylaw-286-art-375.md)
[Article 376 - Heures de visites du responsable](bylaw-286-art-376.md)

### CHAPITRE XV - SANCTIONS

[Article 377](bylaw-286-art-377.md)
[Article 378](bylaw-286-art-378.md)
[Article 379](bylaw-286-art-379.md)
[Article 380](bylaw-286-art-380.md)
[Article 381](bylaw-286-art-381.md)
[Article 382](bylaw-286-art-382.md)
[Article 383](bylaw-286-art-383.md)
[Article 384](bylaw-286-art-384.md)
[Article 385](bylaw-286-art-385.md)
[Article 386](bylaw-286-art-386.md)
[Article 387](bylaw-286-art-387.md)
[Article 388](bylaw-286-art-388.md)
[Article 389](bylaw-286-art-389.md)
[Article 390](bylaw-286-art-390.md)
[Article 391](bylaw-286-art-391.md)
[Article 392](bylaw-286-art-392.md)
[Article 393](bylaw-286-art-393.md)
[Article 394](bylaw-286-art-394.md)
[Article 395](bylaw-286-art-395.md)
[Article 396](bylaw-286-art-396.md)
[Article 397](bylaw-286-art-397.md)
[Article 398](bylaw-286-art-398.md)

### CHAPITRE XVI – ABROGATION

Article 399

### CHAPITRE XVII - ENTRÉE EN VIGUEUR

[Article 400](bylaw-286-art-400.md)


---------------------------------------------------------------------------


ADOPTÉ À RICHMOND (QUÉBEC) Ce 15e jour de mars deux mille vingt-et-un (2021).

MAIRE

DIRECTEUR GÉNÉRAL ET SECRÉTAIRE-TRÉSORIER

Je, Rémi-Mario Mayette, directeur général et secrétaire-trésorier de la ville de Richmond, certifie, par la présente, que le présent règlement est une vraie copie de l’original passé à la date ci-haut mentionnée. L’original étant gardé au Bureau de la ville.

Rémi-Mario Mayette, OMA directeur général et secrétaire-trésorier