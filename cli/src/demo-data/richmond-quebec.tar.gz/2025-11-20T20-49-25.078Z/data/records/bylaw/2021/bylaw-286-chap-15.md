---
id: bylaw-286-chap-15
title: CHAPITRE XV - SANCTIONS
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:28.795Z

module: public-bylaws
slug: bylaw-286-chap-15

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-377
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-378
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-379
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-380
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-381
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-382
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-383
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-384
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-385
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-386
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-387
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-388
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-389
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-390
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-391
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-392
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-393
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-394
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-395
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-396
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-397
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-398
    type: bylaw
    category: referenced_by
    description: Child record

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-chap-15.md
    created: {}
    year: 2021
    language: fr-CA
    jurisdiction: municipal
    classification: public
    public_access: true
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: chapter
  file_path: bylaw/2021/bylaw-286-chap-15.md

---

# CHAPITRE XV - SANCTIONS

- [Article 377](bylaw-286-art-377.md)
- [Article 378](bylaw-286-art-378.md)
- [Article 379](bylaw-286-art-379.md)
- [Article 380](bylaw-286-art-380.md)
- [Article 381](bylaw-286-art-381.md)
- [Article 382](bylaw-286-art-382.md)
- [Article 383](bylaw-286-art-383.md)
- [Article 384](bylaw-286-art-384.md)
- [Article 385](bylaw-286-art-385.md)
- [Article 386](bylaw-286-art-386.md)
- [Article 387](bylaw-286-art-387.md)
- [Article 388](bylaw-286-art-388.md)
- [Article 389](bylaw-286-art-389.md)
- [Article 390](bylaw-286-art-390.md)
- [Article 391](bylaw-286-art-391.md)
- [Article 392](bylaw-286-art-392.md)
- [Article 393](bylaw-286-art-393.md)
- [Article 394](bylaw-286-art-394.md)
- [Article 395](bylaw-286-art-395.md)
- [Article 396](bylaw-286-art-396.md)
- [Article 397](bylaw-286-art-397.md)
- [Article 398](bylaw-286-art-398.md)