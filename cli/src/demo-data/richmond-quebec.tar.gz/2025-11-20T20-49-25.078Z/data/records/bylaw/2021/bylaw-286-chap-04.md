---
id: bylaw-286-chap-04
title: CHAPITRE IV - LA CIRCULATION
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:27.277Z

module: public-bylaws
slug: bylaw-286-chap-04

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-094
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-095
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-096
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-097
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-098
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-099
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-100
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-101
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-102
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-103
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-104
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-105
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-106
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-107
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-108
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-109
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-110
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-111
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-112
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-113
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-114
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-115
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-116
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-117
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-118
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-119
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-120
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-121
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-122
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-123
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-124
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-125
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-126
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-127
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-128
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-129
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-130
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-131
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-132
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-133
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-134
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-135
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-136
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-137
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-138
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-139
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-140
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-141
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-142
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-143
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-144
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-145
    type: bylaw
    category: referenced_by
    description: Child record

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-chap-04.md
    created: {}
    year: 2021
    language: fr-CA
    jurisdiction: municipal
    classification: public
    public_access: true
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: chapter
  file_path: bylaw/2021/bylaw-286-chap-04.md

---

# CHAPITRE IV - LA CIRCULATION

- [Article 94 - Pouvoirs des pompiers](bylaw-286-art-094.md)
- [Article 95 - Pouvoirs des employés de la ville](bylaw-286-art-095.md)
- [Article 96 - Pouvoirs de diriger la circulation](bylaw-286-art-096.md)
- [Article 97 - Pouvoirs de remisage](bylaw-286-art-097.md)
- [Article 98 - Constables spéciaux](bylaw-286-art-098.md)
- [Article 99 - Signalisation](bylaw-286-art-099.md)
- [Article 100 - Incendie - Signalisation](bylaw-286-art-100.md)
- [Article 101 - Travaux - Signalisation](bylaw-286-art-101.md)
- [Article 102 - Affiches ou dispositifs](bylaw-286-art-102.md)
- [Article 103 - Véhicules d'urgence - Poursuite](bylaw-286-art-103.md)
- [Article 104 - Arrêt interdit](bylaw-286-art-104.md)
- [Article 105 - Boyau](bylaw-286-art-105.md)
- [Article 106 - Enseignes portant une annonce commerciale](bylaw-286-art-106.md)
- [Article 107 - Signalisation non autorisée](bylaw-286-art-107.md)
- [Article 108 - Dommages aux signaux de circulation](bylaw-286-art-108.md)
- [Article 109 - Obstruction aux signaux de circulation](bylaw-286-art-109.md)
- [Article 110 - Subtilisation d'un constat d'infraction](bylaw-286-art-110.md)
- [Article 111 - Ligne fraîchement peinte](bylaw-286-art-111.md)
- [Article 112 - Piste cyclable](bylaw-286-art-112.md)
- [Article 113 - Parade, participation](bylaw-286-art-113.md)
- [Article 114 - Course, participation](bylaw-286-art-114.md)
- [Article 115 - Cortège, nuisance](bylaw-286-art-115.md)
- [Article 116 - Véhicule publicitaire](bylaw-286-art-116.md)
- [Article 117 - Déchets sur la chaussée - véhicule](bylaw-286-art-117.md)
- [Article 118 - Endommager la chaussée](bylaw-286-art-118.md)
- [Article 119 - Nettoyage](bylaw-286-art-119.md)
- [Article 120 - Responsabilité de l'entrepreneur](bylaw-286-art-120.md)
- [Article 121 - Déchets sur la chaussée ou dans les fossés](bylaw-286-art-121.md)
- [Article 122 - Obstacle à la circulation](bylaw-286-art-122.md)
- [Article 123 - Contrôle des animaux](bylaw-286-art-123.md)
- [Article 124 - Lavage de véhicule](bylaw-286-art-124.md)
- [Article 125 - Réparation](bylaw-286-art-125.md)
- [Article 126 - Panneau de rabattement](bylaw-286-art-126.md)
- [Article 127 - Interdiction de circuler sur une place publique](bylaw-286-art-127.md)
- [Article 128 - Interdiction de circuler sur la chaussée](bylaw-286-art-128.md)
- [Article 129 - Conduite sur un trottoir](bylaw-286-art-129.md)
- [Article 130 - Conduite dans un parc ou un espace vert](bylaw-286-art-130.md)
- [Article 131 - Conduite dans une aire de jeux](bylaw-286-art-131.md)
- [Article 132 - Véhicules hors route](bylaw-286-art-132.md)
- [Article 133 - Bruit avec un véhicule](bylaw-286-art-133.md)
- [Article 134 - Trace de pneus sur la chaussée](bylaw-286-art-134.md)
- [Article 135 - Passage pour piétons](bylaw-286-art-135.md)
- [Article 136 - Cession de passage](bylaw-286-art-136.md)
- [Article 137 - Sollicitation sur la chaussée](bylaw-286-art-137.md)
- [Article 138 - Passage pour piétons](bylaw-286-art-138.md)
- [Article 139 - Arrêt d’un véhicule](bylaw-286-art-139.md)
- [Article 140 - Intersection en diagonale](bylaw-286-art-140.md)
- [Article 141 - Trottoir](bylaw-286-art-141.md)
- [Article 142 - Circulation des piétons](bylaw-286-art-142.md)
- [Article 143 - Circulation des piétons – terrain privé](bylaw-286-art-143.md)
- [Article 144 - Chaussée couverte d’eau](bylaw-286-art-144.md)
- [Article 145 - Ferraille](bylaw-286-art-145.md)