---
id: bylaw-286-art-259
title: Article 259 - Contention
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:08.071Z

module: public-bylaws
slug: bylaw-286-art-259

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-11
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-258
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-260
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-259.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 259
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE XI - LES ANIMAUX
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-259.md

---

# Article 259 - Contention

Tout dispositif de contention, notamment une chaîne ou une corde, utilisé pour attacher un animal à l’extérieur doit être conforme aux exigences suivantes :


1) il possède une longueur minimales de 3 mètres et il est installé de sorte que l’animal ne puisse sortir du terrain de son gardien;
2) il est suffisamment solide pour retenir l’animal en fonction de sa taille et de son poids;
3) il ne risque pas de se coincer ou de se raccourcir, notamment en s’enroulant autour d’un obstacle;
4) il n’entraîne pas d’inconfort pour l’animal, notamment en raison de son poids;
5) il permet à l’animal de se mouvoir sans danger ni contrainte;
6) il permet à l’animal d’avoir accès à son eau et à sa nourriture.

De plus, la période de contention ne doit pas excéder 12 heures consécutives par période de 24 heures.