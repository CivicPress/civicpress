---
id: bylaw-286-art-247
title: Article 247 - Nombre
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:06.543Z

module: public-bylaws
slug: bylaw-286-art-247

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-11
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-246
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-248
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-247.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 247
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE XI - LES ANIMAUX
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-247.md

---

# Article 247 - Nombre

Il est interdit de garder, dans une unité d’occupation, un nombre total combiné de chiens ou de chats supérieur aux quantités indiquées dans le tableau suivant selon les catégories qui y sont mentionnées :

| Catégorie de gardien | Nombre d'animaux |
|:---------------------|:-----------------|
| Tout gardien autre que ceux mentionnés aux autres catégories du présent tableau | Nombre total combiné de chats et de chiens = 4 |
| Lieu d’élevage de chats de race enregistrés auprès de l’Association féline canadienne | Se référer à la première catégorie de gardien |
| Lieu d’élevage de chats de race enregistrés auprès de l’Association féline canadienne ( aux endroits autorisés les règlements d’urbanisme ) | 14 chats et 2 chiens |
| Lieu d’élevage de chiens de race enregistrés auprès du Club canin canadien | Se référer à la première catégorie de gardien |
| Lieu d’élevage de chiens de race enregistrés auprès du Club canin canadien (aux endroits autorisés les règlements d’urbanisme) | 2 chats et 14 chiens |
| Entreprise agricole | Nombre de chats illimité  et 4 chiens |