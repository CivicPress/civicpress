---
id: bylaw-286-art-329
title: Article 329 - Permis de chenils ou chiens de traîneaux
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:17.349Z

module: public-bylaws
slug: bylaw-286-art-329

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-11
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-328
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-330
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-329.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 329
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE XI - LES ANIMAUX
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-329.md

---

# Article 329 - Permis de chenils ou chiens de traîneaux

Un permis de chenil ou de chiens de traîneaux peut être émis par le responsable de l’application du présent règlement. Le coût du permis est défini selon le règlement de tarification. Ce permis donne droit de garder huit (8) chiens au total dont un maximum de quatre (4) chiens reproducteurs; tous les autres doivent être stérilisés.

Tous les chiens doivent être micropucés et porter le médaillon d’identification. Le demandeur d’un tel permis doit avoir l’autorisation écrite de la division de l’urbanisme de la ville avant l’émission du permis. Il doit se conformer à tous les articles du présent règlement incluant le paiement des licences annuelles pour ses chiens. Il doit se conformer aux normes de garde généralement reconnues et être
inspecté une fois par année par le responsable de l’application du présent règlement.

Tout manquement à ces dispositions entraînera la révocation immédiate du permis.