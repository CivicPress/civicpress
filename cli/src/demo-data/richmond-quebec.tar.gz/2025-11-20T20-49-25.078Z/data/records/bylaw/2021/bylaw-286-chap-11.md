---
id: bylaw-286-chap-11
title: CHAPITRE XI - LES ANIMAUX
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:28.228Z

module: public-bylaws
slug: bylaw-286-chap-11

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-243
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-244
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-245
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-246
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-247
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-248
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-249
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-250
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-251
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-252
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-253
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-254
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-255
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-256
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-257
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-258
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-259
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-260
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-261
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-262
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-263
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-264
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-265
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-266
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-267
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-268
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-269
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-270
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-271
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-272
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-273
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-274
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-275
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-276
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-277
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-278
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-279
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-280
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-281
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-282
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-283
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-284
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-285
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-286
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-287
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-288
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-289
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-290
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-291
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-292
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-293
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-294
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-295
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-296
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-297
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-298
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-299
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-300
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-301
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-302
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-303
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-304
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-305
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-306
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-307
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-308
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-309
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-310
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-311
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-312
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-313
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-314
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-315
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-316
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-317
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-318
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-319
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-320
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-321
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-322
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-323
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-324
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-325
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-326
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-327
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-328
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-329
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-330
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-331
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-332
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-333
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-334
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-335
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-336
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-337
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-338
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-339
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-340
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-341
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-342
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-343
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-344
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-345
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-346
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-347
    type: bylaw
    category: referenced_by
    description: Child record

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-chap-11.md
    created: {}
    year: 2021
    language: fr-CA
    jurisdiction: municipal
    classification: public
    public_access: true
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: chapter
  file_path: bylaw/2021/bylaw-286-chap-11.md

---

# CHAPITRE XI - LES ANIMAUX

- [Article 243 - Entente et fonctionnaire désigné](bylaw-286-art-243.md)
- [Article 244 - Loi visant à favoriser la protection des personnes par la mise en place d’un encadrement concernant les chiens](bylaw-286-art-244.md)
- [Article 245 - Animaux autorisés](bylaw-286-art-245.md)
- [Article 246 - Infraction](bylaw-286-art-246.md)
- [Article 247 - Nombre](bylaw-286-art-247.md)
- [Article 248 - Exception](bylaw-286-art-248.md)
- [Article 249 - Stérilisation](bylaw-286-art-249.md)
- [Article 250 - Exception - Stérilisation](bylaw-286-art-250.md)
- [Article 251 - Chien laissé seul](bylaw-286-art-251.md)
- [Article 252 - Besoins vitaux](bylaw-286-art-252.md)
- [Article 253 - Salubrité](bylaw-286-art-253.md)
- [Article 254 - Sécurité](bylaw-286-art-254.md)
- [Article 255 - Aire de repos](bylaw-286-art-255.md)
- [Article 256 - Abri extérieur](bylaw-286-art-256.md)
- [Article 257 - Localisation de l’abri extérieur](bylaw-286-art-257.md)
- [Article 258 - Enclos extérieur pour chat ou pour chien](bylaw-286-art-258.md)
- [Article 259 - Contention](bylaw-286-art-259.md)
- [Article 260 - Collier](bylaw-286-art-260.md)
- [Article 261 - Muselière](bylaw-286-art-261.md)
- [Article 262 - Transport d'animaux](bylaw-286-art-262.md)
- [Article 263 - Animal blessé ou malade](bylaw-286-art-263.md)
- [Article 264 - Cession d’un animal](bylaw-286-art-264.md)
- [Article 265 - Animal abandonné](bylaw-286-art-265.md)
- [Article 266 - Animal mort](bylaw-286-art-266.md)
- [Article 267 - Normes de garde d’un animal](bylaw-286-art-267.md)
- [Article 268 - Animal errant](bylaw-286-art-268.md)
- [Article 269 - Signalement d’un animal errant ou abandonné](bylaw-286-art-269.md)
- [Article 270 - Animal tenu en laisse à l’extérieur des limites de son terrain](bylaw-286-art-270.md)
- [Article 271 - Animal gênant le passage des gens](bylaw-286-art-271.md)
- [Article 272 - Transport d’un animal](bylaw-286-art-272.md)
- [Article 273 - Gardien d’âge mineur](bylaw-286-art-273.md)
- [Article 274 - Combat d'animaux](bylaw-286-art-274.md)
- [Article 275 - Attaque](bylaw-286-art-275.md)
- [Article 276 - Cruauté](bylaw-286-art-276.md)
- [Article 277 - Excréments](bylaw-286-art-277.md)
- [Article 278 - Ordures ménagères](bylaw-286-art-278.md)
- [Article 279 - Dommages](bylaw-286-art-279.md)
- [Article 280 - Poison](bylaw-286-art-280.md)
- [Article 281 - Pigeons, écureuils, ratons laveurs, animaux en liberté](bylaw-286-art-281.md)
- [Article 282 - Oeufs, nids d'oiseaux](bylaw-286-art-282.md)
- [Article 283 - Canards, goélands, bernaches](bylaw-286-art-283.md)
- [Article 284 - Animaux agricoles](bylaw-286-art-284.md)
- [Article 285 - Événement](bylaw-286-art-285.md)
- [Article 286 - Baignade](bylaw-286-art-286.md)
- [Article 287 - Fontaine publique](bylaw-286-art-287.md)
- [Article 288 - Nuisances causées pour les chats](bylaw-286-art-288.md)
- [Article 289 - Nuisances particulières causées par les chiens](bylaw-286-art-289.md)
- [Article 290 - Chien dangereux](bylaw-286-art-290.md)
- [Article 291 - Avis au gardien](bylaw-286-art-291.md)
- [Article 292 - Décision de la ville](bylaw-286-art-292.md)
- [Article 293 - Défaut de se conformer à la décision et pouvoir d’intervention](bylaw-286-art-293.md)
- [Article 294 - Pouvoir d’intervention](bylaw-286-art-294.md)
- [Article 295 - Infraction](bylaw-286-art-295.md)
- [Article 296 - Comportements canins jugés inacceptables nécessitant une évaluation](bylaw-286-art-296.md)
- [Article 297 - Examen sommaire](bylaw-286-art-297.md)
- [Article 298 - Garde du chien](bylaw-286-art-298.md)
- [Article 299 - Évaluation comportementale](bylaw-286-art-299.md)
- [Article 300 - Déclarations et ordonnances](bylaw-286-art-300.md)
- [Article 301 - Chien déclaré dangereux](bylaw-286-art-301.md)
- [Article 302 - Chien déclaré potentiellement dangereux](bylaw-286-art-302.md)
- [Article 303 - Chien déclaré à faible risque](bylaw-286-art-303.md)
- [Article 304 - Chien normal](bylaw-286-art-304.md)
- [Article 305 - Avis au gardien](bylaw-286-art-305.md)
- [Article 306 - Contre-expertise](bylaw-286-art-306.md)
- [Article 307 - Décision suivant l’évaluation ou la contre-expertise](bylaw-286-art-307.md)
- [Article 308 - Confidentialité du rapport du médecin vétérinaire, de la décision et des mesures ordonnées](bylaw-286-art-308.md)
- [Article 309 - Infraction](bylaw-286-art-309.md)
- [Article 310 - Récidive](bylaw-286-art-310.md)
- [Article 311 - Gardien irresponsable](bylaw-286-art-311.md)
- [Article 312 - Licence](bylaw-286-art-312.md)
- [Article 313 - Exigibilité](bylaw-286-art-313.md)
- [Article 314 - Durée](bylaw-286-art-314.md)
- [Article 315 - Animal visiteur](bylaw-286-art-315.md)
- [Article 316 - Demande de licence](bylaw-286-art-316.md)
- [Article 317 - Durée](bylaw-286-art-317.md)
- [Article 318 - Renouvellement](bylaw-286-art-318.md)
- [Article 319 - Coûts des licences](bylaw-286-art-319.md)
- [Article 320 - Indivisible et non remboursable](bylaw-286-art-320.md)
- [Article 321 - Médaille](bylaw-286-art-321.md)
- [Article 322 - Transférabilité](bylaw-286-art-322.md)
- [Article 323 - Port de la médaille](bylaw-286-art-323.md)
- [Article 324 - Altération d'une médaille](bylaw-286-art-324.md)
- [Article 325 - Gardien sans licence](bylaw-286-art-325.md)
- [Article 326 - Duplicata](bylaw-286-art-326.md)
- [Article 327 - Délai pour aviser de la disposition d’un animal](bylaw-286-art-327.md)
- [Article 328 - Registre](bylaw-286-art-328.md)
- [Article 329 - Permis de chenils ou chiens de traîneaux](bylaw-286-art-329.md)
- [Article 330 - Renseignements](bylaw-286-art-330.md)
- [Article 331 - Application](bylaw-286-art-331.md)
- [Article 332 - Garde des animaux](bylaw-286-art-332.md)
- [Article 333 - Utilisation d’un tranquillisant](bylaw-286-art-333.md)
- [Article 334 - Délai de conservation d’un animal gardé au refuge de la SPA de l’Estrie](bylaw-286-art-334.md)
- [Article 335 - Disposition d’un animal gardé au refuge de la SPA de l’Estrie](bylaw-286-art-335.md)
- [Article 336 - Frais de transport, d’hébergement et de soins vétérinaires](bylaw-286-art-336.md)
- [Article 337 - Demande d’euthanasie](bylaw-286-art-337.md)
- [Article 338 - Animal mort](bylaw-286-art-338.md)
- [Article 339 - Responsabilité – euthanasie ou décès](bylaw-286-art-339.md)
- [Article 340 - Responsabilité – dommages ou blessures](bylaw-286-art-340.md)
- [Article 341 - Pouvoirs](bylaw-286-art-341.md)
- [Article 342 - Chien constituant un danger réel et imminent](bylaw-286-art-342.md)
- [Article 343 - Avis](bylaw-286-art-343.md)
- [Article 344 - Récidive](bylaw-286-art-344.md)
- [Article 345 - Policier](bylaw-286-art-345.md)
- [Article 346 - Patrouilleur de la SPA de l’Estrie](bylaw-286-art-346.md)
- [Article 347 - Avocat](bylaw-286-art-347.md)