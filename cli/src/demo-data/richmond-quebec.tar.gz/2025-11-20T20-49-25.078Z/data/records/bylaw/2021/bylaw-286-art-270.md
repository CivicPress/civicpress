---
id: bylaw-286-art-270
title: Article 270 - Animal tenu en laisse à l’extérieur des limites de son terrain
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:09.539Z

module: public-bylaws
slug: bylaw-286-art-270

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-11
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-269
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-271
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-270.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 270
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE XI - LES ANIMAUX
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-270.md

---

# Article 270 - Animal tenu en laisse à l’extérieur des limites de son terrain

Il est interdit pour un gardien de se promener avec son animal à l’extérieur des limites de son unité d’occupation sans tenir l’animal en laisse ou autrement en assumer le contrôle et le surveiller en tout temps. En l’absence d’un dispositif de contention pour retenir l’animal, celui-ci est présumé ne pas être sous le contrôle de son gardien.

Dans un endroit public et dans une place publique, le gardien doit constamment tenir en laisse son animal. S’il s’agit d’un chien, les exigences suivantes s’ajoutent :

1) la laisse doit être d’une longueur maximale de 1,85 mètres;
2) lorsque son poids est de 20 kilogrammes et plus, le chien doit porter un licou ou un harnais attaché à sa laisse;

L’exigence prévue au deuxième alinéa ne s’applique pas dans un parc canin ni dans un endroit public utilisé comme aire d’exercice canin ou utilisé pour une activité canine telle qu’une exposition, une compétition ou un cours de dressage.

L’usage d’un dispositif de contention extensible est interdit dans un endroit public et dans une place publique.

Le présent article ne s’applique pas aux chats.