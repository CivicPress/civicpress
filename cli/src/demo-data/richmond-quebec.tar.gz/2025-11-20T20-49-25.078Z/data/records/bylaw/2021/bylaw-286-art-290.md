---
id: bylaw-286-art-290
title: Article 290 - Chien dangereux
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:12.256Z

module: public-bylaws
slug: bylaw-286-art-290

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-11
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-289
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-291
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-290.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 290
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE XI - LES ANIMAUX
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-290.md

---

# Article 290 - Chien dangereux

Tout chien dangereux au sens du présent article constitue un risque pour la santé ou la sécurité publique.

La ville peut déclarer un chien comme étant dangereux dans l’une ou l’autre des situations suivantes :

1) il a mordu ou attaqué une personne lui causant la mort;
2) il a mordu ou attaqué une personne lui infligeant une blessure grave, soit une blessure physique pouvant entraîner la mort ou résultant en des conséquences physiques importantes;
3) suite à une évaluation comportementale menée conformément à la présente section.

Lorsque la ville déclare le chien comme étant dangereux, sa décision doit contenir l’ordre d’euthanasier le chien dans un délai maximal de 48 heures. Avant la fin de ce délai, le gardien du chien doit transmettre à la ville la confirmation écrite signée du vétérinaire ayant procédé à l’euthanasie. À défaut, il est présumé ne pas s’être conformé à l’ordre.

Jusqu’à ce que le chien déclaré dangereux soit euthanasié, son gardien doit le museler au moyen d’une muselière-panier dès qu’il se trouve à l’extérieur de sa résidence.