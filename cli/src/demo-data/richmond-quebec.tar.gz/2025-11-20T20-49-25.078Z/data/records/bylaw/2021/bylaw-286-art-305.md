---
id: bylaw-286-art-305
title: Article 305 - Avis au gardien
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:14.243Z

module: public-bylaws
slug: bylaw-286-art-305

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-11
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-304
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-306
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-305.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 305
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE XI - LES ANIMAUX
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-305.md

---

# Article 305 - Avis au gardien

Avant de rendre sa décision et d’ordonner les mesures ou normes appropriées en vertu des articles 301, 302 et 303, la ville notifie au gardien un avis écrit afin de l’informer des éléments suivants :

1) de l’intention de la ville quant à sa décision et aux mesures ordonnées;
2) des motifs sur lesquels elle se base pour en arriver à cette décision;
3) qu’il possède un délai de 72 heures afin de lui présenter ses observations écrites, produire des documents pour compléter son dossier ou demander une contre- expertise conformément à l’article 306, s’il y a lieu.

Si le gardien du chien est inconnu ou introuvable, la ville peut sans délai rendre sa décision et ordonner les mesures appropriées, notamment euthanasier ou faire euthanasier le chien lorsqu’il est déclaré dangereux.