---
id: bylaw-286-art-070
title: Article 70 - Stationnement interdit
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:41:44.547Z

module: public-bylaws
slug: bylaw-286-art-070

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-03
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-069
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-071
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-070.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 70
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE III – LE STATIONNEMENT
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-070.md

---

# Article 70 - Stationnement interdit

Sauf en cas de nécessité ou dans les cas où une autre disposition du présent chapitre le permet, il est défendu d'immobiliser ou de stationner un véhicule routier :

1) à moins de cinq (5) mètres d’une intersection, sauf aux endroits où des affiches permettent le stationnement sur des distances inférieures ou supérieures, et là où des espaces de stationnement sont aménagés;
2) dans l'espace situé entre la ligne d'un lot et la rue proprement dite;
3) à angle perpendiculairement à une zone de rue;
4) sur le côté gauche de la chaussée d’un chemin public composé de deux chaussées séparées par une plate-bande ou autre dispositif et sur lequel la circulation se fait dans un sens seulement;
5) dans les six (6) mètres d'une obstruction ou tranchée dans une rue;
6) aux endroits où le dépassement est prohibé, sauf s'il y a des espaces de stationnement aménagés;
7) en face d'une entrée privée;
8) en face d'une entrée ou d'une sortie de salle de cinéma ou d'une salle de réunions publiques;
9) dans un parc à moins d'une indication expresse ou contraire;
10) dans un espace de verdure, sur les bordures, bandes médianes, plates-bandes ou sur tout espace qui sert de division à deux ou plusieurs voies de circulation;
11) à un endroit interdit par la signalisation;
12) à moins de cinq (5) mètres d’une borne-fontaine et d’un signal d’arrêt;
13) sur un trottoir;
14) à moins de cinq (5) mètres d’un passage pour piétons ou pour cyclistes identifié;
15) à un endroit réservé aux femmes enceintes ou aux parents d’un jeune enfant, dûment identifié;
16) sur un espace réservé aux taxis;
17) sur une voie ferrée;
18) sur un pont;
19) sur un viaduc, dans un tunnel;
20) de manière à cacher un signal de circulation;
21) dans une zone de terrains de jeux identifiée par affiche;
22) dans une zone d’arrêt d’autobus;
23) dans une zone de débarcadère.

Malgré les interdictions prévues au présent article et dans la mesure où cette manœuvre peut être effectuée sans danger, le conducteur d'un véhicule routier qui transporte une personne handicapée peut immobiliser son véhicule pour permettre à cette personne d'y monter ou d'en descendre.