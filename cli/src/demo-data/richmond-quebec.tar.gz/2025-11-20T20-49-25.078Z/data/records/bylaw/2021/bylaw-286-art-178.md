---
id: bylaw-286-art-178
title: Article 178 - Interprétations
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:41:57.867Z

module: public-bylaws
slug: bylaw-286-art-178

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-09
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-177
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-179
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-178.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 178
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE IX - LES JEUX ÉLECTRONIQUES ET LES SALLES DE JEUX ÉLECTRONIQUES
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-178.md

---

# Article 178 - Interprétations

À moins de déclaration contraire, expresse ou résultant du contexte de la disposition, les expressions, termes et mots suivants ont dans le présent chapitre, le sens et l'application que leur attribue le présent article :

Appareil de catégorie A désigne :

1) un appareil muni d'un dispositif permettant :
a) lors de chaque partie, de multiplier ses chances de gagner des parties gratuites ou du temps de jeu additionnel par quelque opération que ce soit;
b) d'effacer une ou plusieurs parties gratuites ou du temps de jeu additionnel accumulé et de conserver autrement ce qui a été effacé;
c) d'accumuler plus de quatre-vingt-dix-neuf (99) parties gratuites.
2) un appareil, connu en anglais sous le nom de one-armed bandit, dont le fonctionnement se fait en actionnant un mécanisme par lequel diverses représentations d'objets se placent en ligne de sorte que le joueur peut gagner, selon la nature et le nombre de représentations d'objets alignés, un nombre plus ou moins grand de parties gratuites.

Appareil de catégorie B désigne :

1) un billard électrique, autrement connu sous le nom de machine à boules ou, en anglais, sous le nom de pinball machine;
2) un groupe d'appareils dont l'opération ne vise que le divertissement sans possibilité d'accumuler des parties gratuites, du temps de jeu additionnel ou de gagner un prix et constituant un seul ensemble inséparable bien que chacun d'eux fonctionne de façon indépendante;
3) un ordinateur ou un dispositif électronique de visualisation dont l'opération peut résulter en l'attribution de parties gratuites ou de temps de jeu additionnel;
4) un jeu d'adresse de fabrication industrielle ne pouvant être joué que par une personne à la fois et dont l'opération peut résulter en l'attribution d'un prix de quelque nature qu'il soit autre qu'une partie gratuite ou du temps de jeu additionnel;
5) un jeu d'adresse du genre de celui décrit au paragraphe 4 et permettant une compétition entre les joueurs.

Jeux électroniques : Désigne un appareil de catégorie (A) ou de catégorie (B) permis par la loi et pour l'utilisation duquel une somme ou un jeton est exigé, mais ne comprend pas un appareil destiné à l'amusement ou à la récréation d'un enfant en bas âge ou un appareil à reproduire le son, une table de billard, de pool, de snooker ou une allée de quilles.

Salle de jeux électroniques : Désigne un local où aucune boisson alcoolique n'est servie ou un local pour lequel un permis de restaurant pour vendre ou un permis de restaurant pour servir tels que définis aux articles 28 et 28.1 de la Loi sur les permis d’alcool et qui, pour fins d'amusements, possède plus de quatre (4) appareils de catégorie A ou plus de quatre (4) appareils de catégorie B mis à la disposition du public moyennant un montant d'argent ou un jeton pour leur utilisation.