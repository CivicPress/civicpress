---
id: bylaw-286-art-341
title: Article 341 - Pouvoirs
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:18.919Z

module: public-bylaws
slug: bylaw-286-art-341

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-11
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-340
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-342
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-341.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 341
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE XI - LES ANIMAUX
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-341.md

---

# Article 341 - Pouvoirs

L’autorité compétente exerce les pouvoirs qui lui sont confiés par le présent chapitre et notamment, elle peut :



1) Visiter et examiner toute unité d’occupation aux fins d’application du présent règlement;
2) Lorsqu’elle a des motifs raisonnables de croire qu’un chien se trouve dans un lieu ou un véhicule;
a) Y pénétrer à toute heure raisonnable pour en faire l’inspection, sauf s’il s’agit d’une maison d’habitation;
b) S’il s’agit d’une maison d’habitation, exiger que le propriétaire ou l’occupant des lieux lui montre le chien sur-le-champ;
c) Ordonner l’immobilisation du véhicule pour en faire l’inspection;
d) Procéder à l’examen de ce chien;
e) Prendre des photographies ou des enregistrements;
f) Exiger de quiconque la communication, pour examen, reproduction ou établissement d’extrait, de tout livre, registre, dossier ou autre document, si elle a des motifs raisonnables de croire qu’il contient des renseignements relatifs à l’application du présent règlement;
g) Exiger de quiconque tout renseignement relatif à l’application du présent règlement.

Lorsque le lieu où le véhicule est inoccupé, l’inspecteur doit y laisser un avis indiquant
son nom, le moment de l’inspection ainsi que les motifs de celle-ci.

3) saisir et garder au refuge de la SPA de l’Estrie tout animal non licencié, dangereux, errant, abandonné, constituant une nuisance, pour lequel il existe des motifs raisonnables de croire qu’il constitue un risque pour la santé ou la sécurité publique ou qui ne fait pas partie des animaux autorisés en vertu du présent chapitre;
4) en plus de ce qui est déjà prévu au paragraphe 3, saisir et garder audit refuge un chien aux fins suivantes :
a) le soumettre à l’examen d’un médecin vétérinaire lorsqu’il y a des motifs raisonnables de croire qu’il constitue un risque pour la santé ou la sécurité publique conformément à l’article 296;
b) le soumettre à l’examen d’un médecin vétérinaire lorsque le gardien est en défaut de se présenter à l’examen conformément à l’article 296;
c) faire exécuter une ordonnance d’euthanasie rendue en vertu des articles 293 ou 307 lorsque le délai prévu pour s’y conformer est expiré;
d) lorsqu’il a été déclaré potentiellement dangereux ou à faible risque et que les normes de gardes imposées en vertu du présent règlement ne sont pas respectées et que cette situation constitue un risque pour la santé ou la sécurité publique. Le chien est gardé au refuge jusqu’à ce que la situation soit corrigée. À défaut de corriger la situation et de respecter les normes de garde dans le délai prescrit, l’article 335 s’applique.
5) confier la garde de tout chien saisi à une personne dans un établissement vétérinaire ou dans un autre refuge, dans un service animalier, dans une famille d’accueil, dans un centre de pension reconnu, dans une fourrière ou dans un lieu tenu par une personne ou un organisme voué à la protection des animaux titulaire d’un permis visé à l’article 19 de la Loi sur le bien-être et la sécurité de l’animal;
6) ordonner l’obligation de faire subir à un animal un examen médical par un vétérinaire;
7) ordonner le musellement ou toute autres normes de garde jugées nécessaire et la détention de tout animal pour une période déterminée;
8) faire isoler jusqu’à guérison complète tout animal soupçonné d’être atteint d’une maladie contagieuse, sur certificat d’un médecin vétérinaire;
9) faire euthanasier ou ordonner l’euthanasie d’un animal dangereux, potentiellement dangereux, mourant, gravement blessé, hautement contagieux ou qui ne fait pas partie des animaux autorisés en vertu du présent chapitre;
10) demander une preuve de stérilisation et de vaccination de tout chien et chat sur le territoire de la ville.

Aux fins de l’application du paragraphe 1) du présent article, tout propriétaire, locataire ou occupant d’une unité d’occupation doit, sur présentation d’une pièce d’identité des représentants de l’autorité compétente, leur permettre l’accès et répondre à leurs questions.

Aux fins de l’application du paragraphe 2) du présent article, lorsque le lieu est une maison d’habitation, l’autorité compétente ne peut y pénétrer qu’avec l’autorisation du propriétaire ou de l’occupant ou, à défaut, qu’en vertu d’un mandat de perquisition délivré par un juge, conformément à l’article 27 du Règlement d’application de la Loi visant à favoriser la protection des personnes par la mise en place d’un encadrement concernant les chiens.

Constitue une infraction au présent règlement le fait de nuire, d’entraver, d’injurier, d’interdire ou d’empêcher de quelque manière que ce soit l’autorité compétente de faire respecter toute disposition au présent chapitre ou de lui interdire l’accès visé au deuxième alinéa du présent article ou d’y faire autrement obstacle ainsi que le fait de refuser ou de négliger de se conformer à une demande qui lui est formulée en vertu du présent règlement.

Dans les cas de maladie contagieuse visés par les paragraphes 8) et 9) du présent article, un médecin vétérinaire doit être avisé sans délai conformément à la Loi sur la protection sanitaire des animaux.