---
id: bylaw-286-art-064
title: Article 64 - Identification civique des immeubles
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:41:43.819Z

module: public-bylaws
slug: bylaw-286-art-064

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-02
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-063
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-065
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-064.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 64
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE II - LES NUISANCES
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-064.md

---

# Article 64 - Identification civique des immeubles

Le numéro d’identification civique de chaque maison ou bâtiment doit être bien visible pour tous les intervenants (policiers, pompiers et ambulanciers).

1) Le propriétaire de toute maison et tout bâtiment situé sur le territoire de la ville doit afficher clairement en chiffres arabes, le numéro qui lui a été désigné par le Service des travaux publics;
2) Ces chiffres doivent être installés sur la façade principale donnant sur la rue du bâtiment ou de la maison et doivent être visibles de la rue en tout temps. Ils doivent être de couleur contrastante avec le mur sur lequel ils sont placés afin d’être visibles. Si la maison ou le bâtiment donne sur un stationnement, le numéro doit être affiché sur le mur qui donne directement sur le stationnement;
3) Pour toute maison ou tout bâtiment situé à plus de 20 mètres de la rue, le numéro doit être affiché à l’entrée du chemin ou de l’allée menant à la maison ou au bâtiment;
4) Si un bâtiment contient plusieurs appartements, locaux ou suites, chacun doit être identifié de façon distincte par un numéro. Le numéro doit être affiché sur la porte d’entrée principale de l’appartement, du local ou de la suite;
5) Le numéro d’identification civique de toute maison ou tout bâtiment commercial ou public doit être éclairé de façon à ce qu’il soit visible de la rue en tout temps;
6) Si un abri temporaire installé pour l’hiver cache le numéro d’identification civique d’une maison ou d’un bâtiment, celui-ci doit être alors affiché sur l’abri temporaire;
7) Dans le cas d’un nouveau bâtiment, le numéro civique doit être installé dans les dix (10) jours suivant le début des travaux de construction.

Ces dispositions ne s’appliquent pas dans le cas où une ville a instauré un système de numérotation en bordure de chemin.