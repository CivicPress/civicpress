---
id: bylaw-286-art-318
title: Article 318 - Renouvellement
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:15.936Z

module: public-bylaws
slug: bylaw-286-art-318

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-11
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-317
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-319
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-318.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 318
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE XI - LES ANIMAUX
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-318.md

---

# Article 318 - Renouvellement

a) Le gardien d’un animal visé au paragraphe a) de l’article 312, dans les limites de la ville, doit, au cours du mois de janvier de chaque année, renouveler la licence émise conformément à l’article 316.
b) Le gardien d’un animal visé au paragraphe b) de l’article 312, dans les limites de la ville, doit, au cours du mois de janvier de chaque année, renouveler la licence émise conformément à l’article 316.
c) Les frais de retard prévus au règlement de tarification de la ville s’ajoutent au coût du renouvellement de la licence lorsque le gardien n’a pas renouvelé, au plus tard le 15 février de chaque année, ladite licence.