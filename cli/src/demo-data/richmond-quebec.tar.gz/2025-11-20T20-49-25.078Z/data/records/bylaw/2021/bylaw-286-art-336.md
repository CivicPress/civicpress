---
id: bylaw-286-art-336
title: Article 336 - Frais de transport, d’hébergement et de soins vétérinaires
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:18.257Z

module: public-bylaws
slug: bylaw-286-art-336

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-11
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-335
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-337
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-336.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 336
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE XI - LES ANIMAUX
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-336.md

---

# Article 336 - Frais de transport, d’hébergement et de soins vétérinaires

Le gardien peut reprendre possession de son animal, à moins qu’il ne s’agisse d’un animal interdit en vertu du présent chapitre ou que la SPA de l’Estrie en ait déjà disposé. Les frais de transport, d’hébergement et de soins vétérinaires, le cas échéant, engagés pour la capture et la garde de l’animal sont aux frais du gardien.

Le gardien doit également payer la licence ou le renouvellement de cette licence si ce dernier est en défaut d’avoir obtenu une licence ou de l’avoir renouvelé.

Les frais décrits au premier alinéa du présent article sont également exigés du gardien d’un animal même si celui-ci ne réclame pas son animal ou lorsque la SPA de l’Estrie en dispose conformément à l’article 335.

Malgré le paiement des frais par le gardien d’animal, la ville se réserve le droit de le poursuivre pour toute infraction au présent règlement, s’il y a lieu.