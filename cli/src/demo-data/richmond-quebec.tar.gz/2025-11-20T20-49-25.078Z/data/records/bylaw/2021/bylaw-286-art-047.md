---
id: bylaw-286-art-047
title: Article 47 - Foyer extérieur préfabriqué
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:41:41.737Z

module: public-bylaws
slug: bylaw-286-art-047

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-02
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-046
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-048
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-047.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 47
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE II - LES NUISANCES
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-047.md

---

# Article 47 - Foyer extérieur préfabriqué

Les feux en plein air contenus dans un foyer extérieur préfabriqué vendu chez des détaillants ou de fabrication artisanale, qui possède une barrière physique de dimension maximale à vingt-sept (27) pieds cubes avec un fond empierré et non attenant à un bâtiment, qui respecte les normes d’installation prévues à l’article suivant et que la fumée n’incommode pas les voisins sont autorisés et aucun permis n’est requis.