---
id: bylaw-286-art-240
title: Article 240 - Règles de conduite
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:05.661Z

module: public-bylaws
slug: bylaw-286-art-240

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-10
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-239
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-241
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-240.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 240
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE X - DE L'ORDRE ET DE LA PAIX PUBLIQUE
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-240.md

---

# Article 240 - Règles de conduite

Dans tout lieu récréatif, il est notamment interdit à quiconque :

1) d’y pénétrer lorsque l’entrée est interdite ou sans être porteur d’un billet lorsqu’un billet est exigible;
2) d’occuper une place autre que celle indiquée sur le billet lorsque ce dernier comporte une telle indication;
3) de passer ou d’aider quelqu’un à passer d’un niveau des gradins à un autre ou d’une section des gradins à une autre, autrement qu’en empruntant les voies d’accès pour se rendre à ces niveaux ou à ces sections;
4) de faire usage de sifflets, sirènes, trompettes à gaz ou à air comprimé ou de tout autre appareil ou objet produisant un son susceptible d’être confondu avec un signal officiel utilisé lors d’un spectacle;
5) de lancer quoi que ce soit sur les terrains d’un bâtiment, d’un lieu récréatif quelconque notamment sur une patinoire, arène, estrades ou tout lieu réservé à ceux qui présentent un spectacle, de même que les gradins ou autres endroits où le public a accès.

Le premier alinéa ne s’applique pas lorsque le lancement d’un objet fait partie d’un jeu ou d’un spectacle et est effectué par un joueur ou une personne qui participe à la présentation d’un tel jeu ou spectacle.

6) de retarder, par quelconque moyen, la présentation d’un spectacle ou de nuire à son déroulement normal;
7) de se rendre en tout temps, sans autorisation, sur une patinoire, arène, estrade ou tout lieu réservé à ceux qui présentent un spectacle;
8) de refuser de suivre les directives données par les préposés ou par une signalisation relative au bon ordre et à la paix ainsi qu’à l’accès aux lieux récréatifs;
9) de vendre ou d’offrir en vente, sans autorisation, quelque marchandise ou objet quelconque y compris tout billet permettant l’admission au lieu récréatif;
10) de flâner lorsqu’aucun spectacle n’y est présenté ou lorsqu’un spectacle est terminé;
11) de se battre;
12) de proférer des blasphèmes, des injures ou des paroles de menace ou indécentes ou de faire une action indécente ou obscène;
13) de se trouver ivre ou sous l’influence d’une drogue ou de faire usage de boissons alcooliques ou de drogues, à l’exception de l’usage de boisson qui peut y être fait conformément à une autorisation donnée par l’administration en place et par la Régie des permis d’alcool du Québec;
14) de causer quelque dommage que ce soit à la propriété;
15) de conduire des animaux, sauf si une autorisation à l’effet contraire le permet, auquel cas ils doivent être tenus en laisse;
16) de satisfaire à quelque besoin naturel ailleurs qu’aux endroits aménagés à cette fin;
17) de jeter, ailleurs que dans les endroits prévus à cette fin, des déchets, papiers, mégots, bouteilles ou autres objets quelconques;
18) de se promener au moyen de cheval ou d’un autre animal, bicyclette, motocyclette, motoneige ou tout autre véhicule, sauf en la manière et dans les endroits spécifiquement prévus à cette fin;
19) d’allumer ou de faire éclater, sans autorisation, tout pétard, pièce pyrotechnique ou tout autre objet explosif;
20) de pénétrer en transportant ou en ayant en sa possession un ou des contenants fabriqués en verre.