---
id: bylaw-286-art-035
title: Article 35 - Travaux de construction
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:41:40.257Z

module: public-bylaws
slug: bylaw-286-art-035

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-02
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-034
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-036
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-035.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 35
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE II - LES NUISANCES
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-035.md

---

# Article 35 - Travaux de construction

Il est interdit de faire ou de laisser faire, entre 22 h 00 et 7 h 00, en tout endroit de la ville à moins de cent cinquante mètres (150 m) d’une maison d’habitation, des bruits à l’occasion de travaux de construction, de reconstruction, de modification ou de réparation d’un bâtiment ou d’une structure, d’un véhicule automobile ou de toute autre machine ou de faire ou de permettre qu’il soit fait des bruits à l’occasion de travaux d’excavation, au moyen de tout appareil mécanique susceptible de faire du bruit.

Cet article ne s’applique pas s’il s’agit de travaux d’urgence visant à sauvegarder la sécurité des lieux ou des personnes.