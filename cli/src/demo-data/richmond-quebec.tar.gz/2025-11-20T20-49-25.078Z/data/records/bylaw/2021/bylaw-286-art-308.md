---
id: bylaw-286-art-308
title: Article 308 - Confidentialité du rapport du médecin vétérinaire, de la décision et des mesures ordonnées
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:14.636Z

module: public-bylaws
slug: bylaw-286-art-308

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-chap-11
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-307
    type: bylaw
    category: follows
    description: Previous record in sequence
  - id: bylaw-286-art-309
    type: bylaw
    category: precedes
    description: Next record in sequence

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-art-308.md
    created: {}
    year: 2021
    language: fr-CA
    article_number: 308
    jurisdiction: municipal
    classification: public
    public_access: true
    chapter: CHAPITRE XI - LES ANIMAUX
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: article
  file_path: bylaw/2021/bylaw-286-art-308.md

---

# Article 308 - Confidentialité du rapport du médecin vétérinaire, de la décision et des mesures ordonnées

Le rapport du médecin vétérinaire produit à la suite de l’évaluation comportementale d’un chien conformément à la présente sous-section appartient à la ville et est considéré confidentiel sauf si, pour des raisons de santé ou de sécurité, il est raisonnable de divulguer à une personne qui le demande certaines informations qui y sont contenues.

La décision et les mesures ordonnées par la ville ne sont pas considérées confidentielles et s’appliquent sur l’ensemble du territoire du Québec, tel que prévu par l’article 15 du Règlement d’application de la Loi visant à favoriser la protection des personnes par la mise en place d’un encadrement concernant les chiens.