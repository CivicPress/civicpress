---
id: bylaw-286-chap-09
title: CHAPITRE IX - LES JEUX ÉLECTRONIQUES ET LES SALLES DE JEUX ÉLECTRONIQUES
type: bylaw
status: approved

author: civicpress-ingest
authors:
  - name: CivicPress Ingest
    role: automation
    username: civicpress-ingest

created: 2021-01-01T00:00:00.000Z
updated: 2025-11-12T20:42:27.950Z

module: public-bylaws
slug: bylaw-286-chap-09

source:
  reference: Regl_286_General.pdf
  original_title: Regl_286_General
  original_filename: Regl_286_General.pdf
  url: https://richmond.quebec/wp-content/uploads/2021/03/Regl_286_General.pdf
  type: import
  imported_at: 2025-11-07T16:28:32.000Z
  imported_by: dashboard

linked_records:
  - id: bylaw-286
    type: bylaw
    category: references
    description: Parent record
  - id: bylaw-286-art-178
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-179
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-180
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-181
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-182
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-183
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-184
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-185
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-186
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-187
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-188
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-189
    type: bylaw
    category: referenced_by
    description: Child record
  - id: bylaw-286-art-190
    type: bylaw
    category: referenced_by
    description: Child record

metadata:
  metadata:
    file_path: bylaw/2021/bylaw-286-chap-09.md
    created: {}
    year: 2021
    language: fr-CA
    jurisdiction: municipal
    classification: public
    public_access: true
    extensions:
      ingest:
        sha256: 0c1f0cf21efdf644010e66482f37ff847f1a8c5231654ae396ed13340869fc34
        extraction_method: pdfminer
        original_size: 994602
        cleanup_applied: true
        cleanup_timestamp: {}
        updated_at: {}
        updated_by: dashboard
    kind: chapter
  file_path: bylaw/2021/bylaw-286-chap-09.md

---

# CHAPITRE IX - LES JEUX ÉLECTRONIQUES ET LES SALLES DE JEUX ÉLECTRONIQUES

- [Article 178 - Interprétations](bylaw-286-art-178.md)
- [Article 179 - Prohibition des salles de jeux électroniques](bylaw-286-art-179.md)
- [Article 180 - Permis d'opération obligatoire](bylaw-286-art-180.md)
- [Article 181 - Conditions](bylaw-286-art-181.md)
- [Article 182 - Coût du permis](bylaw-286-art-182.md)
- [Article 183 - Droits acquis](bylaw-286-art-183.md)
- [Article 184 - Nombre de jeux électroniques](bylaw-286-art-184.md)
- [Article 185 - Autre activité](bylaw-286-art-185.md)
- [Article 186 - Heures d'ouverture](bylaw-286-art-186.md)
- [Article 187 - Accès](bylaw-286-art-187.md)
- [Article 188 - Bruit](bylaw-286-art-188.md)
- [Article 189 - Permis d'exploitation/jeux électroniques](bylaw-286-art-189.md)
- [Article 190 - Coût](bylaw-286-art-190.md)